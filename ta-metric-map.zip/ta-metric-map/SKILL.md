---
name: ta-metric-map
description: Fill the TA metric map workbook (TA_Metric_Map_v5.xlsx) from Tableau workbooks, SQL, spreadsheets and decks. Use when asked to inventory TA dashboards, metrics, tables or fields, to run the metric audit, or to populate or extend the metric map. Works in passes, stops for review after each, and logs every uncertainty as a question instead of guessing.
---

# TA metric map: filling the workbook

You are filling an audit workbook that records what exists today in the talent acquisition
reporting stack: products (dashboards, scorecards, sent reports), the metrics on them, the
tables and fields behind those metrics, and the business rules applied along the way. People
will later decide, row by row, what to keep, fix, move, build or retire. Your job is to make
the inventory complete and honest. Their job is to judge it.

Two rules override everything else in this file:

1. **A blank cell is fine. A guessed cell is a defect.** If you are not sure, leave the cell
   blank and add a row on the Questions sheet. Never pick between two readings yourself.
2. **Stop after every pass and show your work.** Do not run the next pass until the person
   has said to continue.

## Before you start

If this is the first time on this machine, follow `INSTALL.md` (one `pip install openpyxl`, then the self-test).

Read, in this order:

- `references/schema.md` — every sheet and column, which are machine-fillable and which are human-only.
- `references/extraction-rules.md` — how to turn a Tableau workbook, a SQL file, a spreadsheet or a deck into rows, and the rules for IDs, deduplication and metric families.
- `references/writing-style.md` — how to write every cell. Plain, precise, the way an analyst would explain it to a colleague.
- `references/manifest.md` — the folder layout and the manifest the person provides.

Check the inputs:

- The workbook, usually `TA_Metric_Map_v5.xlsx` or a later version. Confirm the sheet names match `schema.md`. If they do not, stop and ask; do not adapt.
- The source folder and its `manifest.csv`. Every file you read must be listed in the manifest. A file in the folder but not in the manifest: ask before reading it. A file in the manifest but not in the folder: report it, do not go looking elsewhere.
- Tableau files must be `.twb` or `.twbx`. Screenshots, PDFs of dashboards and links to Tableau Server cannot be parsed; say so and ask for the workbook file.
- Databricks notebooks must be exported as `.py` or `.ipynb` (or `.sql` for SQL notebooks). A `.dbc` archive cannot be parsed; ask for the export.

Never edit an existing row. Append only. If something already in the workbook looks wrong,
log a question that names the row. Re-running on the same files is safe: `workbook.py` skips a
row whose name or key pair already exists and tells you the existing row.

## The passes

Run them in order. After each, write a short summary (what was added, what was skipped, how
many questions raised), save the workbook, and stop.

### Pass 0a: draft the manifest, if there is none

If the source folder has no `manifest.csv`, run
`python3 scripts/propose_manifest.py <folder>`. It writes a draft with one row per file: the
kind from the extension, and for Tableau files the dashboards, worksheets, tables read and
number of calculated fields, so the person can see what each file is without opening it.
It leaves `product_name`, `owner_team`, `warehouse_schemas` and `team_schemas` blank and
marks any file it cannot classify with kind `?`.

Show the draft and ask the person to fill the blanks and confirm each row. Do not proceed
until they have. Never fill `product_name` or the schema columns yourself; those decide what
lands on the Products sheet and how Layer is set, and both are theirs to say.

### Pass 0: read the manifest and plan

Run `python3 scripts/workbook.py check <map.xlsx>` first; stop if it reports problems.
List the files you will process, in manifest order, and say which pass each feeds. Ask about
anything in the manifest that is unclear (for example, two files that look like versions of the
same dashboard). Stop.

### Pass 1: Products

One row per product in the manifest. Fields you can fill: Product ID, Product name (from the
manifest, or the workbook's dashboard name if the manifest leaves it blank), Type, Tool,
Refresh frequency when the extract settings show it, Source, Confidence. Leave Audience, Owner,
Point of contact and Delivery cadence blank unless the manifest gives them.

Rule: a Tableau workbook with several dashboards is still one product unless the manifest
says otherwise. Ask if a workbook's dashboards look like unrelated products.

Show the Products list. Stop.

### Pass 2: Tables

From SQL files, repo code, Databricks notebooks and the physical tables named in Tableau data sources. One row per
distinct physical table. Fill: Table ID, Table name (schema.table as it appears), Layer (HRDW
if it is a warehouse table named in the manifest or recognisable by schema; Team custom if a
SQL file in the repo creates it; otherwise leave blank and ask), Built from (table IDs of
everything the creating SQL reads, main source first), Refresh when a schedule is visible in
code, Source, Confidence. Never fill Why it exists, Owner, Refresh owner, Point of contact,
Status, Target layer, Disposition.

Rule: if a SQL file reads a table you have not seen, create a row for it with Layer blank and
ask what it is. Do not invent a layer.

Show the Tables list and the lineage chains the workbook computes. Stop.

### Pass 3: Metrics and Metric to Product

From Tableau calculated fields and the measures placed on worksheets, from aggregate columns
computed in notebooks, plus any metric names and values in spreadsheets and decks. When a
notebook computes a column and a dashboard shows it, that is one metric computed in the
notebook; when the dashboard recomputes it with its own formula, that is two definitions and a
question. For each distinct calculation that produces a number
people look at, one Metrics row: Metric ID, Metric family, Metric name, Definition (the
formula translated into plain words, see writing-style.md), Grain if it is clear from the
formula's level of detail, Unit, Source, Confidence. Then one Metric to Product row per
product the metric appears on, with How it is shown.

The deduplication rule, which matters most on a scorecard with one tab per org:

- Same formula, different filter or different tab → **one metric**. The filter is a dimension.
- Same name, different formula → **two metrics in the same family**, each with its own ID,
  and a Question saying the family has two definitions.
- Different name, same formula → one metric; record the alternate name in Notes and ask
  which name is official.

Compare formulas after normalising whitespace, case and field aliases. If you cannot tell
whether two formulas are equivalent, they are two rows and a question.

Never fill Population ID, Status, Owner. If a formula contains a filter that looks like a
population rule (for example excluding evergreen reqs), put that in Notes and raise a
question proposing it as a Population.

Show the Metrics list grouped by family, with families that have more than one definition at
the top. Stop.

### Pass 4: Fields and Metric to Field

For each field a metric's formula uses: one Fields row. Raw if it maps to a physical column
(the Tableau metadata gives the column and table); Derived if it is itself a calculated field
or is produced by SQL in the repo. Fill: Field ID, Field name (the caption, not the internal
name), Type, Table ID, Derived from, Logic (the calculation in plain words, for Derived
only), Source, Confidence. Then one Metric to Field row per field each metric uses, with Role.

Never fill Data quality, Target layer, Disposition, Issue / note.

Rule: if a Tableau calculated field's logic is a business rule (who gets credit, what counts,
how things are linked) rather than arithmetic, say so in Notes: "Business rule computed inside
the dashboard." That is what the person needs to find.

Show Fields with Derived rows first. Stop.

### Pass 5: Dimensions and Dimension usage

From the filters and the dimension fields on each worksheet. One Dimensions row per distinct
cut (org, level, location, recruiter, source, and so on), with Dimension ID and name only. One
Dimension usage row per product per dimension, with the Mapping source table ID you can trace
the dimension field back to. Never fill Agreed source; that is a decision.

Show the usage list, flagging any dimension whose products trace to different tables. Stop.

### Pass 6: Reconcile and report

Run `python3 scripts/workbook.py check <map.xlsx>`. Summarise: rows added per sheet, Questions
open, anything in the manifest that was not processed and why. Point the person at the
Decisions sheet. Stop. Do not fill Target layer or Disposition for anything.

## Working with the workbook

Use `scripts/workbook.py`; do not write cells with openpyxl directly. It assigns IDs, refuses
to touch formula columns, validates dropdown values, defaults missing Confidence to
"Guessed" so it cannot slip through, and turns a bad foreign key into a Question instead of a
broken row. Prepare each batch of rows as JSON keyed by the exact header text and call
`append`. After every save, run `check`.

Use `scripts/parse_notebook.py` for Databricks notebooks (.py, .ipynb, .sql exports) and PySpark
scripts. It returns reads, writes, join conditions and aliased expressions per cell; the join
conditions matter because that is where attribution rules hide. Use `scripts/parse_twb.py` for Tableau files. It outputs JSON with datasources, fields
(including calculated-field formulas with readable names), worksheets with the fields and
filters they use, dashboards, and extract settings. Work from that JSON, not from the raw XML.

The workbook's own formulas compute lineage depth, chains, counts and the Decisions sheet.
Open the saved file in a spreadsheet application, or have the person do so, to see those; do
not try to reproduce them.

## Confidence

Set on every row:

- **Found** — read directly from the file: a table name in a data source, a formula, a
  dashboard name.
- **Inferred** — deduced from more than one file, or from a naming pattern. Say what the
  inference was in Notes.
- **Guessed** — avoid. If you find yourself about to write Guessed, write a Question instead
  and leave the row's uncertain cells blank. The only acceptable Guessed is a row the person
  explicitly asked you to draft anyway.
- **Human** — never set by you.

## When to stop and ask

Add a Questions row and leave the cell blank, rather than deciding, when:

- Two sources disagree (two formulas for one name, two names for one formula, two tables
  with the same name in different schemas).
- A value for a dropdown column is not one of the allowed options.
- A table's layer is not clear from where it lives.
- A manifest entry is ambiguous or a file will not parse.
- Anything would require knowing intent: why a table exists, who owns something, whether a
  number is right.

Write each question so a person who was not there can answer it in one line, and put the
evidence (both formulas, both file names) in What was seen.

## What done looks like

Every file in the manifest has been processed or has a question explaining why not. Every
row has a Source and a Confidence that is Found or Inferred. No cell in a human-only column
has been touched. `check` reports no problems. The person can open Decisions and see counts.
