# Writing style for every cell

The test for any cell you write: would an analyst on the team write it this way to a
colleague? Precise about the rule, plain about the words. Not a system log, not a sales
deck, not a textbook.

## The standard

**Good**
> Recruiter who owned the requisition on the day the offer was accepted, not the recruiter tagged on it today.

**Too much**
> Leverages temporal ownership attribution logic to assign recruiter credit based on point-in-time requisition ownership at offer acceptance.

**Too little**
> The recruiter.

The good version says exactly what is chosen and what is not, in words a recruiter would use.

## Rules

1. **Say the rule, not the mechanism.** "Calendar days from requisition approval to offer
   acceptance", not "DATEDIFF('day', [Approved Date], [Accepted Date])". The formula goes in
   Notes for checking; the Definition is for reading.
2. **Name the edge case the formula handles.** If the formula excludes something, say so:
   "excluding requisitions flagged evergreen". If it handles transfers, say how.
3. **Use the business words the files use.** If the dashboard says "req", write "requisition"
   the first time and "req" is fine after. If it says "opening", do not change it to
   "position".
4. **One or two sentences.** Three means you are explaining instead of defining.
5. **No filler.** Never start with "This metric measures", "This table contains", "This field
   represents". Start with the thing itself.
6. **No judgement words.** Not "incorrectly", "legacy", "redundant", "should". You record;
   people judge. The exception is a Question, where you may say "appears to" when stating
   what you saw.
7. **No AI phrasing.** Avoid: leverage, utilise, robust, holistic, streamline, facilitate,
   ensure, comprehensive, seamless, delve, crucial, key (as an adjective). Avoid em dashes.
   Avoid bullet lists inside a cell.
8. **Numbers and dates plainly.** "38 days", "2026-10-07", "about a fifth of requisitions".
9. **Unknown is a word you may use.** If a formula is opaque, write "Unknown; see Notes" in
   the Definition and put the raw formula in Notes, then ask.

## By column

**Definition (plain words).** What starts the clock or what is counted, what ends it or
over what period, what is left out. Do not say who is counted; that is the Population.
> Calendar days from requisition approval to offer acceptance. A transferred requisition keeps its original approval date.

**Logic (the business rule).** What is chosen, from where, and what is deliberately not.
> Hiring org taken from the requisition at the time it was opened, not from the recruiter's org and not updated if the requisition moves.

**Why it exists.** Human-only. You never write it.

**How it is shown.** What the reader sees.
> Headline number for the quarter, one tab per org.

**Notes.** Facts a reviewer needs: the raw formula, the file, alternate names, where it appears.
> Formula: DATEDIFF('day', [Approved Date], [Accepted Date]). Appears on sheets "Eng", "Finance", "Ops". Also labelled "TTF" on the recruiter view.

**Question.** One question, answerable in a line, with the evidence separate.
> The scorecard and the recruiter view both call this "Cycle time" but the scorecard runs approval to accepted and the recruiter view runs posted to start. Are these meant to be the same metric?

**What was seen.**
> scorecard.twb: DATEDIFF('day',[Approved Date],[Accepted Date]). recruiter_view.twb: DATEDIFF('day',[Posted Date],[Start Date]).

## Sample rows

Metrics
> M-004 | Offer acceptance | Offer acceptance rate | Accepted offers divided by offers extended in the period. | Hire | Percent | Notes: Formula: COUNTD([Accepted Offer ID]) / COUNTD([Offer ID]). Appears on "Summary".

Fields (Derived)
> F-011 | Hiring org | Derived | Hiring org as recorded on the requisition when it was opened. Not refreshed if the requisition is transferred. | Notes: Business rule computed inside the dashboard. Formula: IF ISNULL([Org Override]) THEN [Req Org] ELSE [Org Override] END

Tables
> T-008 | ta_custom.req_linkage | Team custom | Built from: T-002 | Notes: Created by repo/sql/req_linkage.sql. Scheduled daily in dags/ta_daily.py.
