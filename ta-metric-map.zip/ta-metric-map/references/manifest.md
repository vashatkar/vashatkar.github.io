# Source folder and manifest

The person hands over one folder. Everything you read must be listed in `manifest.csv` at
its root. Nothing in the manifest is optional: if a listed file is missing, report it; if a
file is present but unlisted, ask before reading it.

## Folder layout

```
ta-metric-map-sources/
  manifest.csv
  tableau/        .twb and .twbx files (download the workbook from Tableau; links and screenshots cannot be parsed)
  notebooks/      Databricks notebooks exported as .py or .ipynb (not .dbc), and PySpark scripts
  sql/            .sql files, dbt project folders, scheduler files (DAGs, cron) as they are in the repo
  spreadsheets/   recurring .xlsx reports as the actual files, not PDF exports
  decks/          .pptx files
  docs/           anything else: PDP source-to-target mappings, data dictionaries, runbooks
```

Sub-folders inside those are fine; the manifest path is relative to the root.

## manifest.csv

One row per file. Columns, in this order:

| Column | Required | Meaning |
|---|---|---|
| path | yes | Relative path from the folder root, e.g. `tableau/TA_Scorecard.twbx` |
| kind | yes | One of: `tableau`, `notebook` (Databricks .py/.ipynb/.sql exports, PySpark scripts), `sql`, `dbt`, `scheduler`, `spreadsheet`, `deck`, `mapping`, `doc` |
| product_name | for tableau, spreadsheet, deck | The name people use for it. Becomes the Products row. Leave blank for sql/dbt/scheduler/mapping/doc |
| product_type | for tableau, spreadsheet, deck | Scorecard, Dashboard, Sent report, Data pull, Table, Other |
| owner_team | no | Team that owns it, if known |
| warehouse_schemas | no | Comma-separated schemas that are HRDW (warehouse) tables, e.g. `hrdw, hr_core`. Put this on any row; it applies to the whole run |
| team_schemas | no | Comma-separated schemas that are the team's custom tables, e.g. `ta_custom, ta_rpt` |
| notes | no | Anything the extractor should know: "two dashboards in this workbook are one product", "this deck is monthly", "ignore sheet 'Scratch'" |

Draft it: `python3 scripts/propose_manifest.py <folder>` writes a first version with kind and notes filled from the files; you fill product names and the schema columns and confirm each row. Template for reference: `manifest_template.csv` in this folder. Copy it to the root of the source folder as
`manifest.csv` and fill it.

## What good manifest notes look like

- `TA_Scorecard.twbx`: "One tab per org with the same metrics; tabs 'Exec summary' and 'Pipeline' have different metrics. Treat the whole workbook as one product."
- `recruiter_view.twb`: "Reads the extract table ta_rpt.recruiter_extract. Owner Team Opportunity."
- `sql/`: "dbt project. models/ folder creates all ta_custom tables. Scheduled by dags/ta_daily.py."
- `decks/TA_monthly_Sep.pptx`: "Sent report. Values on slide 3 come from the scorecard."

## What the extractor does with the schemas

`warehouse_schemas` and `team_schemas` are how Layer gets set on Tables without guessing. A
table in a listed warehouse schema is HRDW; in a listed team schema is Team custom; in neither
is left blank with a Question. Give these on the first row of the manifest.
