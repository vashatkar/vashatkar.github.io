# Workbook schema

File: `TA_Metric_Map_v5.xlsx` (or later). Header row is row 4; data starts at row 5. Column A
on every entity sheet is the ID. Columns whose header starts with `h_` are helpers for the
Decisions sheet: never write to them.

**Machine** = you may fill it when the source shows it. **Human** = never fill; a person
decides. **Formula** = computed by the workbook; never write to it.

Every entity sheet also carries four provenance columns at the right: `Source (where found)`
(Machine), `Confidence` (Machine, see SKILL.md), `Last verified` (Human), `Verified by` (Human).
Join sheets carry `Source (where found)` and `Confidence` only.

## Products — one row per thing people look at

| Column | Who | Notes |
|---|---|---|
| Product ID | Machine | `P-001` … assigned by `workbook.py` |
| Product name | Machine | Manifest name, else the workbook's dashboard name |
| Type | Machine | Scorecard, Dashboard, Sent report, Data pull, Table, Other. From manifest or by inspection |
| Tool | Machine | Tableau, QuickSight, Snowflake, Excel, Slides, Other |
| Audience | Human | |
| Owner (team) | Human | Manifest may give it |
| Point of contact | Human | |
| Refresh frequency | Machine | From extract refresh settings or job schedule, when visible |
| Delivery cadence | Human | Sent reports only |
| Notes | Machine | Anything that would otherwise be lost |

## Populations — who is counted

All columns Human except `Metrics using it` (Formula). You may propose a population in a
Question when a formula contains an obvious population filter; never add a row yourself.

## Metrics — one row per distinct definition

| Column | Who | Notes |
|---|---|---|
| Metric ID | Machine | `M-001` … |
| Metric family | Machine | The plain shared name: "Cycle time", "Hires", "Offer acceptance". Reuse an existing family if the idea is the same |
| Metric name | Machine | Family plus the distinguishing part in brackets when more than one definition exists |
| Definition (plain words) | Machine | The formula translated, see writing-style.md. Do not restate who is counted |
| Population ID | Human | |
| Population | Formula | |
| Grain (one row per) | Machine, if clear | Requisition, Opening, Application, Offer, Hire, Interview, Other. Infer from the level of detail of the calculation; if unsure, blank |
| Unit | Machine | Days, Count, Percent, Dollars |
| Status | Human | |
| Owner | Human | |
| Products using it / Fields needed / Definitions in family | Formula | |
| Notes | Machine | Alternate names, where the formula lives, anything odd |

## Metric to Product — one row per metric per product

Metric ID, Product ID (Machine); names (Formula); How it is shown (Machine: "headline tile",
"trend by month", "table by org"); Notes.

## Tables — one row per physical table

| Column | Who | Notes |
|---|---|---|
| Table ID | Machine | `T-001` … |
| Table name | Machine | `schema.table` as written in the source |
| Layer | Machine, if clear | HRDW, Team custom, Platform, Other. Blank plus a Question if unclear |
| Built from (table IDs, main parent first) | Machine | From the creating SQL's FROM/JOIN clauses. Main source first; the lineage chain follows the first one |
| Why it exists | Human | |
| Owner (team) / Refresh owner / Point of contact | Human | |
| Refresh | Machine, if visible | |
| Status | Human | |
| Target layer / Disposition | Human | The architecture decision. Never touch |
| Depth / Lineage chain / Fields listed / Metrics depending | Formula | |
| Notes | Machine | File that creates it, anything odd |

## Fields — one row per column a metric needs

| Column | Who | Notes |
|---|---|---|
| Field ID | Machine | `F-001` … |
| Field name | Machine | The caption people see, not `[Calculation_123]` |
| Type | Machine | Raw if it maps to a physical column; Derived if calculated in Tableau or produced by SQL |
| Table ID | Machine | For Raw: the physical table. For Derived: the table where the result lives; if it lives only inside a Tableau workbook, leave blank and note "exists only in dashboard" |
| Table name / Layer | Formula | |
| Derived from (field IDs) | Machine | Derived only |
| Logic (the business rule) | Machine | Derived only. The calculation in plain words |
| Data quality | Human | |
| Target layer / Disposition | Human | |
| Issue / note | Human | |
| Notes | Machine | Mark "Business rule computed inside the dashboard" when that is what it is |
| Metrics using it / Products reached | Formula | |

## Metric to Field — one row per field a metric uses

Metric ID, Field ID (Machine); names (Formula); Role in the metric (Machine: Start of clock,
End of clock, Event counted, Exclusion, Attribution, Linkage, Dimension, Other); Products
using this metric (Formula); Notes.

## Dimensions — the cuts

Dimension ID, Dimension name (Machine). Agreed source table ID, Agreed source field, Status,
Owner (Human). Counts (Formula).

## Dimension usage — product × dimension

Product ID, Dimension ID, Mapping source table ID (Machine: the table the dimension field
traces back to). Names and Matches agreed source? (Formula). Notes.

## Decision log — Human only. Never write here.

## Questions — your output channel

Question ID (`Q-001` …), Raised on, Sheet, Row ID, Question, What was seen, Status = Open.
Answer, Answered by, Answered on are Human.

## Decisions, Column guide, README — Formula / static. Never write.
