# Extraction rules

How each kind of source becomes rows. Read `schema.md` first for which columns you may fill.

## Tableau workbooks (.twb, .twbx)

Run `python3 scripts/parse_twb.py <file> -o <file>.json` and work from the JSON.

**Products.** One row per workbook unless the manifest says a workbook holds several
products. Type from the manifest; if the manifest is silent, Dashboard. Refresh frequency: if
`extract.enabled` is true and the manifest or a schedule file names a cadence, use it;
otherwise blank.

**Tables.** For each datasource, each entry in `tables` is a physical table (`schema.table`
in the `table` value). Each `custom_sql` entry is a query: create no Tables row for the query
itself; instead create rows for the tables its FROM/JOIN clauses name, and note on the Product
"reads custom SQL embedded in the workbook" (that is logic living in a dashboard, which the
person wants to know). Layer: HRDW if the schema matches one the manifest lists as warehouse;
Team custom if the manifest lists the schema as the team's; else blank and ask.

**Metrics.** A metric is a calculated field, or a plain measure, that is placed on a
worksheet as a value people read. Field placed only as a filter or a row/column header is a
dimension, not a metric. For each:

- `Metric family`: the caption with any qualifier removed ("Cycle Time (Eng)" → family "Cycle
  time"). Reuse an existing family when the idea matches; when in doubt, same family plus a
  question.
- `Metric name`: family, plus a bracketed qualifier if the family already has a different
  definition ("Cycle time (posted to start)").
- `Definition`: translate `formula_readable` into words (see writing-style.md). Keep the
  field captions as they are.
- `Unit`: DATEDIFF in days → Days; COUNT/COUNTD/SUM of a count → Count; a ratio → Percent.
- `Grain`: the entity the formula counts or averages over, if the worksheet's level of detail
  shows it. Otherwise blank.
- `Notes`: "Formula: <formula_readable>" so a reviewer can check your translation, plus the
  worksheet names it appears on.

**Deduplication across worksheets and tabs.** Normalise each formula: lower-case, collapse
whitespace, replace each field reference with its caption. Then:

| Case | Result |
|---|---|
| Same normalised formula, different worksheet / filter / tab | One metric. The filter becomes a Dimension usage |
| Same caption, different normalised formula | Two Metrics rows, same family, distinct bracketed names, one Question: "family X has two definitions" |
| Different caption, same normalised formula | One Metrics row; other caption in Notes; Question: which name is official |
| Formulas differ only by a constant or a hard-coded list | Two rows and a Question. Do not decide they are "basically the same" |

**Metric to Product.** One row per (metric, product). `How it is shown`: what the worksheet
does with it ("headline number", "monthly trend", "table by org"), from the worksheet's
structure and title.

**Fields.** Every field referenced by a metric's formula, recursively through other
calculated fields:

- Physical column (`physical_column` and `physical_table` present) → Type Raw, Table ID = the
  table's row.
- Calculated field → Type Derived, `Derived from` = the fields it references, `Logic` = the
  formula in words, Table ID blank, Notes "Exists only inside the dashboard".
- If a calculated field expresses a business rule (attribution, inclusion, linkage, mapping)
  rather than arithmetic, add to Notes: "Business rule computed inside the dashboard."

**Metric to Field.** One row per (metric, field) with Role: the two dates in a DATEDIFF are
Start of clock and End of clock; the thing inside COUNT/SUM is Event counted; a field used in a
WHERE-like IF or a filter is Exclusion; a field deciding whose row it is (recruiter, owner) is
Attribution; a field used to join records is Linkage; anything used only to slice is
Dimension.

**Dimensions and usage.** Fields that appear as filters, row/column headers or colour on a
worksheet are dimensions. One Dimensions row per distinct caption, merging obvious variants
("Org", "Organization", "Hiring Org") under one name with the variants in Notes and a
question if the merge is not obvious. One Dimension usage row per (product, dimension) with
`Mapping source table ID` = the physical table the field traces to. If the dimension field is
itself calculated (a CASE statement mapping values), that is a mapping living in the dashboard:
note it and leave Mapping source blank.

## SQL files and repository code (dbt, plain .sql)

**Tables.** Each `CREATE TABLE`, `CREATE VIEW`, `CREATE OR REPLACE`, `INSERT INTO`, or dbt
model produces one Tables row for its target, Layer = Team custom (if the repo is the team's)
or blank. `Built from` = every table in FROM and JOIN clauses, resolved to Table IDs; the
first FROM table goes first. Tables read but not created anywhere in the repo get their own row
with Layer blank and a Question unless the manifest identifies the schema. Refresh: from a
scheduler file (Airflow DAG, cron, dbt schedule) when present.

**Fields.** Each column in a SELECT that is more than a pass-through is a Derived field on
the target table: `Derived from` = the source columns, `Logic` = the expression in words. Pure
pass-through columns are not rows unless a metric uses them.

**Lineage sanity.** If a table reads from a table that reads from it (a cycle), stop and ask.

## Databricks notebooks and scripts (.py, .ipynb, .sql)

Run `python3 scripts/parse_notebook.py <file> -o <file>.json`. It splits the notebook into
cells and reports, per cell, the tables read, the tables written, the JOIN conditions, and
every `expression AS alias` (plus `withColumn` and `df["col"] = ...` in Python). It is a
text-level extractor: treat its output as evidence to check against the cell's SQL, which it
also returns.

**Tables.** Every table in `writes` is a Tables row (Layer from the schema columns in the
manifest). Every table in `reads` that is not written anywhere in the manifest's files gets a
row too, Layer by schema or blank plus a question. `Built from` for a written table = the
`reads` of the cell that writes it; if the cell reads a temporary view or DataFrame built in an
earlier cell, follow it back to the physical tables and note that you did.

**Fields.** Every aliased expression that is not a plain rename is a Derived field on the
table the cell writes (`written_to`), with `Logic` = the expression in words and `Derived from`
= the columns it references. A plain rename (`h.owner_id AS credited_recruiter`) is still a
Derived field when the *join* that supplies it carries a condition, because the rule is in the
join: look at the cell's `joins` list. A history table joined on a date range, a status filter in
an ON clause, a COALESCE across two sources, all of these are business rules. Write the rule
from the join condition, not just the alias.

> Example: `h.owner_id AS credited_recruiter` with `JOIN hrdw.requisition_history h ON ... o.accepted_dt BETWEEN h.valid_from AND h.valid_to`
> becomes Logic: "Recruiter who owned the requisition on the day the offer was accepted, taken from the requisition history."

**Metrics.** An aliased expression is a metric candidate when it is an aggregate (COUNT,
SUM, AVG, a ratio of aggregates) or a DATEDIFF that a product then shows. Match it to the
Tableau side by name and formula: if `cycle_time_days` in the notebook and `Cycle Time` in the
workbook are the same calculation, that is one metric with the notebook as the place it is
computed (Notes: "computed in <notebook>, cell N; the dashboard reads the column"). If the
dashboard recomputes it with its own formula, that is a second definition in the family and a
question.

**Parameters and widgets.** If table names come from `dbutils.widgets` or variables you
cannot resolve, do not guess the table: raise a question listing the variable and where it is
set.

**What a notebook cannot tell you.** Why the table exists, who owns it, how often it runs
(unless a job definition is in the manifest). Leave those blank.

## Spreadsheets and decks

These mostly yield metric *names* and *reported values*, not definitions. For each metric
named in a deck or a recurring spreadsheet:

- If it matches an existing Metrics row by family, add a Metric to Product row for the deck or
  spreadsheet (which is itself a Product of Type Sent report, created in Pass 1) and put the
  reported value and date in Notes.
- If it does not match, create a Metrics row with Definition blank, Notes "Named in <file>;
  no formula available", Confidence Inferred, and a Question asking where it is computed.
- If the same name appears with different values for the same period in two files, that is
  evidence for a definition conflict: record both values in the Question.

Never derive a definition from a deck's prose. Only a formula or SQL is a definition.

## IDs and naming

- IDs come from `workbook.py next-id`. Never reuse or renumber.
- Table names: `schema.table`, lower case, exactly as the source spells them.
- Field names: the caption people see. If only an internal name exists, use it unbracketed
  and note it.
- Product names: from the manifest. Never invent a friendlier name.

## What is not extraction

You are not asked to decide whether a rule is right, which definition should win, what a
table is for, or where anything should live. Those are the Human columns. Record, translate,
flag.
