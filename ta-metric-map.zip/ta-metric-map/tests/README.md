# Self-test

Before running the skill on real files, prove the scripts work here:

    python3 scripts/parse_twb.py tests/sample_scorecard.twb -o /tmp/sample.json
    cp /path/to/TA_Metric_Map_v5.xlsx /tmp/map.xlsx
    python3 scripts/workbook.py check /tmp/map.xlsx

Expected from the parser: 1 datasource reading TA_RPT.SCORECARD_BASE, three calculated
fields (two captioned "Cycle Time" with different formulas, one "Hires"), three worksheets
(Eng, Finance, Pipeline), one dashboard. The two "Cycle Time" formulas are the deduplication
case in extraction-rules.md: same caption, different formula, so two Metrics rows in one
family plus a Question.

Notebook parser:

    python3 scripts/parse_notebook.py tests/sample_notebook.py

Expected: reads hrdw.requisition, hrdw.offer, hrdw.requisition_history, ta_custom.req_linkage;
writes ta_rpt.scorecard_base and ta_rpt.hires_by_req; six aliased expressions including
cycle_time_days and counts_for_ttf; a join on requisition_history with a BETWEEN condition,
which is the recruiter-credit rule.

Manifest proposer:

    python3 scripts/propose_manifest.py <any folder containing tests/>
