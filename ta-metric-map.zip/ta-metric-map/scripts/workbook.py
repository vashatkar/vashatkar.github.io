#!/usr/bin/env python3
"""
Read from and append to the TA metric map workbook without breaking its formulas,
formatting, IDs or dropdowns.

Usage (as a library from Claude Code, or from the command line):

    python3 workbook.py list   <map.xlsx> <sheet>                  # print existing rows as JSON
    python3 workbook.py next-id <map.xlsx> <sheet>                 # next free ID for that sheet (P-004, T-012 ...)
    python3 workbook.py append <map.xlsx> <sheet> <rows.json>      # append rows; rows is a JSON list of dicts keyed by header text
    python3 workbook.py question <map.xlsx> <sheet> <row_id> "<question>" "<what was seen>"
    python3 workbook.py check  <map.xlsx>                          # referential check: every ID used on a join sheet exists

Rules enforced here, so the caller does not have to remember them:
  * Never writes into a formula column (green). If a row dict contains one, it is ignored with a warning.
  * Never overwrites an existing row. Append only. Edits are a human's job.
  * Never duplicates: a row with the same name (entity sheets) or the same ID pair (join sheets) is
    skipped and the existing row reported, so running twice on the same files is safe.
  * IDs are assigned by next_id() unless the caller supplies one that does not collide.
  * Every appended row gets Source and Confidence; if the caller omits Confidence it is set to "Guessed",
    which is deliberately the worst value so it cannot pass unnoticed.
  * Dropdown columns are validated against the sheet's own allowed lists; a bad value becomes a Question
    instead of a cell.
"""
import json, sys, re, datetime
from openpyxl import load_workbook
from openpyxl.styles import Font

HEADER_ROW = 4
FIRST_ROW = 5
FORMULA_GREEN = "FF1E7B3A"
ID_PREFIX = {"Products": "P", "Metrics": "M", "Tables": "T", "Fields": "F", "Populations": "POP", "Dimensions": "D", "Questions": "Q"}
JOIN_SHEETS = {"Metric to Product": [("Metric ID", "Metrics"), ("Product ID", "Products")],
               "Metric to Field": [("Metric ID", "Metrics"), ("Field ID", "Fields")],
               "Dimension usage": [("Product ID", "Products"), ("Dimension ID", "Dimensions"), ("Mapping source table ID", "Tables")]}
FK_COLS = {"Metrics": [("Population ID", "Populations")], "Fields": [("Table ID", "Tables")], "Dimensions": [("Agreed source table ID", "Tables")]}


def headers(ws):
    return {ws.cell(row=HEADER_ROW, column=c).value: c for c in range(1, ws.max_column + 1) if ws.cell(row=HEADER_ROW, column=c).value}


def is_formula_col(ws, col):
    cell = ws.cell(row=FIRST_ROW, column=col)
    v = cell.value
    if isinstance(v, str) and v.startswith("="):
        return True
    return (cell.font and cell.font.color and cell.font.color.rgb == FORMULA_GREEN)


def is_helper_col(ws, col):
    h = ws.cell(row=HEADER_ROW, column=col).value
    return isinstance(h, str) and h.startswith("h_")


def allowed_values(ws, col):
    letter = ws.cell(row=FIRST_ROW, column=col).column_letter
    for dv in ws.data_validations.dataValidation:
        if dv.type != "list":
            continue
        for rng in str(dv.sqref).split():
            if rng.split(":")[0].rstrip("0123456789") == letter:
                f = dv.formula1 or ""
                if f.startswith('"'):
                    return [x.strip() for x in f.strip('"').split(",")]
    return None


def rows(ws):
    hs = headers(ws); idcol = 1
    out = []
    for r in range(FIRST_ROW, ws.max_row + 1):
        if ws.cell(row=r, column=idcol).value in (None, ""):
            continue
        row = {}
        for h, c in hs.items():
            if is_helper_col(ws, c):
                continue
            v = ws.cell(row=r, column=c).value
            if isinstance(v, str) and v.startswith("="):
                v = None  # formula, value not cached here
            row[h] = v
        row["_row"] = r; out.append(row)
    return out


def first_empty_row(ws):
    r = FIRST_ROW
    while ws.cell(row=r, column=1).value not in (None, ""):
        r += 1
    return r


def next_id(ws, sheet):
    prefix = ID_PREFIX.get(sheet)
    if not prefix:
        return None
    mx = 0
    for r in range(FIRST_ROW, ws.max_row + 1):
        v = ws.cell(row=r, column=1).value
        if isinstance(v, str):
            m = re.fullmatch(prefix + r"-(\d+)", v.strip())
            if m: mx = max(mx, int(m.group(1)))
    return f"{prefix}-{mx + 1:03d}"


def existing_ids(wb, sheet):
    ws = wb[sheet]
    return {ws.cell(row=r, column=1).value for r in range(FIRST_ROW, ws.max_row + 1) if ws.cell(row=r, column=1).value}


def add_question(wb, sheet, row_id, question, seen, raised_on=None):
    ws = wb["Questions"]; hs = headers(ws); r = first_empty_row(ws)
    qid = next_id(ws, "Questions")
    vals = {"Question ID": qid, "Raised on": raised_on or datetime.date.today().isoformat(), "Sheet": sheet, "Row ID": row_id,
            "Question": question, "What was seen": seen, "Status": "Open"}
    for h, v in vals.items():
        if h in hs: ws.cell(row=r, column=hs[h], value=v)
    return qid


NAME_COL = {"Products": "Product name", "Metrics": "Metric name", "Tables": "Table name", "Fields": "Field name", "Dimensions": "Dimension name", "Populations": "Population name"}


def find_duplicate(ws, sheet, nr, hs):
    """Same name (case-insensitive) on an entity sheet, or same key pair on a join sheet -> existing row number, else None."""
    if sheet in NAME_COL:
        name = (nr.get(NAME_COL[sheet]) or "").strip().lower()
        if not name: return None
        c = hs.get(NAME_COL[sheet])
        for r in range(FIRST_ROW, ws.max_row + 1):
            v = ws.cell(row=r, column=c).value
            if isinstance(v, str) and v.strip().lower() == name and ws.cell(row=r, column=1).value:
                return r
    elif sheet in JOIN_SHEETS:
        keys = [fk for fk, _ in JOIN_SHEETS[sheet]][:2]
        want = tuple((nr.get(k) or "") for k in keys)
        if not all(want): return None
        for r in range(FIRST_ROW, ws.max_row + 1):
            if tuple((ws.cell(row=r, column=hs[k]).value or "") for k in keys) == want:
                return r
    return None


def append_rows(wb, sheet, new_rows, default_source=None):
    """new_rows: list of dicts keyed by header text. Returns list of (id, row_number, warnings).
    A row whose name (entity sheets) or key pair (join sheets) already exists is NOT appended; the
    existing row number is returned with a warning, so re-running on the same files cannot duplicate."""
    ws = wb[sheet]; hs = headers(ws); results = []
    id_header = ws.cell(row=HEADER_ROW, column=1).value
    for nr in new_rows:
        warnings = []
        dup = find_duplicate(ws, sheet, nr, hs)
        if dup:
            warnings.append(f"already present at row {dup} (same {'name' if sheet in NAME_COL else 'key pair'}); not appended. If this is a different thing, give it a distinguishing name and a question.")
            results.append((ws.cell(row=dup, column=1).value, dup, warnings)); continue
        r = first_empty_row(ws)
        if r > ws.max_row or ws.cell(row=r, column=1).has_style is False:
            warnings.append(f"row {r} is beyond the formatted/formula area; formulas will be missing for this row. Extend the sheet first.")
        rid = nr.get(id_header)
        if sheet in ID_PREFIX:
            if not rid or rid in existing_ids(wb, sheet):
                rid = next_id(ws, sheet)
            nr[id_header] = rid
        # foreign keys must exist; a row with a broken key is not written at all
        broken = False
        for fk, target in FK_COLS.get(sheet, []) + JOIN_SHEETS.get(sheet, []):
            v = nr.get(fk)
            if v and v not in existing_ids(wb, target):
                warnings.append(f"{fk} {v} does not exist on {target}; row NOT written, logged as a question")
                add_question(wb, sheet, rid or "", f"A row was proposed with {fk} = {v}, but no such row exists on {target}. Which {target[:-1].lower()} is meant? The row was not written.", json.dumps({k: v for k, v in nr.items() if v}, ensure_ascii=False)[:400])
                broken = True
        if broken:
            results.append((None, None, warnings)); continue
        if "Confidence" in hs and not nr.get("Confidence"):
            nr["Confidence"] = "Guessed"; warnings.append("Confidence missing; set to Guessed")
        if "Source (where found)" in hs and not nr.get("Source (where found)") and default_source:
            nr["Source (where found)"] = default_source
        for h, v in nr.items():
            if h not in hs:
                warnings.append(f"unknown column '{h}' ignored"); continue
            c = hs[h]
            if is_formula_col(ws, c) or is_helper_col(ws, c):
                if v not in (None, ""): warnings.append(f"'{h}' is a formula column; value ignored")
                continue
            allowed = allowed_values(ws, c)
            if allowed and v not in (None, "") and v not in allowed:
                add_question(wb, sheet, rid or "", f"Value '{v}' for {h} is not one of the allowed options ({', '.join(allowed)}). Which applies?", str(v))
                warnings.append(f"'{h}' value '{v}' not allowed; left blank and logged as a question"); v = None
            ws.cell(row=r, column=c, value=v)
        results.append((rid, r, warnings))
    return results


def check(wb):
    problems = []
    for sheet, fks in list(JOIN_SHEETS.items()) + list(FK_COLS.items()):
        ws = wb[sheet]; hs = headers(ws)
        for fk, target in fks:
            ids = existing_ids(wb, target)
            for r in range(FIRST_ROW, ws.max_row + 1):
                if ws.cell(row=r, column=1).value in (None, ""): continue
                v = ws.cell(row=r, column=hs[fk]).value
                if v and v not in ids: problems.append(f"{sheet} row {r}: {fk} {v} not found on {target}")
    for sheet in ID_PREFIX:
        if sheet == "Questions": continue
        seen = {}
        ws = wb[sheet]
        for r in range(FIRST_ROW, ws.max_row + 1):
            v = ws.cell(row=r, column=1).value
            if v:
                if v in seen: problems.append(f"{sheet}: duplicate ID {v} at rows {seen[v]} and {r}")
                seen[v] = r
    return problems


def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    cmd, path = sys.argv[1], sys.argv[2]
    wb = load_workbook(path)
    if cmd == "list":
        print(json.dumps(rows(wb[sys.argv[3]]), indent=2, default=str))
    elif cmd == "next-id":
        print(next_id(wb[sys.argv[3]], sys.argv[3]))
    elif cmd == "append":
        sheet = sys.argv[3]; new_rows = json.load(open(sys.argv[4]))
        res = append_rows(wb, sheet, new_rows)
        wb.save(path)
        for rid, r, w in res:
            tag = f"{sheet} row {r}: {rid}" if r else f"{sheet}: row skipped"
            if w and w[0].startswith("already present"): tag = f"{sheet}: duplicate of {rid}"
            print(tag + (f"  WARNINGS: {'; '.join(w)}" if w else ""))
    elif cmd == "question":
        qid = add_question(wb, sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6] if len(sys.argv) > 6 else "")
        wb.save(path); print(qid)
    elif cmd == "check":
        p = check(wb)
        print("\n".join(p) if p else "OK: all IDs resolve, no duplicates")
    else:
        print(__doc__); sys.exit(1)


if __name__ == "__main__":
    main()
