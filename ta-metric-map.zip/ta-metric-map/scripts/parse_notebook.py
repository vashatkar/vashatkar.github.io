#!/usr/bin/env python3
"""
Extract tables, lineage and calculated columns from Databricks notebooks and scripts.

Usage:
    python3 parse_notebook.py <file> [-o out.json]

Accepts:
  .py     Databricks notebook export ("# Databricks notebook source", cells split by "# COMMAND ----------")
          or a plain Python/PySpark script
  .ipynb  Jupyter / Databricks notebook
  .sql    Databricks SQL notebook export or a plain SQL file
  .dbc    not supported; export the notebook as .py or .ipynb first

What it reports, per cell:
  language        sql | python | other (from %sql / %python magics or file type)
  reads           tables named in FROM / JOIN, spark.table(...), spark.read.table(...), .load("...") paths
  writes          CREATE [OR REPLACE] TABLE|VIEW, INSERT INTO/OVERWRITE, MERGE INTO, saveAsTable(...), .write...path
  joins           JOIN <table> ON <condition>, because a join condition is often where a business rule hides
                  (a history table joined on a date range is an attribution rule)
  expressions     SELECT-list items written as  <expression> AS <alias>, with the raw expression text;
                  also withColumn("alias", <expr>) and df["alias"] = <expr>
  sql             the SQL text that was found, so a reviewer can check the extraction

And at the top level, de-duplicated: reads, writes, a table-level lineage list
(write -> [reads in the same cell or the cells feeding it]), and every aliased expression with the
cell it came from.

This is a text-level extractor, not a SQL parser. It will miss things in unusual syntax and may
over-collect table names in comments. Everything it returns must be read as evidence, not fact.
"""
import argparse, json, re, sys

CMD_SPLIT = re.compile(r"^# COMMAND -{5,}\s*$", re.M)
MAGIC = re.compile(r"^# MAGIC\s?(.*)$", re.M)

T = r"[`\"']?([A-Za-z_][\w$]*(?:\.[`\"']?[A-Za-z_][\w$]*[`\"']?){0,2})[`\"']?"
RE_FROM = re.compile(r"\b(?:FROM|JOIN)\s+" + T, re.I)
RE_WRITE = re.compile(r"\b(?:CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMP(?:ORARY)?\s+)?(?:TABLE|VIEW)(?:\s+IF\s+NOT\s+EXISTS)?|INSERT\s+(?:INTO|OVERWRITE)(?:\s+TABLE)?|MERGE\s+INTO)\s+" + T, re.I)
RE_SPARK_TABLE = re.compile(r"\.(?:table|read\.table)\(\s*[\"']([^\"']+)[\"']\s*\)")
RE_SAVE_AS = re.compile(r"\.saveAsTable\(\s*[\"']([^\"']+)[\"']")
RE_INSERT_INTO_PY = re.compile(r"\.insertInto\(\s*[\"']([^\"']+)[\"']")
RE_LOAD = re.compile(r"\.(?:load|csv|parquet|json)\(\s*[\"']([^\"']+)[\"']")
RE_SPARK_SQL = re.compile(r"spark\.sql\(\s*(f?)(\"\"\"|'''|\"|')(.*?)\2", re.S)
RE_WITHCOL = re.compile(r"\.withColumn\(\s*[\"']([^\"']+)[\"']\s*,\s*(.+?)\)\s*(?=\.|\n|$)", re.S)
RE_ASSIGN = re.compile(r"(\w+)\[\s*[\"']([^\"']+)[\"']\s*\]\s*=\s*(.+)")
RE_AS = re.compile(r"(.+?)\s+AS\s+[`\"']?([A-Za-z_]\w*)[`\"']?\s*$", re.I | re.S)
SQL_KEYWORDS = {"select", "from", "where", "and", "or", "on", "as", "join", "left", "right", "inner", "outer", "group", "by", "order", "having", "with", "union", "all", "values", "lateral", "cross", "full"}


def split_select_list(sql):
    """Return the items of every SELECT list in sql (CTEs and the outer query), respecting parentheses."""
    out = []
    for m in re.finditer(r"\bSELECT\b(.*?)\bFROM\b", sql, re.I | re.S):
        body = m.group(1); items, depth, cur = [], 0, []
        for ch in body:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                items.append("".join(cur).strip()); cur = []
            else:
                cur.append(ch)
        if cur: items.append("".join(cur).strip())
        out += [i for i in items if i and i.lower() not in ("distinct", "*")]
    return out


RE_JOIN_ON = re.compile(r"\bJOIN\s+" + T + r"(?:\s+(?:AS\s+)?\w+)?\s+ON\s+(.+?)(?=\bLEFT\b|\bRIGHT\b|\bINNER\b|\bFULL\b|\bJOIN\b|\bWHERE\b|\bGROUP\b|\)\s*$|\)\s*SELECT|$)", re.I | re.S)


def joins_in_sql(sql):
    return [{"table": m.group(1), "on": re.sub(r"\s+", " ", m.group(2).strip())} for m in RE_JOIN_ON.finditer(sql)]


def expressions_from_sql(sql):
    out = []
    for item in split_select_list(sql):
        m = RE_AS.match(item)
        if m:
            expr, alias = m.group(1).strip(), m.group(2)
            if expr != alias and not re.fullmatch(r"[\w.`\"]+", expr):
                out.append({"alias": alias, "expression": re.sub(r"\s+", " ", expr)})
            elif expr != alias:
                out.append({"alias": alias, "expression": expr, "rename_only": True})
    return out


def tables_in_sql(sql):
    reads = [m.group(1) for m in RE_FROM.finditer(sql) if m.group(1).lower() not in SQL_KEYWORDS and not m.group(1).startswith("(")]
    writes = [m.group(1) for m in RE_WRITE.finditer(sql)]
    # CTE names are not tables
    ctes = set(re.findall(r"\b(\w+)\s+AS\s*\(", sql, re.I))
    reads = [r for r in reads if r not in ctes and r.lower() not in ctes]
    return reads, writes


def analyse_cell(text, language):
    cell = {"language": language, "reads": [], "writes": [], "expressions": [], "joins": [], "sql": []}
    sqls = []
    if language == "sql":
        sqls.append(text)
    else:
        for m in RE_SPARK_SQL.finditer(text):
            sqls.append(m.group(3))
        cell["reads"] += RE_SPARK_TABLE.findall(text) + RE_LOAD.findall(text)
        cell["writes"] += RE_SAVE_AS.findall(text) + RE_INSERT_INTO_PY.findall(text)
        for m in RE_WITHCOL.finditer(text):
            cell["expressions"].append({"alias": m.group(1), "expression": re.sub(r"\s+", " ", m.group(2).strip())})
        for line in text.splitlines():
            m = RE_ASSIGN.match(line.strip())
            if m and not line.strip().startswith("#"):
                cell["expressions"].append({"alias": m.group(2), "expression": m.group(3).strip()})
    for s in sqls:
        r, w = tables_in_sql(s)
        cell["reads"] += r; cell["writes"] += w; cell["expressions"] += expressions_from_sql(s); cell["joins"] += joins_in_sql(s); cell["sql"].append(s.strip())
    cell["reads"] = sorted(set(cell["reads"])); cell["writes"] = sorted(set(cell["writes"]))
    return cell


def cells_from_py(text):
    if "# Databricks notebook source" in text or CMD_SPLIT.search(text):
        parts = CMD_SPLIT.split(text)
        out = []
        for p in parts:
            magics = MAGIC.findall(p)
            if magics:
                body = "\n".join(magics)
                lang = "sql" if body.lstrip().startswith("%sql") else ("python" if body.lstrip().startswith("%python") else "other")
                body = re.sub(r"^%\w+\s*", "", body.lstrip(), count=1)
                out.append((lang, body))
            else:
                out.append(("python", p))
        return out
    return [("python", text)]


def cells_from_ipynb(path):
    nb = json.load(open(path))
    out = []
    for c in nb.get("cells", []):
        if c.get("cell_type") != "code":
            continue
        src = "".join(c.get("source", []))
        first = src.lstrip().split("\n", 1)[0] if src.strip() else ""
        if first.startswith("%sql") or first.startswith("%%sql"):
            out.append(("sql", src.split("\n", 1)[1] if "\n" in src else ""))
        else:
            out.append(("python", src))
    return out


def cells_from_sql_file(text):
    if "-- Databricks notebook source" in text or re.search(r"^-- COMMAND -{5,}", text, re.M):
        parts = re.split(r"^-- COMMAND -{5,}\s*$", text, flags=re.M)
        return [("sql", p) for p in parts if p.strip()]
    return [("sql", text)]


def parse(path):
    low = path.lower()
    if low.endswith(".ipynb"):
        cells = cells_from_ipynb(path)
    elif low.endswith(".py"):
        cells = cells_from_py(open(path, encoding="utf-8", errors="replace").read())
    elif low.endswith(".sql"):
        cells = cells_from_sql_file(open(path, encoding="utf-8", errors="replace").read())
    elif low.endswith(".dbc"):
        raise SystemExit(".dbc archives are not supported; export the notebook as .py or .ipynb")
    else:
        raise SystemExit(f"unsupported file type: {path}")
    out = {"file": path, "cells": [], "reads": set(), "writes": set(), "lineage": [], "expressions": []}
    for i, (lang, body) in enumerate(cells):
        if not body.strip():
            continue
        c = analyse_cell(body, lang); c["index"] = i
        out["cells"].append(c)
        out["reads"].update(c["reads"]); out["writes"].update(c["writes"])
        for w in c["writes"]:
            out["lineage"].append({"writes": w, "reads": c["reads"], "cell": i})
        for e in c["expressions"]:
            out["expressions"].append(dict(e, cell=i, written_to=c["writes"][0] if c["writes"] else None))
    out["reads"] = sorted(out["reads"]); out["writes"] = sorted(out["writes"])
    if not out["reads"] and not out["writes"]:
        out["notes"] = ["No tables found. If this notebook reads via a connector or widgets, the table names may be in parameters; ask."]
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out")
    a = ap.parse_args()
    d = parse(a.path); js = json.dumps(d, indent=2)
    if a.out:
        open(a.out, "w").write(js); print(f"wrote {a.out}: {len(d['cells'])} cells, reads {len(d['reads'])}, writes {len(d['writes'])}, {len(d['expressions'])} aliased expressions")
    else:
        print(js)


if __name__ == "__main__":
    main()
