# SIOP Leading Edge Consortium 2026: Shaping the Future of People Analytics
Sept 30 – Oct 1, 2026 · Baltimore, MD

Presenter materials from the SIOP LEC Resources page, organized by program track.
File names follow: **Presenter – Title**.

| Folder | Contents |
|---|---|
| 01 Opening Session and Keynote | Co-chairs' welcome (Oki & Dmytriw); keynote by Herman Aguinis plus two companion articles |
| 02 Impact | Akosile, Spencer, Cameron, Channa (PROPEL model, white paper, dashboards) |
| 03 Interactive Sessions 1 | Fink (Future of Work), McNulty (causal evidence), Stanley (governing AI agents) |
| 04 Interactive Sessions 2 | Bazigos, Napper, Lisk, Nesbitt (activity files and slides) |
| 05 Influence | Higher-ed stakeholder complexity, Complexity Compass, military / Space Force analytics |
| 06 Integrity | Ross, Waber, Saling, Rupayana & Lobuglio (governance and ethics) |
| 07 Innovation | Pierce, Pak, Samo, Lisk (novel methods and tools) |
| 08 Closing Keynote | Angela Cheng-Cimini, Beyond the Dashboard |
| 09 Posters | Poster PDFs; multi-file posters (Mannion, Cameron) have their own subfolders |

## Sessions with no files posted
- Kristin Saboe – Maintaining User Centricity while Pursuing Workforce Intelligence
- Matthew J. Monnot – The AI Paradox (SIOP's link points to another presenter's poster)
- Willford, Callan & Schultz – People Analytics in the Age of AI (poster)

## Related online resources (links only)
- Keith McNulty – Handbook of Regression Modeling in People Analytics: https://peopleanalytics-regression-book.org/causal_inference.html
- Statistical Rethinking 2026 (YouTube): https://www.youtube.com/playlist?list=PLDcUM9US4XdNOlqSyhe38US8mFgmqzI14
- Jason Stanley – Governance as a Learning Signal: https://jasonstanley.substack.com/p/governance-as-a-learning-signal
- Timothy Lisk – Activity: Redesign an I-O Workflow with AI: https://stardustvault.com/sioplec2026/#/conference

Source: siop.org › Events › Leading Edge Consortium › Shaping the Future of People Analytics › Program › Resources (SIOP member content).
