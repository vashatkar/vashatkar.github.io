# Databricks notebook source
# Owner: Team Opportunity. Runs weekdays 06:00 ET via workflow ta_daily_scorecard.
# MAGIC %md
# MAGIC # Scorecard metrics build

# COMMAND ----------

# MAGIC %run ./helpers

# COMMAND ----------

reqs = spark.table("hrdw.requisition")
offers = spark.read.table("hrdw.offer")
link = spark.table("ta_custom.req_linkage")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE ta_rpt.scorecard_base AS
# MAGIC WITH base AS (
# MAGIC   SELECT r.req_id, COALESCE(l.original_req_id, r.req_id) AS canonical_req_id,
# MAGIC          r.approved_dt, r.posted_dt, r.is_evergreen, r.hiring_org,
# MAGIC          o.offer_id, o.accepted_dt, o.start_dt,
# MAGIC          h.owner_id AS credited_recruiter
# MAGIC   FROM hrdw.requisition r
# MAGIC   LEFT JOIN ta_custom.req_linkage l ON l.req_id = r.req_id
# MAGIC   LEFT JOIN hrdw.offer o ON o.req_id = r.req_id
# MAGIC   LEFT JOIN hrdw.requisition_history h ON h.req_id = r.req_id AND o.accepted_dt BETWEEN h.valid_from AND h.valid_to
# MAGIC )
# MAGIC SELECT *,
# MAGIC        DATEDIFF(accepted_dt, approved_dt) AS cycle_time_days,
# MAGIC        CASE WHEN is_evergreen THEN 0 ELSE 1 END AS counts_for_ttf
# MAGIC FROM base

# COMMAND ----------

df = spark.sql("SELECT canonical_req_id, COUNT(DISTINCT offer_id) AS hires FROM ta_rpt.scorecard_base GROUP BY canonical_req_id")
df = df.withColumn("hires_per_req", F.col("hires") / F.lit(1))
df.write.mode("overwrite").saveAsTable("ta_rpt.hires_by_req")

# COMMAND ----------

dbutils.widgets.text("schema", "ta_rpt")
schema = dbutils.widgets.get("schema")
snap = spark.table(f"{schema}.req_snapshot")
pdf = spark.table("ta_rpt.hires_by_req").toPandas()
pdf.to_excel("/dbfs/FileStore/ta/scorecard_input.xlsx", sheet_name="Data", index=False)
