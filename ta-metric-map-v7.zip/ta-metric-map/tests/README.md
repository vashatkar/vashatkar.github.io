# Self-test

Before running the skill on real files, prove the scripts work here:

    python3 scripts/parse_twb.py tests/sample_scorecard.twb -o /tmp/sample.json
    cp template/TA_Metric_Map_v7.xlsx /tmp/map.xlsx
    python3 scripts/workbook.py check /tmp/map.xlsx

Expected from the parser: 1 datasource reading TA_RPT.SCORECARD_BASE, three calculated
fields (two captioned "Cycle Time" with different formulas, one "Hires"), three worksheets
(Eng, Finance, Pipeline), one dashboard. The two "Cycle Time" formulas are the deduplication
case in extraction-rules.md: same caption, different formula, so two Metrics rows in one
family plus a Question.

Notebook parser:

    python3 scripts/parse_notebook.py tests/sample_notebook.py

Expected: reads hrdw.requisition, hrdw.offer, hrdw.requisition_history, ta_custom.req_linkage,
ta_rpt.scorecard_base, ta_rpt.hires_by_req; writes ta_rpt.scorecard_base and ta_rpt.hires_by_req;
six aliased expressions including cycle_time_days and counts_for_ttf; a join on
requisition_history with a BETWEEN condition, which is the recruiter-credit rule.

Also expected from the added keys:
  header_comments    one line: "Owner: Team Opportunity. Runs weekdays 06:00 ET via workflow ta_daily_scorecard."
  runs               one entry, kind "%run", path "./helpers" (cell 1)
  widgets            one entry, name "schema", default "ta_rpt"
  unresolved_tables  one entry, expression f"{schema}.req_snapshot" from .table in the last cell;
                     it is NOT in reads, and the matching question names the widget and its default
  file_writes        one entry: path /dbfs/FileStore/ta/scorecard_input.xlsx, format xlsx,
                     sheet_name "Data", call .to_excel
  questions          two: the runtime-named table, and "./helpers must be parsed separately"

Scorecard workbook parser:

    python3 scripts/parse_xlsx.py tests/sample_scorecard.xlsx

The fixture is a Data tab (60 rows, 7 snake_case columns: req_id, org, month, hires,
offers_extended, cycle_time_days, source), two scorecard tabs Eng and Finance with the same five
labels and month columns Jul/Aug/Sep, one comment on Eng!B7, a named range Data_Hires, and a
hidden Scratch sheet. Expected:
  sheets      Data = "data dump" (header_row 1, 7 columns); Eng and Finance = "scorecard"
              (12 formulas each, header_row 2); Scratch = "hidden", read_by_visible_formulas []
  metrics     exactly 5, each with where listing 6 cells and tabs ["Eng", "Finance"]:
                Hires                  formula, SUMIFS over the named range Data_Hires
                                       (names_used {"Data_Hires": "Data!$D:$D"}; reads_labels say org / month / hires)
                Offers extended        formula, SUMIFS, unit_hint unknown
                Offer accept rate      formula, shape R[-2]C[0]/R[-1]C[0], unit_hint percent,
                                       reads_labels resolve B3 to "Hires / Jul" etc.
                Avg cycle time (days)  formula, AVERAGEIFS, unit_hint days
                Open reqs              "pasted value", cached [120,131,128,135,146,143],
                                       comments [["Eng!B7", "pasted from notebook run 2026-10-01"]]
              The org literal ("Eng"/"Finance") appears in the shape as "<sheet>" and the month
              literal as "<period>" with parameters.period.values {Jul: 2026-07, Aug: 2026-08,
              Sep: 2026-09}: three months x two tabs collapse into one metric, not six or fifteen.
  tables      one entry for Data, listobject null, kind_guess "Script output" (snake_case headers)
  questions   four: formula cells never calculated (one per scorecard tab, because openpyxl writes
              no cached values), hidden Scratch not read by any formula, and "what writes Data?".
              No question about Open reqs, because one of its cells carries a comment.

Manifest proposer:

    python3 scripts/propose_manifest.py <any folder containing tests/>

Job definition and incidents log (used by Pass 2b and Pass 5c):

    tests/sample_job.json        a Databricks workflow: weekdays 06:00 ET, owner, failure email, runs sample_notebook
    tests/sample_incidents.csv   five reported problems; two are the same symptom (recurring), one fix is "Fixed" with no detail (Root stage Unknown + a question)

Expected rows: one Jobs row (Trigger Scheduled, Failure notice "email to ta-data-alerts@"), five
Incidents rows with Root stages Manual step, Platform to HRDW, Manual step, Inside the dashboard,
Unknown.
