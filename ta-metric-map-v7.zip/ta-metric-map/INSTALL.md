# Install and first run

## Install the skill

Unzip so that the folder is named `ta-metric-map` and sits in one of:

- `~/.claude/skills/ta-metric-map/` for your own use on this machine, or
- `<project>/.claude/skills/ta-metric-map/` inside a repo, so anyone who clones it gets the skill.

Claude Code lists it as `ta-metric-map`. Nothing else to register.

## Dependency

The scripts need Python 3.9+ and one package:

    pip install openpyxl

Nothing else; the Tableau and notebook parsers use the standard library.

## Self-test (do this once per machine)

    cd <skill folder>
    python3 scripts/parse_twb.py tests/sample_scorecard.twb | head -40
    python3 scripts/parse_notebook.py tests/sample_notebook.py | head -40
    python3 scripts/parse_xlsx.py tests/sample_scorecard.xlsx | head -40
    cp template/TA_Metric_Map_v7.xlsx /tmp/map.xlsx
    python3 scripts/workbook.py check /tmp/map.xlsx

All four should run without errors; `check` prints "OK".

## First real run

1. Make a source folder with `tableau/`, `notebooks/`, `sql/`, `jobs/`, `incidents/`, `decks/`, `docs/` and drop the files in. Job definitions (Databricks workflow exports, DAGs) are what give refresh cadence and the manual/automated split; an incidents log (tickets, an issues sheet) is what gives root cause by stage. Both are optional but the diagnosis is thin without them.
2. Copy `template/TA_Metric_Map_v7.xlsx` from the skill folder next to it. Always work on a copy; the template stays empty.
3. Open Claude Code in that folder and say:
   "Use the ta-metric-map skill to fill TA_Metric_Map_v7.xlsx from the files in this folder."
4. It drafts the manifest first and waits for you to fill product names and the schema columns.
5. It then runs pass by pass and stops after each. Read the Questions sheet as it fills.

To read the result: the Decisions sheet, `analysis.md` from `scripts/analyze.py`, and a product card from `scripts/workbook.py card`. The web front end comes after the back end is proven on real files; the v6 site builder is parked in `scripts/deferred/`.

Running it again on the same files is safe: rows that already exist are skipped, not duplicated.

## What the workbook needs

Excel (desktop) for the Decisions sheet's click-through links and hover notes. Google Sheets
and LibreOffice open it and compute everything, but may not follow the in-sheet links.
