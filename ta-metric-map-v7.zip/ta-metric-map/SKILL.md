---
name: ta-metric-map
description: Fill and self-check the TA metric map workbook (TA_Metric_Map_v7.xlsx) from Excel scorecards, Tableau workbooks, Databricks notebooks, SQL, job definitions and decks. Builds the linked inventory platform -> table -> script -> metric -> product with every link shown as a name, proposes everything except Disposition, then reviews its own output with an independent reviewer before a person sees it, and analyses duplicates, automation and root causes. Use when asked to inventory TA dashboards, metrics, tables, fields or scripts, run the metric audit, find duplicate metrics or products, or populate or extend the metric map.
---

# TA metric map: filling and checking the workbook

You are filling one linked inventory of what exists today in talent-acquisition reporting:
**Platforms** (where data is born) → **Tables** (warehouse, custom, shared, hand-kept) →
**Scripts** (what reads and writes them, when, started by whom) → **Metrics** (one row per
definition, with the **Fields** they read) → **Products** (what people look at, and what each
reads directly). People will validate it row by row and then decide what to keep, fix, merge or
retire. Their end goal: one definition per metric, one table per subject, fewer products.

Four rules override everything else here:

1. **Propose everything except Disposition.** Fill every cell you have a reading for, including
   the judgement ones (why a table exists, who owns it, root stage). Every row you write carries
   `Review = Proposed`; cells you could only infer carry `Confidence = Proposed` or `Inferred` with
   the evidence in Notes. A person flips Review to Accepted, Corrected or Rejected. Disposition,
   the Decision log, and Platform on source tables are theirs. A blank cell is allowed only when
   you have nothing to go on; then a Questions row.
2. **Names, never codes.** Every link you write is a Short name, Metric name or Field name. The
   tools maintain the grey ID columns. If you catch yourself typing `T-004`, stop.
3. **Every cell is a plain sentence** a new analyst could read cold (`writing-style.md`). The
   metric family is the business question the metric answers, from the Families sheet, exactly.
4. **Nothing reaches a person unchecked.** After extraction, the mechanical checker and an
   independent reviewer run over every sheet; you fix what they find or turn it into a Question.
   Then stop and show the result.

## Before you start

First time on this machine: `INSTALL.md` (`pip install openpyxl`, then the self-test).

Read, in this order: `references/schema.md` (every sheet and column, who fills it),
`references/extraction-rules.md` (how each file kind becomes rows; the append order that avoids
broken links), `references/families.md`, `references/writing-style.md`,
`references/manifest.md`, `references/review-prompt.md`.

Check the inputs:

- The workbook, `TA_Metric_Map_v7.xlsx` or later. `python3 scripts/workbook.py check <map.xlsx>`
  must print OK; if it reports that headers differ from `schema.json`, stop and ask.
- The source folder and its `manifest.csv`. Every file you read must be in the manifest. Unlisted
  file: ask before reading. Listed but missing: report, do not go looking.
- Excel products come as `.xlsx` (not PDF or screenshots). Tableau as `.twb`/`.twbx`. Databricks
  notebooks exported as `.py`, `.ipynb` or `.sql` (not `.dbc`). Job definitions as the workflow
  JSON or DAG file.

Never edit a row whose Review is Accepted or Corrected; `workbook.py` refuses, and `fill` turns a
conflict into a Question. Re-running on the same files is safe: duplicates are skipped by name.

## Working with the workbook

Only through `scripts/workbook.py`; never with openpyxl directly. Prepare each batch as JSON
keyed by the exact header text, with names in every link column, and call `append`. After every
batch: `sync` (resolves names to the grey IDs and rebuilds the derived name columns: Built by,
Refresh mechanism, Reads from, Fed by scripts, Reads from tables) and `check`.

- `append` skips duplicates, resolves names, refuses a row whose link does not exist (Question
  instead), drops any Disposition, sets Review and Confidence to Proposed when missing.
- `fill <sheet> "<column>" by_name.json --source "..."` writes only blank cells or Proposed rows;
  a different value on a validated row becomes a Question. Use it for lineage backfill.
- `set` overwrites, but refuses validated rows without `--force`. Use it only to apply reviewer
  repairs.
- `question <sheet> <name> "<question>" "<what was seen>"`.
- `merge Metrics <keep> <merge...>` folds duplicate metrics and re-points the join rows.
- `card <product name>` writes a one-page product card.

Source (where found) must be specific enough for the reviewer to find the region:
`<file> cell N` for notebooks; `<file> tabs Eng, Finance, label Hires` for Excel products;
`<file> worksheet X, field Y` for Tableau. The reviewer only sees what that string locates.

## The passes

Run in order. After each, write a short summary (rows added per sheet, skipped, questions
raised), save, and stop until the person says continue.

### Pass 0a: draft the manifest if there is none

`python3 scripts/propose_manifest.py <folder>` writes a draft: kind per file, and for each
file what it contains. Show it; the person fills `product_name` (an .xlsx with a product name is
a product; without one it is a hand-kept table), the schema columns and confirms each row. Do not
proceed before that.

### Pass 0: plan

`workbook.py check`. List the files in manifest order and which pass each feeds. Parse everything
now into `parsed/<file>.json` with `parse_xlsx.py`, `parse_twb.py`, `parse_notebook.py`; read
every `questions` list the parsers return and keep them for the passes. Ask about anything
unclear (two files that look like versions of one product, a notebook that `%run`s something not
in the manifest). Stop.

### Pass 1: Platforms, Products, Tables, Scripts (the chain)

In this order, so links resolve:

1. **Platforms**: none from files. Leave the sheet for the person; mention it in the summary.
2. **Tables**: every table or file any source reads or writes, per `extraction-rules.md`. Short
   name, Full name, Kind (by the manifest's schema lists; Script output file for files notebooks
   write; Manual spreadsheet for hand-kept files; blank plus a Question otherwise), Built from as
   names, main parent first. Propose Why it exists only when a comment, README or the name says
   it; quote it in Notes.
3. **Scripts**: one row per notebook, SQL file, workflow, and per manual step a file or note
   describes (Kind Manual process). Reads, Writes, Feeds as names; Trigger, Schedule, Who runs it,
   Failure notice from job definitions and header comments; "Unknown" and a Question otherwise.
4. **Products**: one row per product in the manifest. Short name, Full name, Type, Tool,
   Refresh frequency when a schedule or extract setting shows it; propose Audience and Owner
   from the file's title block, footer or job owner, labelled. Leave Last hop, Automation level
   and Manual effort blank: those are the analyst's three cells. Propose Manual steps when a
   comment or manifest note describes one.
5. **Product inputs**: one row per table or file each product reads directly (data tabs,
   external links, datasources), with How it gets in.

Then `sync` and `check`. Show the Tables list with their lineage chains (names) and the Scripts
grouped by Trigger, Manual run and Unknown first. Stop.

### Pass 2: Metrics, Fields and the two join sheets

Raw Fields first, then Derived (Derived from must resolve), then Metrics, then Metric to Field
and Metric to Product.

Before every Metrics row, three checks: already there (same name and definition, even on a
different tab: add the tab to the existing Metric to Product row's How it is shown)? a subset of an
existing metric (an org, a level, "(external)": same metric; the cut is a Dimension usage, the
subset goes in Who is counted)? which family (from the Families sheet, by reading the
definition)? Same name with a different formula = two rows in one family with bracketed names
and a Question. Different name, same formula = one row, the other name in Notes, a Question which
is official. Pasted scorecard numbers get Definition blank, a Question "where is it computed?",
and a notebook match attempt per the matching table in `extraction-rules.md`.

Who is counted and Who is left out: from the formula's filters and the notebook's WHERE and
CASE clauses, in words. A filter that looks like a population rule is worth a Question asking
whether it is intended.

Where the rule lives on Derived fields: "Inside the product" for Tableau calculations and
scorecard formulas, "In a script" for notebook expressions. That column is what the architecture
work moves.

`sync`, `check`. Show Metrics grouped by family, families with more than one definition first,
and the Decisions sheet's metric counts. Stop.

### Pass 3: Dimensions and Dimension usage

From filters and headers on worksheets and scorecard tabs (org, level, location, recruiter,
month). One Dimensions row per cut; one Dimension usage row per product per cut with the Mapping
source table the cut traces to. Agreed source table is a decision; leave it. `sync`, `check`.
Show usages whose products map the same cut from different tables. Stop.

### Pass 4: Self-check (every sheet, every column)

1. `python3 scripts/check_quality.py <map.xlsx> -o findings.json --batches review/`. Fix every
   `auto: true` finding with `set` (full stops, capitalisation, a code replaced by its name).
   Fix every other error you can fix from the files yourself (a family that is a name fragment,
   a formula paraphrase that needs rewriting in words, a missing Source). Re-run until only
   findings that need evidence you do not have remain.
2. `python3 scripts/review_tools.py excerpts <map.xlsx> parsed/ -o excerpts.json`.
3. For each batch file in `review/`, spawn an independent reviewer: the Agent tool,
   `subagent_type: general-purpose`, prompt = the text between the rules in
   `references/review-prompt.md` with the three paths filled in, asking it to write its JSON list
   to `review/<batch>.verdicts.json`. Run batches in parallel. It is a fresh context: it sees
   only the rows, the findings and the excerpts, never your reasoning. That is the point.
4. `python3 scripts/review_tools.py apply <map.xlsx> review/<batch>.json review/<batch>.verdicts.json excerpts.json --log selfcheck_log.jsonl`
   for each. The guards are in the script: only Proposed rows, only the allowed columns,
   evidence must be a quote from the excerpt, a cell repaired twice is frozen and questioned.
5. `sync`, `check`, then `check_quality.py` again. Loop from step 3 on the batches that still
   have findings or had repairs, at most three rounds; after that every remaining finding becomes
   a Question.

Show: findings before and after, repairs applied (from the log), questions raised. Stop.

### Pass 5: Analysis

`python3 scripts/analyze.py <map.xlsx> -o analysis.json --md analysis.md`. Reads the saved
workbook, writes nothing to it: the front-page counts (metrics total, distinct, same definition
under two names, families with more than one definition, same metric from different tables;
tables total, stacked, hand-kept, no builder; products by automation level derived from the chain
against what is recorded, pasted by hand; scripts run by hand, nobody told), metric and product
overlap pairs with a verdict in words, automation per product with low-hanging score, incidents
by root stage, and the validation queue ranked by products reached. Show `analysis.md`. Do not act
on it; merges and dispositions are the person's. Stop.

### Pass 6: Reconcile and hand over

`workbook.py check`. Summarise: rows per sheet, rows awaiting review per sheet, open Questions,
manifest files not processed and why, the three analyst cells still to fill on each product,
Platforms still blank. Point the person at the Decisions sheet. Stop.

### Product cards and the diagnosis draft (when asked)

`workbook.py card "<product>" cards/<product>.md` for one product. A diagnosis draft, only after
the queue is validated: four chapters (where data problems come from; are the metrics right and
defined once; which products and metrics duplicate each other; ownership, refresh and manual
work), each claim followed by the row names it rests on, nothing beyond what the rows show.

## Confidence and Review

Confidence is about the cell: Found (read from a file), Inferred (deduced from more than one
file or a naming pattern; say how in Notes), Proposed (your best reading where nothing states it;
always with Notes), Human (never yours). Review is about the row: every row you write is Proposed.

## When to ask

A Questions row, next to the proposal the evidence favours, when: two sources disagree; a
dropdown value fits nothing; a table's kind is not clear from its schema; a name in a link does
not exist; a manifest entry is ambiguous or a file will not parse; a notebook names a table at
runtime; a scorecard number is pasted with nothing saying where from; anything needs intent (why
a table exists, who owns it, whether a number is right). Write it so a person who was not there
can answer in one line, with the evidence in What was seen.

## What done looks like

Every manifest file processed or questioned. Every row has a Source and Review = Proposed. No
code where a name belongs. Disposition, the Decision log and Platform untouched. `check` OK,
`check_quality.py` with no errors, the reviewer loop run, `analysis.md` written. The person can
open Decisions, read the counts, and work the validation queue.
