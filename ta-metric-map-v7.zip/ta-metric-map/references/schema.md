# Workbook schema (v7)

Header row 4, data from row 5. Generated from schema.json; edit the generator, not this file.

Every link a person reads is a **name**. Single links are a name column with a grey ID formula next to it. Multi-value links are a comma-separated names column with a grey IDs column that `workbook.py sync` maintains. Nobody types an ID.

**Who fills it**: Tool = written by workbook.py (IDs, derived name lists). Machine = the skill, from files. Propose = the skill's best labelled reading; a person accepts, corrects or rejects. Human = only a person. Formula = computed; never written.

## Platforms

Capacity 40 rows. Key: **Platform name**.

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Platform name | key name (light blue, unique) | Person only |  |
| What it holds | text | Person only |  |
| Point of contact | text | Person only |  |
| Tables fed | formula | Formula; never write |  |
| Notes | text | Person only |  |

## Families

Capacity 40 rows. Key: **Family (the question it answers)**.

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Family (the question it answers) | key name (light blue, unique) | Person only |  |
| Old name | text | Person only |  |
| What it covers | text | Person only |  |
| Example metrics | text | Person only |  |
| Metrics in family | formula | Formula; never write |  |

## Products

Capacity 150 rows. IDs `P-001`… Key: **Short name**.

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Product ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Short name | key name (light blue, unique) | Skill, from files |  |
| Full name | text | Skill, from files |  |
| Type | drop-down | Skill, from files | Scorecard, Dashboard, Sent report, Data pull, Table, Other |
| Tool | drop-down | Skill, from files | Excel, Tableau, QuickSight, Snowflake, Slides, Other |
| Audience | text | Skill proposes, person confirms |  |
| Owner (team) | text | Skill proposes, person confirms |  |
| Point of contact | text | Person only |  |
| Refresh frequency | drop-down | Skill, from files | Real time, Daily, Weekly, Monthly, Quarterly, On request, Unknown |
| Delivery cadence | text | Person only |  |
| Reads from | names list (comma-separated) | Tool (workbook.py writes it; never typed) |  |
| h_reads_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Fed by scripts | names list (comma-separated) | Tool (workbook.py writes it; never typed) |  |
| h_fed_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Last hop into the product | drop-down | Person only | Scripted, Pasted by hand, Live connection, Unknown |
| Automation level | drop-down | Person only | Automated, Partly manual, Manual, Unknown |
| Manual steps | text | Skill proposes, person confirms |  |
| Manual effort (hours per cycle) | text | Person only |  |
| Metrics shown | formula | Formula; never write |  |
| Manual spreadsheets read | formula | Formula; never write |  |
| Phase | drop-down | Person only | Phase 1, Later, Not traced, Out of scope |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |
| Last verified | text | Person only |  |
| Verified by | text | Person only |  |

## Product inputs

Capacity 500 rows. 

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Product | one name, drop-down from a sheet | Skill, from files | names on Products |
| h_product_id | ID formula (grey) | Formula; never write |  |
| Table | one name, drop-down from a sheet | Skill, from files | names on Tables |
| h_table_id | ID formula (grey) | Formula; never write |  |
| Table kind | formula | Formula; never write |  |
| How it gets in | drop-down | Skill proposes, person confirms | Scripted, Pasted by hand, Live connection, Unknown |
| Origin of this row | drop-down | Skill, from files | Derived from a script, Derived from the product file, Typed by a person |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |

## Metrics

Capacity 300 rows. IDs `M-001`… Key: **Metric name**.

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Metric ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Metric family | drop-down from a sheet | Skill, from files | names on Families |
| Metric name | key name (light blue, unique) | Skill, from files |  |
| Definition (plain words) | text | Skill, from files |  |
| Who is counted | text | Skill proposes, person confirms |  |
| Who is left out | text | Skill proposes, person confirms |  |
| Grain (one row per) | drop-down | Skill, from files | Requisition, Opening, Application, Offer, Hire, Interview, Recruiter, Other |
| Unit | drop-down | Skill, from files | Days, Count, Percent, Dollars, Other |
| Reads from tables | names list (comma-separated) | Tool (workbook.py writes it; never typed) |  |
| h_tables_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Tables read | formula | Formula; never write |  |
| Products using it | formula | Formula; never write |  |
| Fields needed | formula | Formula; never write |  |
| Definitions in family | formula | Formula; never write |  |
| Same definition elsewhere | formula | Formula; never write |  |
| Owner | text | Skill proposes, person confirms |  |
| Phase | drop-down | Person only | Phase 1, Later, Not traced, Out of scope |
| Notes | text | Skill, from files |  |
| h_defkey | helper (grey) | Formula; never write |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |
| Last verified | text | Person only |  |
| Verified by | text | Person only |  |

## Metric to Product

Capacity 600 rows. 

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| h_metric_id | ID formula (grey) | Formula; never write |  |
| h_product_id | ID formula (grey) | Formula; never write |  |
| Metric | one name, drop-down from a sheet | Skill, from files | names on Metrics |
| Product | one name, drop-down from a sheet | Skill, from files | names on Products |
| How it is shown | text | Skill, from files |  |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |

## Tables

Capacity 300 rows. IDs `T-001`… Key: **Short name**.

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Table ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Short name | key name (light blue, unique) | Skill, from files |  |
| Full name | text | Skill, from files |  |
| Kind | drop-down | Skill, from files | HRDW, Team custom, Shared (other team), Manual spreadsheet, Script output file, Platform extract, Other |
| Platform | one name, drop-down from a sheet | Person only | names on Platforms |
| Built from | names list (comma-separated) | Skill, from files |  |
| h_built_from_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Built by | names list (comma-separated) | Tool (workbook.py writes it; never typed) |  |
| h_built_by_id | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Refresh mechanism | drop-down | Tool (workbook.py writes it; never typed) | Scheduled job, Manual run, Manual spreadsheet, Live query, Unknown |
| Refresh frequency | drop-down | Skill, from files | Real time, Daily, Weekly, Monthly, Quarterly, On request, Unknown |
| Why it exists | text | Skill proposes, person confirms |  |
| Owner (team) | text | Skill proposes, person confirms |  |
| Point of contact | text | Person only |  |
| Depth | formula | Formula; never write |  |
| Lineage chain | formula | Formula; never write |  |
| Root platform | formula | Formula; never write |  |
| Fields listed | formula | Formula; never write |  |
| Metrics depending | formula | Formula; never write |  |
| Products reading it directly | formula | Formula; never write |  |
| Target layer | drop-down | Skill proposes, person confirms | Source tables, Business rules, Certified tables, Reporting |
| Disposition | drop-down | Person only | Keep as is, Build, Fix upstream, Move to business rules, Merge into certified table, Retire, Undecided |
| Phase | drop-down | Person only | Phase 1, Later, Not traced, Out of scope |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |
| Last verified | text | Person only |  |
| Verified by | text | Person only |  |
| h_p1 | helper (grey) | Formula; never write |  |
| h_p2 | helper (grey) | Formula; never write |  |
| h_p3 | helper (grey) | Formula; never write |  |
| h_p4 | helper (grey) | Formula; never write |  |

## Scripts

Capacity 300 rows. IDs `S-001`… Key: **Short name**.

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Script ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Short name | key name (light blue, unique) | Skill, from files |  |
| Kind | drop-down | Skill, from files | Databricks notebook, Databricks workflow, Airflow DAG, SQL file, SQL in dbt, Python script, Tableau extract refresh, Manual process, Other |
| Path or location | text | Skill, from files |  |
| Reads | names list (comma-separated) | Skill, from files |  |
| h_reads_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Writes | names list (comma-separated) | Skill, from files |  |
| h_writes_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Feeds | names list (comma-separated) | Skill, from files |  |
| h_feeds_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| What it does | formula | Formula; never write |  |
| Schedule | text | Skill, from files |  |
| Trigger | drop-down | Skill, from files | Scheduled, Manual run, On demand, Unknown |
| Who runs it | text | Skill proposes, person confirms |  |
| Failure notice | drop-down | Skill proposes, person confirms | Alert to team channel, Email, Nobody is told, Unknown |
| Last modified | text | Skill, from files |  |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |
| Last verified | text | Person only |  |
| Verified by | text | Person only |  |

## Fields

Capacity 700 rows. IDs `F-001`… Key: **Field name**.

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Field ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Field name | key name (light blue, unique) | Skill, from files |  |
| Table | one name, drop-down from a sheet | Skill, from files | names on Tables |
| h_table_id | ID formula (grey) | Formula; never write |  |
| Table kind | formula | Formula; never write |  |
| Type | drop-down | Skill, from files | Raw, Derived |
| Derived from | names list (comma-separated) | Skill, from files |  |
| h_derived_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Logic (the business rule) | text | Skill, from files |  |
| Where the rule lives | drop-down | Skill, from files | In a script, Inside the product, In the warehouse, Unknown |
| Data quality | drop-down | Skill proposes, person confirms | OK, Issue, Unknown |
| Root stage of issue | drop-down | Skill proposes, person confirms | Platform, Platform to HRDW, HRDW to custom table, Inside the product, Manual step, Unknown |
| Issue / note | text | Skill proposes, person confirms |  |
| Target layer | drop-down | Skill proposes, person confirms | Source tables, Business rules, Certified tables, Reporting |
| Disposition | drop-down | Person only | Keep as is, Build, Fix upstream, Move to business rules, Merge into certified table, Retire, Undecided |
| Notes | text | Skill, from files |  |
| Metrics using it | formula | Formula; never write |  |
| Products reached | formula | Formula; never write |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |
| Last verified | text | Person only |  |
| Verified by | text | Person only |  |

## Metric to Field

Capacity 900 rows. 

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| h_metric_id | ID formula (grey) | Formula; never write |  |
| h_field_id | ID formula (grey) | Formula; never write |  |
| Metric | one name, drop-down from a sheet | Skill, from files | names on Metrics |
| Field | one name, drop-down from a sheet | Skill, from files | names on Fields |
| Role in the metric | drop-down | Skill, from files | Start of clock, End of clock, Event counted, Exclusion, Attribution, Linkage, Dimension, Period (as-of date), Other |
| Table | formula | Formula; never write |  |
| h_products | helper (grey) | Formula; never write |  |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |

## Dimensions

Capacity 100 rows. IDs `D-001`… Key: **Dimension name**.

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Dimension ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Dimension name | key name (light blue, unique) | Skill, from files |  |
| Agreed source table | one name, drop-down from a sheet | Person only | names on Tables |
| h_agreed_id | ID formula (grey) | Formula; never write |  |
| Agreed source field | text | Person only |  |
| Owner | text | Person only |  |
| Products using it | formula | Formula; never write |  |
| Mappings off the agreed source | formula | Formula; never write |  |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |
| Last verified | text | Person only |  |
| Verified by | text | Person only |  |

## Dimension usage

Capacity 400 rows. 

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Product | one name, drop-down from a sheet | Skill, from files | names on Products |
| h_product_id | ID formula (grey) | Formula; never write |  |
| Dimension | one name, drop-down from a sheet | Skill, from files | names on Dimensions |
| h_dimension_id | ID formula (grey) | Formula; never write |  |
| Mapping source table | one name, drop-down from a sheet | Skill, from files | names on Tables |
| h_mapping_id | ID formula (grey) | Formula; never write |  |
| Matches agreed source? | formula | Formula; never write |  |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |

## Incidents

Capacity 500 rows. IDs `I-001`… 

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Incident ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Date | text | Skill, from files |  |
| Product | one name, drop-down from a sheet | Skill, from files | names on Products |
| h_product_id | ID formula (grey) | Formula; never write |  |
| Symptom | drop-down | Skill, from files | Wrong number, Stale, Missing, Slow, Access, Other |
| What was reported | text | Skill, from files |  |
| Root stage | drop-down | Skill proposes, person confirms | Platform, Platform to HRDW, HRDW to custom table, Inside the product, Manual step, Unknown |
| Root cause (plain words) | text | Skill proposes, person confirms |  |
| Tables or fields involved | names list (comma-separated) | Skill proposes, person confirms |  |
| h_involved_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Time to resolve (hours) | text | Skill, from files |  |
| Reported by | text | Skill, from files |  |
| Fixed by | text | Skill, from files |  |
| Recurring? | drop-down | Skill proposes, person confirms | Yes, No, Unknown |
| Notes | text | Skill, from files |  |
| Review | drop-down | Person only | Proposed, Accepted, Corrected, Rejected |
| Source (where found) | text | Skill, from files |  |
| Confidence | drop-down | Skill, from files | Found, Inferred, Proposed, Human |

## Decision log

Capacity 300 rows. IDs `DL-001`… 

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Decision ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Date | text | Person only |  |
| Decision | text | Person only |  |
| Relates to | names list (comma-separated) | Person only |  |
| h_relates_ids | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Agreed by | text | Person only |  |
| Follow-up | text | Person only |  |
| Status | drop-down | Person only | Agreed, In progress, Done, Reopened |
| Notes | text | Person only |  |

## Questions

Capacity 500 rows. IDs `Q-001`… 

| Column | Kind | Who | Allowed values / links to |
|---|---|---|---|
| Question ID | ID (grey) | Tool (workbook.py writes it; never typed) |  |
| Raised on | text | Skill, from files |  |
| Sheet | text | Skill, from files |  |
| About | names list (comma-separated) | Tool (workbook.py writes it; never typed) |  |
| h_row_id | IDs for the names list (grey, sync) | Tool (workbook.py writes it; never typed) |  |
| Question | text | Skill, from files |  |
| What was seen | text | Skill, from files |  |
| Status | drop-down | Person only | Open, Answered, Dropped |
| Answer | text | Person only |  |
| Answered by | text | Person only |  |
| Answered on | text | Person only |  |

## Families (fixed list; the Metric family cell holds the question text exactly)

| Family (question) | Old name | Covers | Examples |
|---|---|---|---|
| How much hiring is asked of us? | Requisition demand | Requisitions created or approved, hiring plan against actual. | Reqs approved; Hiring plan vs actual |
| How many openings are open right now? | Open requisitions | Open requisition counts, ageing, point-in-time snapshots. | Open reqs; Average open live reqs; Req ageing |
| How many people are in the pipeline? | Pipeline | Active candidates by stage. | Candidates in process; Pipeline by stage |
| How many apply? | Applications | Application volume and applications per requisition. | Applications; Apps per req |
| Where do candidates come from? | Source mix | Share of applicants or hires by source or channel. | % referrals; % sourced; % internal |
| How many interviews do we run? | Interview volume | Interview and results-card counts. | Interviews completed; Results cards |
| Who gets through each stage? | Conversion | Pass and conversion rates between stages. | First-round pass rate; App-to-offer conversion |
| How many offers do we make? | Offers | Offer counts. | Offers extended |
| Do candidates accept our offers? | Offer acceptance | Accepted offers over offers extended. | Offer accept rate; Accept rate by level |
| What do we offer? | Offer terms | Pay, bonus and position in range on offers. | % with sign-on; % at max of range |
| How many do we hire? | Hires | Hire counts, hires against demand. | Hires; Hires against plan |
| How long does hiring take? | Cycle time | Elapsed days between two events in the hiring process, any pair. | Approved to accepted; Posted to start; App to offer |
| Are the hires good? | Quality of hire | Early performance, hiring-manager rating. | 90-day rating; New-hire survey |
| Do our processes pass review? | QA pass rate | Requisition, offer and decline quality checks. | % passed req QA |
| Are we hiring a diverse slate? | Diversity | Representation at each stage. | % women in slate; Offer rate by group |
| How much does each recruiter carry? | Recruiter load | Load per recruiter or team. | Reqs per recruiter; Hires per recruiter |
| Do we have enough recruiters? | TA capacity | Capacity of the TA team against demand. | Capacity vs demand; Team headcount |
| What does hiring cost? | Cost | Cost per hire, agency spend, operating cost. | Cost per hire; Agency fees |
| Do our hires stay? | Early attrition | Attrition and retention of recent hires. | 90-day attrition; First-year retention |
| How is the TA organisation itself doing? | Org health | Measures about the TA team, not about the hiring flow. | Engagement; Span of control |

## Decisions, Column guide, README: read-only summaries. Never write.
