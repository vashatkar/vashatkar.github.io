# Reviewer prompt (for the independent sub-agent)

Spawn one reviewer per batch file that `check_quality.py --batches` wrote, with the Agent tool,
`subagent_type: general-purpose`. The reviewer is a fresh context: it has not seen the extraction
and must not re-extract. Give it absolute paths. Paste the text below as the prompt, filling the
three placeholders.

---

You are reviewing rows of a talent-acquisition reporting inventory that someone else extracted
from files. You have NOT seen the extraction and must not redo it. Judge only what is in front
of you: the rows, the mechanical findings attached to each, and the source excerpts.

Read these two files first; they are the rules every cell must meet:
- {SKILL_DIR}/references/writing-style.md
- {SKILL_DIR}/references/families.md

Then read the batch: {BATCH_FILE}
It is JSON: {"sheet": ..., "rows": [{...row columns..., "_row": n, "findings": [...]}]}.

Source excerpts for the rows are in: {EXCERPTS_FILE}
It is JSON keyed by the row's "Source (where found)" text, each value the text of that file
region (a formula, a notebook cell, a sheet range), at most 40 lines. If a row's source is not in
the file, you have no evidence for it.

For each row return exactly one object:

{"_row": n, "verdict": "ok" | "repair" | "question",
 "repairs": {"<column>": "<new value>"},
 "evidence": "<a quote copied from the source excerpt that supports every new value>",
 "question": "<one line a person can answer>",
 "what_was_seen": "<the conflicting or missing evidence, in one line>"}

Rules you must follow:
1. A repair value must be supported by a quote in "evidence", copied verbatim from the excerpt.
   If you cannot quote it, the verdict is "question", not "repair". This is the whole point.
2. Only these columns may be repaired: Definition (plain words), Who is counted, Who is left out,
   Metric family, Metric name, Why it exists, Logic (the business rule), Manual steps,
   How it is shown, Who runs it, Short name, Notes. Never Review, Source, Confidence, Disposition,
   any ID, any grey column, any formula column.
3. A Metric family must be one of the questions in families.md, exactly. If none fits, verdict
   "question".
4. Do not add rows. Do not merge rows yourself; if two rows look like the same metric, say so in a
   "question" verdict on both, naming the other row.
5. Every repaired text cell must pass the writing-style checklist: a plain sentence a new analyst
   could read cold, ending in a full stop, no formula syntax, no codes, no filler.
6. "ok" means you checked the row against its excerpt and every cell is right and readable. Do
   not mark "ok" a row whose source excerpt is missing; that is "question".

Return a JSON list only, no prose.

---

## How the orchestrating skill applies the result

- Parse the list. For each "repair": check the row's Review is Proposed; check that
  `evidence` is a substring of the excerpt given (mechanical; this is the anti-invention
  guard); check the column is in the allowed list; then `workbook.py set <sheet> "<column>"`
  with `{name: value}`. Append a line to `selfcheck_log.jsonl`: row, column, old, new, evidence.
- For each "question": `workbook.py question <sheet> <name> "<question>" "<what_was_seen>"`.
- A repair that fails any check becomes a question instead.
- Rows with Review Accepted or Corrected are never changed; a verdict on them becomes a question.
- Loop: `check_quality.py` → reviewers on batches with findings or repairs last round → apply →
  `sync` → `check_quality.py`. Stop when no error-severity findings remain and no repairs were
  applied this round, or after round 3, when every remaining finding becomes a Question. A cell
  repaired twice is frozen and questioned, so extractor and reviewer cannot oscillate.
