# Metric families

A family is the **business question a metric answers**. It is a classification, never a
shortening of the name. "Avg open live reqs per recruiter" is not in family "Avg open live";
it answers "How much does each recruiter carry?".

The list lives on the workbook's **Families** sheet (and in `schema.json`). The Metric family
cell holds the question text exactly as written there; the Families sheet also keeps the old
category name next to each question so nothing is lost when people rename them.

## The rule

1. Read the definition, not the name. Ask: what question does this number answer?
2. Pick the family from the list. Use the question text exactly.
3. If none fits, leave Metric family blank and raise a Question: "No family fits <name>;
   propose adding '<question>'." A person extends the Families sheet.
4. Never create a family from the first words of a name. Never invent a family.

## The list

| Family (the question) | Old name | What belongs here | Examples |
|---|---|---|---|
| How much hiring is asked of us? | Requisition demand | Requisitions created or approved, hiring plan against actual | Reqs approved; Hiring plan vs actual |
| How many openings are open right now? | Open requisitions | Open requisition counts, ageing, snapshots | Open reqs; Average open live reqs; Req ageing |
| How many people are in the pipeline? | Pipeline | Active candidates by stage | Candidates in process; Pipeline by stage |
| How many apply? | Applications | Application volume and applications per requisition | Applications; Apps per req |
| Where do candidates come from? | Source mix | Share of applicants or hires by source or channel | % referrals; % sourced; % internal |
| How many interviews do we run? | Interview volume | Interview and results-card counts | Interviews completed; Results cards |
| Who gets through each stage? | Conversion | Pass and conversion rates between stages | First-round pass rate; App-to-offer conversion |
| How many offers do we make? | Offers | Offer counts | Offers extended |
| Do candidates accept our offers? | Offer acceptance | Accepted offers over offers extended | Offer accept rate; Accept rate by level |
| What do we offer? | Offer terms | Pay, bonus and position in range on offers | % with sign-on; % at max of range |
| How many do we hire? | Hires | Hire counts, hires against demand | Hires; Hires against plan |
| How long does hiring take? | Cycle time | Elapsed days between two events in the hiring process, any pair | Approved to accepted; Posted to start; App to offer |
| Are the hires good? | Quality of hire | Early performance, hiring-manager rating | 90-day rating; New-hire survey |
| Do our processes pass review? | QA pass rate | Requisition, offer and decline quality checks | % passed req QA |
| Are we hiring a diverse slate? | Diversity | Representation at each stage | % women in slate; Offer rate by group |
| How much does each recruiter carry? | Recruiter load | Load per recruiter or team | Reqs per recruiter; Hires per recruiter |
| Do we have enough recruiters? | TA capacity | Capacity of the TA team against demand | Capacity vs demand; Team headcount |
| What does hiring cost? | Cost | Cost per hire, agency spend, operating cost | Cost per hire; Agency fees |
| Do our hires stay? | Early attrition | Attrition and retention of recent hires | 90-day attrition; First-year retention |
| How is the TA organisation itself doing? | Org health | Measures about the TA team, not the hiring flow | Engagement; Span of control |

## Variants inside a family

Same family, different rule = different Metrics rows, each named with the distinguishing part
in brackets: "Cycle time (approved to accepted)", "Cycle time (posted to start)". The
Decisions sheet counts families with more than one definition; that count is the alignment
agenda.

Same rule on a subset or a different cut (an org, a level, "(external)") = the same metric.
The cut is a Dimension usage; the subset belongs in Who is counted.
