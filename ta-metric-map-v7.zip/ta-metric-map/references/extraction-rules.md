# Extraction rules

How each kind of source becomes rows. Read `schema.md` first for the columns. Every link you
write is a **name** (Short name, Metric name, Field name); never an ID.

## Order that avoids broken links

Tables before Scripts before Fields before Metrics before the join sheets. A row that links to a
name that does not exist yet is refused and questioned, so append the things that are linked to
first. Within Fields, append Raw fields before Derived ones.

## Short names

Every table, script and product gets a Short name: two or three words a colleague would
recognise, unique on its sheet. Derive it from the full name (`ta_rpt.scorecard_base` →
"scorecard base"; `hrdw.requisition` → "HRDW requisitions"; a notebook `scorecard_v3.py` →
"scorecard notebook"). Keep it stable; it is the key everything else points at. If two sources
would get the same short name, add the distinguishing part ("scorecard base (2023)").

Field names must be unique across the Fields sheet. When two tables carry the same column, put
the table's short name in brackets: "hires (scorecard input file)".

## XLSX products (a scorecard or report that is an Excel workbook)

Run `python3 scripts/parse_xlsx.py <file.xlsx> -o <file>.json` and work from the JSON.

**Products.** One row: Short name from the manifest, Full name = the file name, Type from the
manifest (Scorecard if it says so), Tool = Excel. Notes: tab layout in one sentence ("one tab per
org with the same five labels, months across"). Refresh frequency from the manifest if given.

**Tables.** Each `tables` entry (a data-dump tab) is a Tables row: Short name "<product> data
tab" or the tab name in words, Full name = "<file> tab <name>", Kind = "Script output file"
when a notebook in the manifest writes that file or the tab's columns match a notebook's written
table, otherwise "Manual spreadsheet" plus a Question asking what writes it. External links
(`external_links`) are tables too: Kind "Manual spreadsheet" unless the manifest says otherwise,
Full name = the linked path. A connection (`connections`) names a query; the table in its
command is a Tables row with Kind by schema, and the product's Last hop is a Live connection.

**Product inputs.** One row per data-dump tab and per external link the product reads. How it
gets in: "Scripted" when a notebook writes the file; "Live connection" when a connection is
present; "Pasted by hand" when the tab has no formula, no connection and a comment or the
manifest says someone pastes it; else "Unknown" and a Question. Origin = "Derived from the
product file".

**Metrics.** One Metrics row per entry in `metrics` (the parser has already collapsed the same
label and formula shape across tabs into one). Kind "formula": Definition = the formula in
words, Notes = "Formula: <formula_example>. Appears on tabs <tabs>." and the `parameters`
(period, org) become a Dimension usage, not separate metrics. Kind "pasted value": Definition
blank, Notes = "Pasted value, no formula in the file. <comment if any>", Confidence Inferred,
and a Question: "Where is <label> computed?" Then match the label to the notebook (below).
Unit from `unit_hint`. Family from `families.md` by reading the definition.

**Fields.** For each formula metric, every range in `reads` that lands on a data-dump tab is a
Raw field on that tab's table, named by the column header (`reads_labels`), with the table's
short name in brackets if the name already exists. A formula cell that other formulas read is a
Derived field with Where the rule lives = "Inside the product". A pasted value has no fields
until the notebook match supplies them.

**Metric to Field.** One row per field a formula reads, Role: the column being summed or
averaged = "Event counted" (counts) or "Other" (amounts); a column used as a criterion = "Dimension"
when it is org/level/recruiter, "Period (as-of date)" when it is a date or month, "Exclusion"
when the criterion removes rows.

**Matching a scorecard label to a notebook column.** Normalise both: lower case, drop units in
brackets, drop "avg", "average", "total", "#", "no. of", snake_case to spaces, singular. Then:

| Match | Rule | Confidence |
|---|---|---|
| Exact | normalised label equals a notebook alias, and that alias is in the table the data tab holds | Found |
| Synonym | via the list: hires = hire count; ttf, time to fill = cycle time; accept rate = offer accept pct; open reqs = open requisitions | Inferred |
| Formula shape | the sheet aggregates a data-tab column whose header equals the alias | Found for the field, Inferred for the metric |
| Family only | same family, different words | Proposed, plus a Question |
| None | | Question: "Where is <label> computed?" |

Never collapse on name alone when the notebook has two aliases in the same family.

**What the file cannot tell you** (ask, do not guess): which script produced a pasted block;
whether a data tab is overwritten by a script or pasted; the population behind a pasted number;
the cadence (file metadata gives one date, not a schedule); which rows a whole-column SUMIFS
actually covers.

## Tableau workbooks (.twb, .twbx)

Run `python3 scripts/parse_twb.py <file> -o <file>.json`.

**Products.** One row per workbook unless the manifest says a workbook holds several products.
Type from the manifest; else Dashboard. Tool = Tableau.

**Tables.** Each datasource table is a Tables row (`schema.table`), Kind by the manifest's schema
lists (warehouse schemas → HRDW, team schemas → Team custom; else blank plus a Question).
Custom SQL embedded in the workbook: rows for the tables it names, and Notes on the product
"reads custom SQL embedded in the workbook". **Product inputs**: one row per datasource table,
How it gets in = "Live connection" for a live connection, "Scripted" for an extract on a schedule.

**Metrics.** A calculated field, or a plain measure, placed on a worksheet as a value people
read. A field used only as a filter or header is a Dimension. Definition = `formula_readable`
in words; Notes = "Formula: <formula_readable>. On worksheets <names>." Family from `families.md`.

**Deduplication across worksheets and tabs.** Normalise each formula (lower case, collapse
whitespace, captions for field references). Same formula, different filter or tab = one metric,
the filter is a Dimension usage. Same caption, different formula = two rows in one family with
bracketed names and a Question. Different caption, same formula = one row, other caption in
Notes, Question which name is official. Formulas differing only by a constant = two rows and a
Question.

**Fields.** Every field a metric's formula references, recursively. Physical column → Raw on the
table's row. Calculated field → Derived, Where the rule lives = "Inside the product", Table =
the datasource's main table, Logic = the formula in words.

## Databricks notebooks and scripts (.py, .ipynb, .sql)

Run `python3 scripts/parse_notebook.py <file> -o <file>.json`. It returns reads, writes,
file_writes, joins, aliased expressions, runs (`%run`, `dbutils.notebook.run`), widgets,
unresolved_tables, header_comments, questions.

**Scripts.** One row per notebook: Short name, Kind "Databricks notebook", Path, Reads and
Writes as table short names, Feeds = the product whose file a `file_writes` entry writes (match
the path or sheet name to the product's data tab), Trigger "Unknown" unless a job definition or
header comment says, Schedule and Who runs it from header_comments when present (Confidence
Inferred, the comment quoted in Notes), Failure notice "Unknown" unless a job definition says.
Every entry in `questions` becomes a Question on this row. Every `runs` entry: if the target is
in the manifest, parse it too; if not, a Question.

**Tables.** Every `writes` table is a Tables row (Kind by schema). Every `file_writes` path is a
Tables row with Kind "Script output file", Full name = the path. Every `reads` table not written
anywhere in the manifest gets a row with Kind by schema or blank plus a Question. Built from
for a written table = the reads of the cell that writes it, main source first; follow
temporary views back to physical tables and say so in Notes. `unresolved_tables` never become
rows; they are Questions.

**Fields.** Every aliased expression that is not a plain rename is a Derived field on the table
the cell writes, Logic = the expression in words, Derived from = the columns it references,
Where the rule lives = "In a script". A plain rename is still Derived when the join that supplies
it carries a condition (a date range, a status filter, a COALESCE); write the rule from the join.

> `h.owner_id AS credited_recruiter` with `JOIN hrdw.requisition_history h ON ... o.accepted_dt BETWEEN h.valid_from AND h.valid_to`
> becomes Logic: "Recruiter who owned the requisition on the day the offer was accepted, taken from the requisition history."

**Metrics.** An aliased aggregate or DATEDIFF that a product then shows is a metric computed in
the notebook. Match it to the product's metric by the table above; one row, Notes "Computed in
<notebook>, cell N; the product reads the column." If the product recomputes it with its own
formula, that is a second definition in the family and a Question.

## Job definitions (Databricks workflow JSON, Airflow DAGs, cron, Tableau extract schedules)

**Scripts.** A workflow is its own Scripts row (Kind "Databricks workflow") whose Notes list the
notebooks it runs; set each notebook's Trigger to "Scheduled" (or "On demand" when triggered by
another task) and Schedule in words ("weekdays 06:00 ET"; convert from UTC and say so). Owner and
Who runs it from `run_as` or the owner field. Failure notice from alert or email settings: "Email"
or "Alert to team channel" with the address in Notes; none configured → "Nobody is told" plus a
Question asking who notices. A notebook with no schedule and no trigger anywhere → "Manual run".

**Tables.** `workbook.py sync` sets Built by and Refresh mechanism from the scripts; set Refresh
frequency from the schedule with `fill`.

## Manual processes

When a manifest note, a cell comment or a header says a person does a step ("Jamie pastes the
Data tab each Monday"), that is a Scripts row with Kind "Manual process", Trigger "Manual run",
Who runs it in words, Feeds = the product, Confidence Inferred, and the quote in Notes.

## Spreadsheets that are inputs, decks, documents

A spreadsheet with no `product_name` in the manifest is a **table** of Kind "Manual spreadsheet"
(Owner and Point of contact blank, Question asking who maintains it). A deck or sent report is a
Product of Type "Sent report"; metric names on it link to existing Metrics rows by family when the
match is clear, else a Metrics row with Definition blank and a Question. Never derive a definition
from prose; only a formula or SQL is a definition.

## Incident logs (tickets, an issues sheet), if any exist

One Incidents row per reported problem: Symptom as the category, What was reported in the
reporter's words, Root stage from the fix not the symptom (changed at source → Platform; HRDW
late or missing → Platform to HRDW; our notebook fixed → HRDW to custom table; calculated field or
scorecard formula edited → Inside the product; re-uploaded or re-pasted → Manual step; "fixed"
with no detail → Unknown plus a Question). Recurring = Yes when the same symptom appears before.

## What is not extraction

Disposition and the Decision log are the people's. Platform on a source table is the people's.
Everything else you may propose, labelled Review = Proposed, with the evidence in Source and
Notes so a person can accept, correct or reject it in one glance.
