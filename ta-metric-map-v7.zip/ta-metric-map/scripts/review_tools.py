#!/usr/bin/env python3
"""
Helpers around the independent reviewer (see references/review-prompt.md).

    python3 review_tools.py excerpts <map.xlsx> <parsed_dir> -o excerpts.json
        For every row whose Review is Proposed, cut the source region named in its "Source (where found)"
        from the parser JSON files in <parsed_dir> (parse_xlsx / parse_notebook / parse_twb outputs, named
        <file>.json). Keyed by the exact Source text. Rows whose source cannot be located get no entry,
        which the reviewer must treat as "no evidence".

    python3 review_tools.py apply <map.xlsx> <batch.json> <verdicts.json> <excerpts.json> [--log selfcheck_log.jsonl]
        Apply reviewer verdicts with the guards: only Proposed rows, only allowed columns, evidence must be a
        substring of the excerpt, a cell repaired twice (per the log) is frozen and questioned.
"""
import json, sys, os, re, datetime
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import workbook as W
from openpyxl import load_workbook

ALLOWED = {"Definition (plain words)", "Who is counted", "Who is left out", "Metric family", "Metric name", "Why it exists",
           "Logic (the business rule)", "Manual steps", "How it is shown", "Who runs it", "Short name", "Notes"}


def _load_parsed(parsed_dir):
    out = {}
    for fn in os.listdir(parsed_dir):
        if fn.endswith(".json"):
            try: out[fn[:-5].lower()] = json.load(open(os.path.join(parsed_dir, fn)))
            except Exception: pass
    return out


def _excerpt_for(source, parsed):
    """Best-effort cut of the region a Source string names."""
    s = str(source); low = s.lower()
    hit = None
    for name, data in parsed.items():
        base = os.path.basename(name)
        if base in low or base.rsplit(".", 1)[0] in low: hit = data; break
    if not hit: return None
    lines = []
    m = re.search(r"cell\s+(\d+)", low)
    if "cells" in hit and m:  # notebook
        n = int(m.group(1)); cells = hit["cells"]
        cell = next((c for c in cells if c.get("index") == n or c.get("n") == n), cells[n - 1] if 0 < n <= len(cells) else None)
        if cell:
            sql = cell.get("sql") or cell.get("source") or cell.get("text") or ""
            if isinstance(sql, list): sql = "\n".join(sql)
            lines = sql.splitlines()
            for e in cell.get("expressions", []) or []: lines.append(f"expression: {e.get('expression') or e.get('expr')} AS {e.get('alias')}")
            for j in cell.get("joins", []) or []: lines.append(f"join: {j if isinstance(j, str) else json.dumps(j)}")
    elif "metrics" in hit and "sheets" in hit:  # xlsx
        tab = re.search(r"tab[s]?\s+([A-Za-z0-9_ ,]+?)(?:,| row| cell|$)", s)
        for mt in hit["metrics"]:
            where = " ".join(mt.get("where", [])).lower()
            if mt["label"].lower() in low or (tab and any(t.strip().lower() + "!" in where for t in tab.group(1).split(","))):
                lines.append(f"label: {mt['label']} | kind: {mt['kind']} | formula: {mt.get('formula_example')} | reads: {', '.join(mt.get('reads', []))} | where: {', '.join(mt.get('where', []))} | parameters: {json.dumps(mt.get('parameters', {}))}")
        for sh in hit["sheets"]:
            if sh["kind"] == "data dump" and (sh["name"].lower() in low or not tab): lines.append(f"data tab {sh['name']}: columns {', '.join(str(c.get('name', c)) if isinstance(c, dict) else str(c) for c in sh.get('columns', []))}, {sh.get('rows')} rows")
    elif "datasources" in hit:  # twb
        for ds in hit["datasources"]:
            for f in ds.get("fields", []):
                if f.get("calculated") and ((f.get("caption") or "").lower() in low or (f.get("name") or "").lower() in low): lines.append(f"{f.get('caption')}: {f.get('formula_readable') or f.get('formula')}")
        if not lines:
            for ds in hit["datasources"]:
                lines.append(f"datasource {ds.get('name')}: tables {', '.join(t.get('table', '') for t in ds.get('tables', []))}")
                for f in ds.get("fields", []):
                    if f.get("calculated"): lines.append(f"{f.get('caption')}: {f.get('formula_readable') or f.get('formula')}")
    return "\n".join(lines[:40]) if lines else None


def excerpts(path, parsed_dir):
    wb = load_workbook(path); parsed = _load_parsed(parsed_dir); out = {}
    for sheet, d in W.SHEETS.items():
        cs = W.cols(sheet)
        if "Source (where found)" not in cs: continue
        for r, row in W.rows_raw(wb[sheet], sheet):
            src = row.get("Source (where found)")
            if not src or src in out: continue
            ex = _excerpt_for(src, parsed)
            if ex: out[src] = ex
    return out


def apply(path, batch, verdicts, excerpts_map, log_path):
    wb = load_workbook(path); sheet = batch["sheet"]; cs = W.cols(sheet); rows = {r["_row"]: r for r in batch["rows"]}
    idx = W.Index(wb); rep = []; ws = wb[sheet]
    prior = {}
    if log_path and os.path.exists(log_path):
        for line in open(log_path):
            try: e = json.loads(line); prior[(e["sheet"], e["row"], e["column"])] = prior.get((e["sheet"], e["row"], e["column"]), 0) + 1
            except Exception: pass
    logf = open(log_path, "a") if log_path else None
    key = W.key_col(sheet)
    for v in verdicts:
        r = v.get("_row"); row = rows.get(r)
        if not row: rep.append(f"row {r}: not in batch; ignored"); continue
        name = row.get(key) if key and sheet not in W.JOIN_SHEETS else " -> ".join(str(row.get(c) or "") for c in W.link_cols(sheet)[:2])
        review = ws.cell(row=r, column=cs["Review"]).value if "Review" in cs else "Proposed"
        verdict = v.get("verdict")
        if verdict == "ok": continue
        if verdict == "repair":
            ev = v.get("evidence") or ""; ex = excerpts_map.get(row.get("Source (where found)") or "", "")
            if review != "Proposed":
                W.add_question(wb, sheet, name, f"A reviewer proposed changing {', '.join(v.get('repairs', {}))} on a row a person already validated: {json.dumps(v.get('repairs'), ensure_ascii=False)[:200]}", ev[:300], idx); rep.append(f"row {r}: validated row; repair turned into a question"); continue
            if not ev or ev.strip() not in ex:
                W.add_question(wb, sheet, name, f"A reviewer proposed {json.dumps(v.get('repairs'), ensure_ascii=False)[:200]} but could not quote the source for it. Is it right?", ev[:300] or "no evidence given", idx); rep.append(f"row {r}: evidence not in excerpt; turned into a question"); continue
            for col, val in (v.get("repairs") or {}).items():
                if col not in ALLOWED or col not in cs: rep.append(f"row {r}: column {col} not repairable; skipped"); continue
                if prior.get((sheet, r, col), 0) >= 2:
                    W.add_question(wb, sheet, name, f"{col} has been repaired twice already; the extractor and the reviewer disagree. Latest proposal: {val}", ev[:300], idx); rep.append(f"row {r}: {col} frozen; questioned"); continue
                cd = W.coldef(sheet, col)
                if cd.get("dropdown") and val not in cd["dropdown"]: W.add_question(wb, sheet, name, f"Reviewer proposed '{val}' for {col}, which is not an allowed value.", ev[:300], idx); continue
                if col == "Metric family" and val not in [f["question"] for f in W.SCHEMA["families"]]: W.add_question(wb, sheet, name, f"Reviewer proposed family '{val}', which is not on the Families sheet.", ev[:300], idx); continue
                old = ws.cell(row=r, column=cs[col]).value
                ws.cell(row=r, column=cs[col], value=val); rep.append(f"row {r}: {col}: '{str(old)[:40]}' -> '{str(val)[:40]}'")
                if logf: logf.write(json.dumps({"when": datetime.datetime.now().isoformat(timespec="seconds"), "sheet": sheet, "row": r, "name": name, "column": col, "old": old, "new": val, "evidence": ev[:300]}, ensure_ascii=False) + "\n")
        elif verdict == "question":
            W.add_question(wb, sheet, name, v.get("question") or "The reviewer could not confirm this row.", v.get("what_was_seen") or "", idx); rep.append(f"row {r}: question raised")
    if logf: logf.close()
    wb.save(path); return rep


def main():
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit(1)
    if a[0] == "excerpts":
        out = a[a.index("-o") + 1] if "-o" in a else "excerpts.json"
        ex = excerpts(a[1], a[2]); json.dump(ex, open(out, "w"), indent=1, ensure_ascii=False); print(f"wrote {out}: {len(ex)} sources with an excerpt")
    elif a[0] == "apply":
        log = a[a.index("--log") + 1] if "--log" in a else "selfcheck_log.jsonl"
        rep = apply(a[1], json.load(open(a[2])), json.load(open(a[3])), json.load(open(a[4])), log); print("\n".join(rep) or "nothing to apply")
    else: print(__doc__); sys.exit(1)


if __name__ == "__main__":
    main()
