#!/usr/bin/env python3
"""
Draft manifest.csv for a source folder, for a person to verify.

Usage:
    python3 propose_manifest.py <source_folder> [-o manifest.csv]

Writes one row per file found under the folder. Fills what the file itself shows:
  path            relative to the folder root
  kind            from extension and location: tableau, notebook, sql, dbt, scheduler, job, incidents, spreadsheet, deck, mapping, doc
  product_type    for Tableau files, a guess from the file name ("scorecard" -> Scorecard, else Dashboard)
  notes           facts a reviewer needs: for Tableau files, dashboard and worksheet names, data source tables;
                  for dbt projects, the models folder; for anything unrecognised, "kind unclear"

Leaves blank on purpose, for a person: product_name, owner_team, warehouse_schemas, team_schemas.
Rows whose kind could not be determined get kind = "?" so they cannot be processed until fixed.

If a manifest.csv already exists in the folder it is NOT overwritten; the draft goes to
manifest.proposed.csv next to it.
"""
import argparse, csv, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
try:
    from parse_twb import parse as parse_twb
except Exception:
    parse_twb = None

SKIP_DIRS = {".git", "__pycache__", "node_modules", ".DS_Store"}
ROOT = "."
COLUMNS = ["path", "kind", "product_name", "product_type", "owner_team", "warehouse_schemas", "team_schemas", "notes"]


def classify(rel, name):
    low = name.lower(); parts = rel.lower().split(os.sep)
    if low.endswith((".twb", ".twbx")): return "tableau"
    if low.endswith(".sql"):
        try:
            head = open(os.path.join(ROOT, rel), encoding="utf-8", errors="replace").read(200)
        except Exception:
            head = ""
        return "notebook" if "Databricks notebook source" in head else "sql"
    if low.endswith((".json", ".yml", ".yaml")) and ("jobs" in parts or "job" in low or "workflow" in low or "schedule" in low): return "job"
    if low.endswith((".xlsx", ".xlsm", ".csv")):
        if "mapping" in low or "source_to_target" in low or "s2t" in low: return "mapping"
        if "incident" in low or "ticket" in low or "issues" in low or "incidents" in parts: return "incidents"
        return "spreadsheet"
    if low.endswith(".pptx"): return "deck"
    if low.endswith((".md", ".docx", ".pdf", ".txt")): return "doc"
    if low.endswith(".py") and ("dag" in low or "dags" in parts or "airflow" in parts or "schedule" in low): return "scheduler"
    if low.endswith(".ipynb"): return "notebook"
    if low.endswith(".py"):
        try:
            head = open(os.path.join(ROOT, rel), encoding="utf-8", errors="replace").read(400)
        except Exception:
            head = ""
        if "Databricks notebook source" in head or "spark" in head: return "notebook"
        return "notebook" if "notebooks" in parts else "?"
    if low.endswith(".dbc"): return "?"
    if low in ("dbt_project.yml",): return "dbt"
    if low.endswith((".yml", ".yaml")) and "models" in parts: return "dbt"
    return "?"


def notebook_notes(path):
    try:
        from parse_notebook import parse as parse_nb
        d = parse_nb(path)
    except SystemExit as e:
        return f"not supported: {e}"
    except Exception as e:
        return f"could not parse: {e}"
    bits = [f"{len(d['cells'])} cells"]
    if d["writes"]: bits.append(f"writes: {', '.join(d['writes'])}")
    if d["reads"]: bits.append(f"reads: {', '.join(d['reads'])}")
    n = sum(1 for e in d["expressions"] if not e.get("rename_only"))
    bits.append(f"{n} calculated columns")
    return ". ".join(bits)


def tableau_notes(path):
    if parse_twb is None:
        return "parse_twb unavailable"
    try:
        d = parse_twb(path)
    except Exception as e:
        return f"could not parse: {e}"
    dbs = [x["name"] for x in d["dashboards"]]
    wss = [w["name"] for w in d["worksheets"]]
    tables = []
    for ds in d["datasources"]:
        for t in ds.get("tables", []): tables.append(t["table"])
        if ds.get("custom_sql"): tables.append("(custom SQL in workbook)")
    n_calc = sum(1 for ds in d["datasources"] for f in ds["fields"] if f["calculated"])
    bits = []
    if dbs: bits.append(f"dashboards: {', '.join(dbs)}")
    bits.append(f"{len(wss)} worksheets: {', '.join(wss[:12])}{' ...' if len(wss) > 12 else ''}")
    if tables: bits.append(f"reads: {', '.join(sorted(set(tables)))}")
    bits.append(f"{n_calc} calculated fields")
    if len(dbs) > 1: bits.append("MORE THAN ONE DASHBOARD: confirm whether this is one product or several")
    return ". ".join(bits)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("folder"); ap.add_argument("-o", "--out")
    a = ap.parse_args()
    root = os.path.abspath(a.folder)
    global ROOT; ROOT = root
    out = a.out or os.path.join(root, "manifest.csv")
    if os.path.exists(out):
        out = os.path.join(os.path.dirname(out), "manifest.proposed.csv")
    rows = []; dbt_dirs = set()
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        if "dbt_project.yml" in filenames:
            dbt_dirs.add(os.path.relpath(dirpath, root))
        for fn in sorted(filenames):
            if fn.startswith(".") or fn in ("manifest.csv", "manifest.proposed.csv"): continue
            full = os.path.join(dirpath, fn); rel = os.path.relpath(full, root)
            kind = classify(rel, fn)
            ptype, notes = "", ""
            if kind == "tableau":
                ptype = "Scorecard" if "scorecard" in fn.lower() else "Dashboard"
                notes = tableau_notes(full)
            elif kind == "notebook":
                notes = notebook_notes(full)
            elif kind == "deck":
                ptype = "Sent report"
            elif kind == "spreadsheet":
                ptype = "Sent report"; notes = "confirm: sent report, data pull, or a working file to ignore?"
            elif kind == "?":
                notes = "kind unclear: set kind or delete this row"
            rows.append({"path": rel, "kind": kind, "product_name": "", "product_type": ptype, "owner_team": "", "warehouse_schemas": "", "team_schemas": "", "notes": notes})
    # collapse dbt project files into one row per project
    final = []
    for r in rows:
        in_dbt = next((d for d in dbt_dirs if r["path"].startswith(d + os.sep) or r["path"] == d), None)
        if in_dbt and r["kind"] in ("sql", "dbt"):
            continue
        final.append(r)
    for d in sorted(dbt_dirs):
        final.append({"path": d + "/", "kind": "dbt", "product_name": "", "product_type": "", "owner_team": "", "warehouse_schemas": "", "team_schemas": "", "notes": "dbt project; models/ creates the team's tables. Confirm the scheduler file."})
    order = {"tableau": 0, "notebook": 1, "spreadsheet": 2, "deck": 3, "dbt": 4, "sql": 5, "scheduler": 6, "mapping": 7, "doc": 8, "?": 9}
    final.sort(key=lambda r: (order.get(r["kind"], 9), r["path"]))
    if final:
        final[0]["notes"] = (final[0]["notes"] + ". " if final[0]["notes"] else "") + "FILL warehouse_schemas and team_schemas on this row; they apply to the whole run"
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS); w.writeheader(); w.writerows(final)
    unclear = sum(1 for r in final if r["kind"] == "?")
    print(f"wrote {out}: {len(final)} rows, {unclear} with kind unclear. Fill product_name for tableau/deck/spreadsheet rows and the schema columns on row 1, then rename to manifest.csv if needed.")


if __name__ == "__main__":
    main()
