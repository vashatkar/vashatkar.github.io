#!/usr/bin/env python3
"""Write references/schema.md from references/schema.json so the two never drift. Run after build_v7.py."""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__)); REF = os.path.join(HERE, "..", "references")
S = json.load(open(os.path.join(REF, "schema.json")))
WHO = {"Tool": "Tool (workbook.py writes it; never typed)", "Machine": "Skill, from files", "Propose": "Skill proposes, person confirms", "Human": "Person only", "Formula": "Formula; never write"}
KIND = {"id": "ID (grey)", "key": "key name (light blue, unique)", "in": "text", "dd": "drop-down", "ddr": "drop-down from a sheet", "f": "formula", "names": "names list (comma-separated)", "ids": "IDs for the names list (grey, sync)", "h": "helper (grey)", "link": "one name, drop-down from a sheet", "linkid": "ID formula (grey)"}
L = ["# Workbook schema (v7)", "", f"Header row {S['header_row']}, data from row {S['first_row']}. Generated from schema.json; edit the generator, not this file.", "",
     "Every link a person reads is a **name**. Single links are a name column with a grey ID formula next to it. Multi-value links are a comma-separated names column with a grey IDs column that `workbook.py sync` maintains. Nobody types an ID.", "",
     "**Who fills it**: Tool = written by workbook.py (IDs, derived name lists). Machine = the skill, from files. Propose = the skill's best labelled reading; a person accepts, corrects or rejects. Human = only a person. Formula = computed; never written.", ""]
for sheet, d in S["sheets"].items():
    L += [f"## {sheet}", "", f"Capacity {d['cap']} rows. " + (f"IDs `{d['id_prefix']}-001`… " if d.get("id_prefix") else "") + (f"Key: **{d['key']}**." if d.get("key") else ""), "", "| Column | Kind | Who | Allowed values / links to |", "|---|---|---|---|"]
    for c in d["columns"]:
        extra = ", ".join(c["dropdown"]) if c.get("dropdown") else (f"names on {c['link_to'][0]}" if c.get("link_to") else "")
        L.append(f"| {c['name']} | {KIND.get(c['kind'], c['kind'])} | {WHO.get(c['who'], c['who'])} | {extra} |")
    L.append("")
L += ["## Families (fixed list; the Metric family cell holds the question text exactly)", "", "| Family (question) | Old name | Covers | Examples |", "|---|---|---|---|"]
for f in S["families"]: L.append(f"| {f['question']} | {f['old_name']} | {f['covers']} | {f['examples']} |")
L += ["", "## Decisions, Column guide, README: read-only summaries. Never write."]
open(os.path.join(REF, "schema.md"), "w").write("\n".join(L) + "\n"); print("wrote schema.md")
