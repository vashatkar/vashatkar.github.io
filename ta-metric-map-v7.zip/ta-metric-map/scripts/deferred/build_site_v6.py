#!/usr/bin/env python3
"""
Build a single-file HTML decision site from the TA metric map workbook.

Usage:
    python3 build_site.py <map.xlsx> [-o metric_map.html]

Open the result in any browser. No server, no internet, nothing else to install. Everything
comes from the workbook; re-run to refresh.

Sections:
  Decisions   the headline choices with counts, each expandable to its rows
  Products    one card per product: contact, cadence, metrics, what feeds it (with manual
              spreadsheets flagged), data issues, business rules, open questions
  Metrics     by family, with conflicting families first
  Tables      lineage, depth, disposition
  Questions   open items
"""
import argparse, html, json, re, sys, datetime, os
from openpyxl import load_workbook
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analyze import analyze

HEADER_ROW, FIRST_ROW = 4, 5


def rows_of(wb, name):
    ws = wb[name]
    hs = {ws.cell(row=HEADER_ROW, column=c).value: c for c in range(1, ws.max_column + 1) if ws.cell(row=HEADER_ROW, column=c).value}
    out = []
    for r in range(FIRST_ROW, ws.max_row + 1):
        if ws.cell(row=r, column=1).value in (None, ""): continue
        d = {h: ws.cell(row=r, column=c).value for h, c in hs.items() if not str(h).startswith("h_")}
        out.append(d)
    return out


def load(path):
    wb = load_workbook(path, data_only=True)  # cached values; formulas computed if the file was saved by Excel/Sheets/recalc
    d = {k: rows_of(wb, k) for k in ["Products", "Metrics", "Metric to Product", "Populations", "Tables", "Fields", "Metric to Field", "Dimensions", "Dimension usage", "Questions", "Decision log", "Jobs", "Incidents"]}
    d["_analysis"] = analyze(path)
    return d


MANUAL_TAG = ' <span class="tag warn">manual spreadsheet</span>'
RETIRE_TAG = ' <span class="tag bad">retire</span>'
MANUALRUN_TAG = ' <span class="tag warn">run by hand</span>'
PROPOSED_TAG = ' <span class="tag warn">proposed, not reviewed</span>'


def e(x):
    return html.escape("" if x is None else str(x))


def depth_of(tables, tid, seen=None):
    seen = seen or set()
    t = tables.get(tid)
    if not t or tid in seen: return 0
    parents = [p.strip() for p in str(t.get("Built from (table IDs, main parent first)") or "").replace(";", ",").split(",") if p.strip()]
    if not parents: return 0
    return 1 + max(depth_of(tables, p, seen | {tid}) for p in parents)


def build(d):
    P = {p["Product ID"]: p for p in d["Products"]}
    M = {m["Metric ID"]: m for m in d["Metrics"]}
    T = {t["Table ID"]: t for t in d["Tables"]}
    F = {f["Field ID"]: f for f in d["Fields"]}
    m2p, m2f = d["Metric to Product"], d["Metric to Field"]
    Q = [q for q in d["Questions"] if q.get("Status") == "Open"]
    for t in T.values(): t["_depth"] = depth_of(T, t["Table ID"])
    fam_count = {}
    for m in M.values(): fam_count[m.get("Metric family")] = fam_count.get(m.get("Metric family"), 0) + 1

    # ---- per product feeding chain
    def chain(pid):
        mids = [x["Metric ID"] for x in m2p if x["Product ID"] == pid and x["Metric ID"] in M]
        fids = sorted({x["Field ID"] for x in m2f if x["Metric ID"] in mids and x["Field ID"] in F})
        direct = sorted({F[f]["Table ID"] for f in fids if F[f].get("Table ID") in T})
        seen, order = set(), []
        def walk(tid, depth):
            if tid in seen or tid not in T: return
            seen.add(tid); order.append((tid, depth))
            for p in str(T[tid].get("Built from (table IDs, main parent first)") or "").replace(";", ",").split(","):
                p = p.strip()
                if p: walk(p, depth + 1)
        for tid in direct: walk(tid, 0)
        return mids, fids, order

    # ---- decisions
    retire = [t for t in T.values() if t.get("Disposition") == "Retire"]
    build_ = [t for t in T.values() if t.get("Disposition") == "Build"]
    stacked = [t for t in T.values() if t["_depth"] >= 2]
    conflicts = [m for m in M.values() if fam_count.get(m.get("Metric family"), 0) > 1 and m.get("Metric family")]
    fix = [f for f in F.values() if f.get("Disposition") == "Fix upstream"]
    move = [f for f in F.values() if f.get("Disposition") in ("Move to business rules", "Merge into certified table")]
    dim_sources = {x["Dimension ID"]: x.get("Agreed source table ID") for x in d["Dimensions"]}
    offsrc = [u for u in d["Dimension usage"] if dim_sources.get(u["Dimension ID"]) and u.get("Mapping source table ID") and u.get("Mapping source table ID") != dim_sources[u["Dimension ID"]]]
    undecided = [("Table", t["Table ID"], t.get("Table name")) for t in T.values() if not t.get("Disposition") or t.get("Disposition") == "Undecided" or not t.get("Target layer")] + \
                [("Field", f["Field ID"], f.get("Field name")) for f in F.values() if not f.get("Disposition") or f.get("Disposition") == "Undecided" or not f.get("Target layer")]
    manual = [t for t in T.values() if str(t.get("Layer") or "").lower().startswith("manual")]
    no_poc = [p for p in P.values() if not p.get("Point of contact")]

    def tbl(headers, rows):
        h = "".join(f"<th>{e(x)}</th>" for x in headers)
        b = "".join("<tr>" + "".join(f"<td>{e(c)}</td>" for c in r) + "</tr>" for r in rows) or f'<tr><td colspan="{len(headers)}" class="muted">nothing yet</td></tr>'
        return f"<table><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table>"

    def mname(mid): return M.get(mid, {}).get("Metric name", mid)
    def tname(tid): return T.get(tid, {}).get("Table name", tid)

    decisions = [
        ("Tables to retire", len(retire), "Marked Retire; check what still depends on them", tbl(["Table", "Layer", "Depth", "Metrics depending", "Why it exists"], [(t.get("Table name"), t.get("Layer"), t["_depth"], t.get("Metrics depending"), t.get("Why it exists")) for t in retire])),
        ("Tables to build", len(build_), "Proposed tables the dispositions call for", tbl(["Table", "Target layer", "Built from", "Why it exists", "Status"], [(t.get("Table name"), t.get("Target layer"), ", ".join(tname(p.strip()) for p in str(t.get("Built from (table IDs, main parent first)") or "").split(",") if p.strip()), t.get("Why it exists"), t.get("Status")) for t in build_])),
        ("Stacked tables (depth 2 or more)", len(stacked), "Layers built on layers: the simplification candidates", tbl(["Table", "Depth", "Disposition", "Metrics depending", "Why it exists"], [(t.get("Table name"), t["_depth"], t.get("Disposition"), t.get("Metrics depending"), t.get("Why it exists")) for t in sorted(stacked, key=lambda x: -x["_depth"])])),
        ("Metric families with more than one definition", len({m.get("Metric family") for m in conflicts}), "Same name, different rule: the alignment agenda with TAAA", tbl(["Family", "Metric", "Definition", "Status", "Products"], [(m.get("Metric family"), m.get("Metric name"), m.get("Definition (plain words)"), m.get("Status"), m.get("Products using it")) for m in sorted(conflicts, key=lambda x: str(x.get("Metric family")))])),
        ("Fields to fix upstream", len(fix), "Data problems that belong to the source, to take to PDP", tbl(["Field", "Table", "Issue", "Metrics using it"], [(f.get("Field name"), tname(f.get("Table ID")), f.get("Issue / note"), f.get("Metrics using it")) for f in fix])),
        ("Rules moving into the business layer", len(move), "Logic that lives in a dashboard or a one-off table today", tbl(["Field", "Table today", "Rule", "Disposition"], [(f.get("Field name"), tname(f.get("Table ID")), f.get("Logic (the business rule)"), f.get("Disposition")) for f in move])),
        ("Dimension usages off the agreed source", len(offsrc), "Same filter name, different mapping table", tbl(["Product", "Dimension", "Mapping source today", "Agreed source"], [(P.get(u["Product ID"], {}).get("Product name"), next((x.get("Dimension name") for x in d["Dimensions"] if x["Dimension ID"] == u["Dimension ID"]), u["Dimension ID"]), tname(u.get("Mapping source table ID")), tname(dim_sources.get(u["Dimension ID"]))) for u in offsrc])),
        ("Products relying on a manual spreadsheet", sum(1 for pid in P if any(t in {x["Table ID"] for x in manual} for t, _ in chain(pid)[2])), "A hand-maintained file sits under these; one person away from breaking", tbl(["Product", "Spreadsheet", "Maintained by", "Refresh"], [(P[pid].get("Product name"), T[t].get("Table name"), T[t].get("Point of contact") or T[t].get("Owner (team)") or "unknown", T[t].get("Refresh")) for pid in P for t, _ in chain(pid)[2] if t in {x["Table ID"] for x in manual}])),
        ("Products with no point of contact", len(no_poc), "Nobody to call when it breaks", tbl(["Product", "Type", "Owner"], [(p.get("Product name"), p.get("Type"), p.get("Owner (team)")) for p in no_poc])),
        ("Tables and fields still undecided", len(undecided), "No Target layer or Disposition yet", tbl(["Kind", "ID", "Name"], undecided)),
    ]


    A = d["_analysis"]
    # ---- validation queue
    qrows = "".join(f'<tr><td><span class="tag">{e(q["sheet"])}</span> {e(q["id"])}</td><td><b>{e(q["name"])}</b></td><td>{"".join(f"<div><span class=k2>{e(k)}</span> {e(v)}</div>" for k, v in q["proposed"].items()) or "<span class=muted>row itself is proposed</span>"}</td><td class="muted">{e(q["source"])} · {e(q["confidence"])}</td><td class="num">{q["impact"]}</td></tr>' for q in A["queue"])
    queue_html = f'<p class="muted">Rows the skill filled that nobody has confirmed, highest impact first. Accept, correct or reject each on its sheet (Review column), then rebuild this page.</p><div class="wide"><table><thead><tr><th>Row</th><th>Name</th><th>What was proposed</th><th>Where from</th><th>Impact</th></tr></thead><tbody>{qrows or "<tr><td colspan=5 class=muted>nothing awaiting review</td></tr>"}</tbody></table></div>'
    # ---- overlaps
    mo = "".join(f'<tr><td><b>{e(o["a_name"])}</b><div class="muted">{e(", ".join(P.get(p, {}).get("Product name", p) for p in o["products_a"]))}</div></td><td><b>{e(o["b_name"])}</b><div class="muted">{e(", ".join(P.get(p, {}).get("Product name", p) for p in o["products_b"]))}</div></td><td class="num">{o["score"]}</td><td>{e(", ".join(o["reasons"]))}</td><td>{e(o["verdict"])}</td></tr>' for o in A["metric_overlaps"])
    po = "".join(f'<tr><td><b>{e(o["a_name"])}</b></td><td><b>{e(o["b_name"])}</b></td><td class="num">{o["score"]}</td><td>{len(o["shared_metrics"])} metrics · families {e(", ".join(o["shared_families"]) or "none")} · {len(o["shared_tables"])} tables{" · same audience" if o["same_audience"] else ""}</td><td>{e(o["verdict"])}</td></tr>' for o in A["product_overlaps"])
    overlaps_html = f'<h3>Metrics that may be the same thing</h3><p class="muted">Scored on name, definition and shared fields. The verdict is a suggestion for a person to confirm.</p><div class="wide"><table><thead><tr><th>Metric</th><th>Metric</th><th>Score</th><th>Why</th><th>Suggested call</th></tr></thead><tbody>{mo or "<tr><td colspan=5 class=muted>no overlapping pairs</td></tr>"}</tbody></table></div><h3>Products that overlap</h3><div class="wide"><table><thead><tr><th>Product</th><th>Product</th><th>Score</th><th>What they share</th><th>Suggested call</th></tr></thead><tbody>{po or "<tr><td colspan=5 class=muted>no overlapping pairs</td></tr>"}</tbody></table></div>'
    # ---- automation
    ao = "".join(f'<tr><td><b>{e(x["product"])}</b></td><td><span class="tag {"bad" if x["derived"] == "Manual" else "warn" if x["derived"] == "Partly manual" else ""}">{e(x["derived"])}</span>{" <span class=bad>recorded " + e(x["recorded"]) + "</span>" if x["agree"] is False else ""}</td><td class="num">{x["hours_per_cycle"]:g}</td><td class="num">{x["depth"]}</td><td>{"".join(f"<div>{e(s)}</div>" for s in x["manual_steps"]) or "<span class=muted>none found</span>"}</td><td>{e(", ".join(x["no_failure_notice"])) or "<span class=muted>all alert</span>"}</td><td class="num">{x["low_hanging_score"]}</td></tr>' for pid, x in sorted(A["automation"].items(), key=lambda kv: -kv[1]["low_hanging_score"]))
    automation_html = f'<p class="muted">Derived from the jobs and tables under each product: a product is only as automated as its least automated feed. Low-hanging score favours high manual effort on a shallow chain. "Recorded" in red means the sheet says one thing and the chain says another.</p><div class="wide"><table><thead><tr><th>Product</th><th>Automation</th><th>Hours / cycle</th><th>Chain depth</th><th>Manual steps found</th><th>Jobs nobody is told about when they fail</th><th>Low-hanging</th></tr></thead><tbody>{ao}</tbody></table></div>'
    # ---- incidents by stage
    so = "".join(f'<tr><td><b>{e(s)}</b></td><td class="num">{v["incidents"]}</td><td class="num">{v["hours"]:g}</td><td class="num">{v["recurring"]}</td><td>{e(", ".join(P.get(p, {}).get("Product name", p) for p in v["products"]))}</td><td class="num">{A["field_issue_stages"].get(s, 0)}</td></tr>' for s, v in sorted(A["stages"].items(), key=lambda kv: -kv[1]["incidents"]))
    inc_rows = "".join(f'<tr><td>{e(i.get("Date"))}</td><td>{e(P.get(i.get("Product ID"), {}).get("Product name", i.get("Product ID")))}</td><td>{e(i.get("Symptom"))}</td><td>{e(i.get("What was reported"))}</td><td><span class="tag">{e(i.get("Root stage") or "?")}</span></td><td>{e(i.get("Root cause (plain words)"))}</td><td class="num">{e(i.get("Time to resolve (hours)"))}</td><td>{"<span class=bad>yes</span>" if i.get("Recurring?") == "Yes" else e(i.get("Recurring?") or "")}</td></tr>' for i in sorted(d["Incidents"], key=lambda x: str(x.get("Date")), reverse=True))
    stages_html = f'<p class="muted">Where problems actually originate once traced. The hours column is the cost of the status quo.</p><div class="wide"><table><thead><tr><th>Root stage</th><th>Incidents</th><th>Hours</th><th>Recurring</th><th>Products hit</th><th>Fields with an issue here</th></tr></thead><tbody>{so or "<tr><td colspan=6 class=muted>no incidents recorded</td></tr>"}</tbody></table></div><details><summary>All incidents ({len(d["Incidents"])})</summary><div class="wide"><table><thead><tr><th>Date</th><th>Product</th><th>Symptom</th><th>Reported</th><th>Stage</th><th>Root cause</th><th>Hours</th><th>Recurring</th></tr></thead><tbody>{inc_rows}</tbody></table></div></details>'

    # ---- product cards
    cards = []
    for pid, p in P.items():
        mids, fids, order = chain(pid)
        manual_here = [t for t, _ in order if str(T[t].get("Layer") or "").lower().startswith("manual")]
        issues = [f for f in fids if F[f].get("Data quality") == "Issue"]
        rules = [f for f in fids if F[f].get("Type") == "Derived"]
        ids = set(mids) | set(fids) | {t for t, _ in order} | {pid}
        oq = [q for q in Q if q.get("Row ID") in ids]
        watch = []
        if not p.get("Point of contact"): watch.append("no point of contact")
        if manual_here: watch.append(f"{len(manual_here)} manual spreadsheet(s) underneath")
        if issues: watch.append(f"{len(issues)} field(s) with a known data issue")
        if oq: watch.append(f"{len(oq)} open question(s)")
        nopoc = [t for t, _ in order if not T[t].get("Point of contact")]
        if nopoc: watch.append(f"{len(nopoc)} feeding table(s) without a contact")
        mrows = "".join(f'<li><b>{e(mname(x["Metric ID"]))}</b> <span class="tag">{e(M[x["Metric ID"]].get("Metric family") or "no family")}</span> <span class="tag st-{e(str(M[x["Metric ID"]].get("Status") or "none").split()[0].lower())}">{e(M[x["Metric ID"]].get("Status") or "no status")}</span><div class="def">{e(M[x["Metric ID"]].get("Definition (plain words)") or "no definition")}</div><div class="muted">shown as: {e(x.get("How it is shown"))}</div></li>' for x in m2p if x["Product ID"] == pid and x["Metric ID"] in M)
        trows = "".join(f'<li style="margin-left:{depth * 22}px"><b>{e(T[t].get("Table name"))}</b> <span class="tag">{e(T[t].get("Layer") or "layer?")}</span>{MANUAL_TAG if t in manual_here else ""}{MANUALRUN_TAG if str(T[t].get("Refresh mechanism") or "") == "Manual run" else ""}{RETIRE_TAG if T[t].get("Disposition") == "Retire" else ""}<div class="muted">owner {e(T[t].get("Owner (team)") or "?")} · contact {("<b class=bad>none</b>" if not T[t].get("Point of contact") else e(T[t].get("Point of contact")))} · refresh {e(T[t].get("Refresh") or "?")}</div><div class="def">{e(T[t].get("Why it exists") or "why it exists: not recorded")}</div></li>' for t, depth in order)
        irows = "".join(f'<li><b>{e(F[f].get("Field name"))}</b> on {e(tname(F[f].get("Table ID")))}: {e(F[f].get("Issue / note"))}</li>' for f in issues)
        rrows = "".join(f'<li><b>{e(F[f].get("Field name"))}</b>: {e(F[f].get("Logic (the business rule)") or "logic not recorded")}</li>' for f in rules)
        qrows = "".join(f'<li><b>{e(q.get("Question ID"))}</b> {e(q.get("Question"))}</li>' for q in oq)
        cards.append(f'''
<section class="card" id="{e(pid)}">
  <h3>{e(p.get("Product name"))} <span class="muted">{e(pid)}</span>{PROPOSED_TAG if p.get("Review") == "Proposed" else ""}</h3>
  <div class="facts">
    <div><span class="k">Type</span>{e(p.get("Type"))} in {e(p.get("Tool"))}</div>
    <div><span class="k">Audience</span>{e(p.get("Audience") or "not recorded")}</div>
    <div><span class="k">Owner</span>{e(p.get("Owner (team)") or "not recorded")}</div>
    <div><span class="k">Contact</span>{("<b class=bad>not recorded</b>" if not p.get("Point of contact") else e(p.get("Point of contact")))}</div>
    <div><span class="k">Refresh</span>{e(p.get("Refresh frequency") or "not recorded")}</div>
    <div><span class="k">Sent</span>{e(p.get("Delivery cadence") or "n/a")}</div>
    <div><span class="k">Automation</span>{e(A["automation"].get(pid, {}).get("derived") or "?")}{" <span class=bad>(sheet says " + e(p.get("Automation level")) + ")</span>" if A["automation"].get(pid, {}).get("agree") is False else ""}</div>
    <div><span class="k">Manual effort</span>{e(p.get("Manual effort (hours per cycle)") or 0)} h / cycle</div>
  </div>
  {"<div class=watch><b>Watch:</b> " + e("; ".join(watch)) + "</div>" if watch else ""}
  <details open><summary>Metrics shown ({len(mids)})</summary><ul class="list">{mrows or "<li class=muted>none linked yet</li>"}</ul></details>
  <details open><summary>What feeds it ({len(order)} tables)</summary><p class="muted">Indented rows are upstream of the row above.</p><ul class="list tree">{trows or "<li class=muted>no tables traced yet</li>"}</ul></details>
  {"<details><summary>Known data issues (" + str(len(issues)) + ")</summary><ul class=list>" + irows + "</ul></details>" if issues else ""}
  {"<details><summary>Business rules it depends on (" + str(len(rules)) + ")</summary><ul class=list>" + rrows + "</ul></details>" if rules else ""}
  {"<details><summary>Open questions (" + str(len(oq)) + ")</summary><ul class=list>" + qrows + "</ul></details>" if oq else ""}
</section>''')

    # ---- metrics by family
    fams = {}
    for m in M.values(): fams.setdefault(m.get("Metric family") or "(no family)", []).append(m)
    fam_html = ""
    for fam, ms in sorted(fams.items(), key=lambda kv: (-len(kv[1]) if len(kv[1]) > 1 else 0, kv[0])):
        flag = ' <span class="tag bad">%d definitions</span>' % len(ms) if len(ms) > 1 else ""
        items = "".join(f'<li><b>{e(m.get("Metric name"))}</b> <span class="tag st-{e(str(m.get("Status") or "none").split()[0].lower())}">{e(m.get("Status") or "no status")}</span> <span class="muted">{e(m.get("Grain (one row per)") or "")} · {e(m.get("Unit") or "")} · {e(m.get("Products using it") or 0)} products</span><div class="def">{e(m.get("Definition (plain words)") or "")}</div></li>' for m in ms)
        fam_html += f'<details {"open" if len(ms) > 1 else ""}><summary>{e(fam)}{flag} <span class="muted">({len(ms)})</span></summary><ul class="list">{items}</ul></details>'

    # ---- tables
    trows_all = "".join(f'<tr><td>{e(t.get("Table name"))}</td><td>{e(t.get("Layer"))}</td><td>{t["_depth"]}</td><td>{e(t.get("Target layer"))}</td><td>{e(t.get("Disposition"))}</td><td>{e(t.get("Metrics depending"))}</td><td>{e(t.get("Point of contact") or "")}</td><td>{e(t.get("Why it exists") or "")}</td></tr>' for t in sorted(T.values(), key=lambda x: (-x["_depth"], str(x.get("Table name")))))
    qrows_all = "".join(f'<tr><td>{e(q.get("Question ID"))}</td><td>{e(q.get("Sheet"))} {e(q.get("Row ID"))}</td><td>{e(q.get("Question"))}</td><td class="muted">{e(q.get("What was seen"))}</td></tr>' for q in Q)
    dec_html = "".join(f'<details class="dec"><summary><span class="n {"zero" if n == 0 else ""}">{n}</span><span class="t">{e(title)}</span><span class="muted">{e(sub)}</span></summary>{body}</details>' for title, n, sub, body in decisions)
    nav = "".join(f'<a href="#{e(pid)}">{e(p.get("Product name"))}</a>' for pid, p in P.items())
    stamp = datetime.date.today().isoformat()

    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TA metric map</title>
<style>
:root{{--navy:#0b1f3a;--mid:#1b3a5c;--pale:#eef3f7;--ink:#1f2933;--muted:#6b7280;--red:#b85042;--amber:#b7791f;--green:#1e7b3a;--bg:#f6f4f0;--card:#fff}}
*{{box-sizing:border-box}} body{{margin:0;font:15px/1.5 -apple-system,Segoe UI,Arial,sans-serif;color:var(--ink);background:var(--bg)}}
header{{background:var(--navy);color:#fff;padding:18px 24px}} header h1{{margin:0;font-size:20px;font-weight:600}} header .muted{{color:#b9cfdc}}
nav.top{{position:sticky;top:0;background:#fff;border-bottom:1px solid #ddd;padding:8px 24px;display:flex;gap:18px;flex-wrap:wrap;z-index:5}} nav.top a{{color:var(--mid);text-decoration:none;font-weight:600}} p.muted a{{margin-right:14px}}
main{{max-width:1180px;margin:0 auto;padding:16px 24px 60px}}
h2{{font-size:18px;margin:28px 0 10px;color:var(--navy)}}
.muted{{color:var(--muted)}} .bad{{color:var(--red)}}
.tag{{display:inline-block;font-size:11px;padding:1px 7px;border-radius:10px;background:var(--pale);color:var(--mid);margin-left:4px;vertical-align:middle}}
.tag.warn{{background:#fdf1dc;color:var(--amber)}} .tag.bad{{background:#f9e3df;color:var(--red)}}
.st-agreed,.st-certified{{background:#e1f3e6;color:var(--green)}} .st-draft{{background:#fdf1dc;color:var(--amber)}}
details.dec{{background:var(--card);border:1px solid #e3e6ea;border-radius:8px;margin:8px 0;padding:0}} details.dec summary{{list-style:none;cursor:pointer;display:grid;grid-template-columns:64px 1fr;gap:4px 14px;padding:12px 16px;align-items:center}}
details.dec summary .n{{font-size:26px;font-weight:700;color:var(--red);grid-row:span 2;text-align:center}} details.dec summary .n.zero{{color:#9aa3ad}} details.dec summary .t{{font-weight:600}}
details.dec table{{margin:0 16px 14px}}
table{{border-collapse:collapse;width:calc(100% - 32px);font-size:13px;background:#fff}} th,td{{text-align:left;padding:6px 8px;border-bottom:1px solid #eceff2;vertical-align:top}} th{{background:var(--pale);color:var(--mid);font-weight:600}}
section.card{{background:var(--card);border:1px solid #e3e6ea;border-radius:10px;padding:16px 18px;margin:14px 0}} section.card h3{{margin:0 0 8px;font-size:17px}}
.facts{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:6px 16px;font-size:13px;margin-bottom:8px}} .facts .k{{display:block;font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.03em}}
.watch{{background:#fdf1dc;border-left:3px solid var(--amber);padding:8px 12px;border-radius:6px;font-size:13px;margin:8px 0 10px}}
details{{margin:6px 0}} summary{{cursor:pointer;font-weight:600;color:var(--mid)}}
ul.list{{list-style:none;padding:0;margin:6px 0}} ul.list>li{{padding:7px 0;border-top:1px solid #f0f2f4}} .def{{font-size:13px;margin-top:2px}}
ul.tree>li{{border-top:none;padding:5px 0 5px 10px;border-left:2px solid #e3e6ea}}
.wide table{{width:100%}} td.num{{text-align:right;white-space:nowrap}} .k2{{display:inline-block;min-width:120px;color:var(--muted);font-size:12px}} .pill{{background:var(--red);color:#fff;border-radius:10px;padding:0 7px;font-size:11px;margin-left:4px}} h3{{font-size:15px;margin:16px 0 6px;color:var(--navy)}}
@media(max-width:700px){{main{{padding:12px}} details.dec summary{{grid-template-columns:48px 1fr}}}}
</style></head><body>
<header><h1>TA metric map</h1><div class="muted">Generated {stamp} from the workbook · {len(P)} products · {len(M)} metrics · {len(T)} tables · {len(F)} fields · {len(d['Jobs'])} jobs · {len(d['Incidents'])} incidents · {len(Q)} open questions</div></header>
<nav class="top"><a href="#decisions">Decisions</a><a href="#queue">To review <span class="pill">{A["counts"]["proposed"]}</span></a><a href="#overlaps">Overlaps</a><a href="#automation">Automation</a><a href="#incidents">Root causes</a><a href="#products">Products</a><a href="#metrics">Metrics</a><a href="#tables">Tables</a><a href="#questions">Questions</a></nav>
<main>
<h2 id="decisions">Decisions</h2>
<p class="muted">Each line is a choice to make. Click to see the rows behind it.</p>
{dec_html}
<h2 id="queue">To review ({A["counts"]["proposed"]})</h2>
{queue_html}
<h2 id="overlaps">Overlaps</h2>
{overlaps_html}
<h2 id="automation">Automation</h2>
{automation_html}
<h2 id="incidents">Root causes</h2>
{stages_html}
<h2 id="products">Products</h2>
<p class="muted">Jump to: {nav}</p>
{"".join(cards)}
<h2 id="metrics">Metrics by family</h2>
<p class="muted">Families with more than one definition are open and flagged; those are the ones to align.</p>
{fam_html}
<h2 id="tables" class="wide">All tables</h2>
<div class="wide"><table><thead><tr><th>Table</th><th>Layer</th><th>Depth</th><th>Target layer</th><th>Disposition</th><th>Metrics depending</th><th>Contact</th><th>Why it exists</th></tr></thead><tbody>{trows_all}</tbody></table></div>
<h2 id="questions" class="wide">Open questions ({len(Q)})</h2>
<div class="wide"><table><thead><tr><th>ID</th><th>About</th><th>Question</th><th>What was seen</th></tr></thead><tbody>{qrows_all or '<tr><td colspan=4 class=muted>none open</td></tr>'}</tbody></table></div>
</main></body></html>'''


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out", default="metric_map.html")
    a = ap.parse_args()
    d = load(a.path)
    if not any(m.get("Products using it") is not None for m in d["Metrics"]):
        print("note: formula values are not cached in this file (saved by a script, not by Excel/Sheets). Counts will show blank; open and save the workbook in Excel or Google Sheets, or run recalc, then rebuild.", file=sys.stderr)
    open(a.out, "w").write(build(d)); print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
