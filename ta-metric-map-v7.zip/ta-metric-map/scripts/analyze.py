#!/usr/bin/env python3
"""
Analysis over the TA metric map workbook (v7). Pure computation, no judgement.

Usage:
    python3 analyze.py <map.xlsx> [-o analysis.json] [--md analysis.md]

Produces:
  front_page        the counts the site's front page shows (metrics, tables, products, scripts, review)
  metric_overlaps   pairs of metrics that may be the same thing: scored on name similarity,
                    definition similarity, and shared fields; each with a reason and a verdict
  product_overlaps  pairs of products with overlapping metrics or feeding tables, and the metrics
                    they share that are pulled from different tables
  automation        per product: automation level derived from the whole chain (input tables, their
                    ancestors, the scripts that build them, the scripts that feed the product, the
                    last hop), compared with the recorded level; a low-hanging-fruit score
  stages            incidents and field issues counted by root stage, with hours
  queue             every Proposed row across sheets, ranked by the number of products it reaches
  chains            per product: the full feeding chain (tables and scripts)

Reads the workbook through workbook.py (Index, rows_raw, SHEETS, split_ids) so names and IDs are
resolved the same way everywhere. IDs come only from the grey h_*_ids columns and from the Index,
never from formula columns. Every human-readable string uses names; IDs sit in separate keys for
the site. Re-run after every change.
"""
import argparse, json, re, sys, os, difflib, datetime
from openpyxl import load_workbook

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import workbook as W  # noqa: E402

STOP = {"avg", "average", "the", "of", "per", "a", "an", "by", "to", "in", "and", "or", "rate", "pct", "percent", "percentage", "%", "count", "number", "total", "monthly", "ytd", "days", "day", "for", "on", "at", "is", "are", "as", "from", "with", "that", "this", "all", "any", "each", "every", "it"}
MANUAL_LAST_HOP = "Pasted by hand"
AUTOMATED_LAST_HOPS = ("Scripted", "Live connection")
NO_NOTICE = ("Nobody is told", "Unknown")
QUEUE_SHEETS = ["Products", "Metrics", "Tables", "Scripts", "Fields", "Product inputs", "Metric to Product", "Metric to Field", "Dimensions", "Dimension usage", "Incidents"]


# ---------------------------------------------------------------- helpers
def tokens(s):
    return {w for w in re.findall(r"[a-z0-9]+", str(s or "").lower()) if w not in STOP and len(w) > 1}


def sim(a, b):
    return difflib.SequenceMatcher(None, str(a or "").lower().strip(), str(b or "").lower().strip()).ratio()


def jaccard(a, b):
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if a | b else 0.0


def blank(v):
    return v in (None, "") or (isinstance(v, str) and not v.strip())


def norm_def(v):
    return re.sub(r"\s+", " ", str(v or "").strip().lower().rstrip("."))


def bare_field_name(name):
    """field name with any trailing '(table)' qualifier removed: 'hires (scorecard input file)' -> 'hires'"""
    return re.sub(r"\s*\([^()]*\)\s*$", "", str(name or "")).strip().lower()


def num(v):
    try: return float(v)
    except Exception: return 0.0


def propose_cols(sheet):
    return [c["name"] for c in W.SHEETS[sheet]["columns"] if c.get("who") == "Propose"]


# ---------------------------------------------------------------- analysis
def analyze(path):
    wb = load_workbook(path, data_only=True)
    idx = W.Index(wb)

    def rows(sheet):
        if sheet not in wb.sheetnames or sheet not in W.SHEETS: return []
        out = []
        for r, row in W.rows_raw(wb[sheet], sheet):
            row = dict(row); row["_row"] = r; row["_sheet"] = sheet; out.append(row)
        return out

    def by_id(sheet):
        idc = W.SHEETS[sheet]["columns"][0]["name"]
        return {row[idc]: row for row in rows(sheet) if not blank(row.get(idc))}

    P, M, T, S, F, D = by_id("Products"), by_id("Metrics"), by_id("Tables"), by_id("Scripts"), by_id("Fields"), by_id("Dimensions")
    m2p, m2f, pinputs, dusage = rows("Metric to Product"), rows("Metric to Field"), rows("Product inputs"), rows("Dimension usage")
    inc, questions = rows("Incidents"), rows("Questions")

    def pname(pid): return P.get(pid, {}).get("Short name") or pid
    def mname(mid): return M.get(mid, {}).get("Metric name") or mid
    def tname(tid): return T.get(tid, {}).get("Short name") or tid
    def sname(sid): return S.get(sid, {}).get("Short name") or sid
    def fname(fid): return F.get(fid, {}).get("Field name") or fid
    def names(fn, ids): return [fn(i) for i in ids]
    def rid(sheet, value): return idx.resolve(sheet, value)[0]

    merged = {mid for mid, m in M.items() if str(m.get("Metric name") or "").startswith("(merged into")}
    live_mids = [m for m in M if m not in merged]

    # ---- joins resolved to IDs through the Index (names in the link columns, never formula columns)
    fields_of_metric, metrics_of_field = {}, {}
    for x in m2f:
        mi, fi = rid("Metrics", x.get("Metric")), rid("Fields", x.get("Field"))
        if mi and fi: fields_of_metric.setdefault(mi, set()).add(fi); metrics_of_field.setdefault(fi, set()).add(mi)
    products_of_metric, metrics_of_product = {}, {}
    for x in m2p:
        mi, pi = rid("Metrics", x.get("Metric")), rid("Products", x.get("Product"))
        if mi and pi: products_of_metric.setdefault(mi, set()).add(pi); metrics_of_product.setdefault(pi, set()).add(mi)
    inputs_of_product, how_in = {}, {}
    for x in pinputs:
        pi, ti = rid("Products", x.get("Product")), rid("Tables", x.get("Table"))
        if pi and ti:
            inputs_of_product.setdefault(pi, []).append(ti) if ti not in inputs_of_product.setdefault(pi, []) else None
            if not blank(x.get("How it gets in")): how_in.setdefault(pi, set()).add(x.get("How it gets in"))
    products_of_dimension = {}
    for x in dusage:
        pi, di = rid("Products", x.get("Product")), rid("Dimensions", x.get("Dimension"))
        if pi and di: products_of_dimension.setdefault(di, set()).add(pi)
    table_of_field = {fid: rid("Tables", f.get("Table")) for fid, f in F.items()}
    tables_of_metric = {mid: [t for t in W.split_ids(m.get("h_tables_ids")) if t in T] for mid, m in M.items()}
    for mid in M:  # fall back to the fields' tables when the synced column is empty
        if not tables_of_metric[mid]:
            tables_of_metric[mid] = sorted({table_of_field[f] for f in fields_of_metric.get(mid, []) if table_of_field.get(f)})

    # ---- table depth and chains
    def depth_of(tid, seen=None):
        seen = seen or set()
        if tid in seen or tid not in T: return 0
        parents = [p for p in W.split_ids(T[tid].get("h_built_from_ids")) if p in T]
        return 0 if not parents else 1 + max(depth_of(p, seen | {tid}) for p in parents)
    tdepth = {tid: depth_of(tid) for tid in T}

    def chain(pid):
        direct = list(inputs_of_product.get(pid, [])) or [t for t in W.split_ids(P[pid].get("h_reads_ids")) if t in T]
        seen, order = set(), []
        def walk(tid, depth):
            if tid in seen or tid not in T: return
            seen.add(tid); order.append((tid, depth))
            for p in W.split_ids(T[tid].get("h_built_from_ids")): walk(p, depth + 1)
        for tid in direct: walk(tid, 0)
        building = sorted({s for t, _ in order for s in W.split_ids(T[t].get("h_built_by_id")) if s in S})
        fed_by = [s for s in W.split_ids(P[pid].get("h_fed_ids")) if s in S]
        mids = sorted(m for m in metrics_of_product.get(pid, []) if m in M and m not in merged)
        fids = sorted({f for m in mids for f in fields_of_metric.get(m, []) if f in F})
        return {"direct": direct, "order": order, "building": building, "fed_by": fed_by, "scripts": sorted(set(building) | set(fed_by)), "metrics": mids, "fields": fids}
    chains = {pid: chain(pid) for pid in P}
    chain_tables = {pid: {t for t, _ in c["order"]} for pid, c in chains.items()}

    def products_reading_table(tid): return sorted(pid for pid in P if tid in chain_tables[pid])
    def products_of_script(sid):
        out = set(p for p in W.split_ids(S[sid].get("h_feeds_ids")) if p in P)
        for t in W.split_ids(S[sid].get("h_writes_ids")): out.update(products_reading_table(t))
        return sorted(out)
    def products_of_field(fid): return sorted({p for m in metrics_of_field.get(fid, []) for p in products_of_metric.get(m, [])})

    # ---- metric overlaps
    overlaps = []
    def def_sim(a, b):
        if blank(a.get("Definition (plain words)")) or blank(b.get("Definition (plain words)")): return 0.0
        seq = sim(a.get("Definition (plain words)"), b.get("Definition (plain words)"))
        ta = tokens(" ".join(str(a.get(k) or "") for k in ("Definition (plain words)", "Who is counted", "Who is left out")))
        tb = tokens(" ".join(str(b.get(k) or "") for k in ("Definition (plain words)", "Who is counted", "Who is left out")))
        return max(seq, jaccard(ta, tb))
    for i in range(len(live_mids)):
        for j in range(i + 1, len(live_mids)):
            ia, ib = live_mids[i], live_mids[j]; a, b = M[ia], M[ib]
            ns = max(sim(a.get("Metric name"), b.get("Metric name")), jaccard(tokens(a.get("Metric name")), tokens(b.get("Metric name"))))
            ds = def_sim(a, b)
            fa = {bare_field_name(fname(f)) for f in fields_of_metric.get(ia, [])}
            fb = {bare_field_name(fname(f)) for f in fields_of_metric.get(ib, [])}
            fs = jaccard(fa, fb) if fa and fb else 0.0
            same_fam = not blank(a.get("Metric family")) and a.get("Metric family") == b.get("Metric family")
            score = ns * 0.4 + ds * 0.35 + fs * 0.25 + (0.1 if same_fam else 0)
            if score < 0.45: continue
            reasons = []
            if ns > 0.6: reasons.append("names alike")
            if ds > 0.7: reasons.append("definitions nearly identical")
            elif ds > 0.4: reasons.append("definitions overlap")
            if fs > 0.6: reasons.append("same fields")
            elif fs > 0.3: reasons.append("share fields")
            if same_fam: reasons.append("same family")
            ta_, tb_ = set(tables_of_metric[ia]), set(tables_of_metric[ib])
            missing = [mname(m) for m, row in ((ia, a), (ib, b)) if blank(row.get("Definition (plain words)"))]
            if missing:
                verdict = "Definition missing on " + " and ".join(missing) + "; cannot compare."
            elif fs > 0.6 and ta_ and tb_ and not (ta_ & tb_):
                verdict = f"Same fields pulled from different tables: {', '.join(names(tname, sorted(ta_)))} vs {', '.join(names(tname, sorted(tb_)))}; agree one source."
            elif ds > 0.85 and fs > 0.6:
                verdict = "Probably the same metric: one row, the other merged."
            elif same_fam and ds < 0.6:
                verdict = "Same family, different rule: align or rename with the difference in brackets."
            elif ns > 0.6 and ds < 0.4:
                verdict = "Same words, different meaning: rename one so nobody confuses them."
            else:
                verdict = "Related: confirm whether one is a cut of the other."
            overlaps.append({"a_name": mname(ia), "b_name": mname(ib), "a_id": ia, "b_id": ib, "score": round(score, 2), "name_sim": round(ns, 2), "def_sim": round(ds, 2), "field_sim": round(fs, 2), "same_family": same_fam, "reasons": reasons, "verdict": verdict,
                             "tables_a": names(tname, sorted(ta_)), "tables_b": names(tname, sorted(tb_)), "table_ids_a": sorted(ta_), "table_ids_b": sorted(tb_),
                             "products_a": names(pname, sorted(products_of_metric.get(ia, []))), "products_b": names(pname, sorted(products_of_metric.get(ib, []))),
                             "product_ids_a": sorted(products_of_metric.get(ia, [])), "product_ids_b": sorted(products_of_metric.get(ib, []))})
    overlaps.sort(key=lambda x: -x["score"])

    # ---- product overlaps
    def tables_for(mid, pid):
        """tables a metric is pulled from inside one product: the metric's field tables that sit in the product's chain,
        else (metric not traced to fields in that chain) the product's direct input tables"""
        hit = set(tables_of_metric.get(mid, [])) & chain_tables[pid]
        return hit if hit else set(inputs_of_product.get(pid, []))
    poverlaps = []
    pids = list(P)
    for i in range(len(pids)):
        for j in range(i + 1, len(pids)):
            pa, pb = pids[i], pids[j]
            ma, mb = metrics_of_product.get(pa, set()) - merged, metrics_of_product.get(pb, set()) - merged
            ta, tb = chain_tables[pa], chain_tables[pb]
            ms, ts_ = jaccard(ma, mb), jaccard(ta, tb)
            fam_a = {M[m].get("Metric family") for m in ma if m in M and not blank(M[m].get("Metric family"))}
            fam_b = {M[m].get("Metric family") for m in mb if m in M and not blank(M[m].get("Metric family"))}
            fams = jaccard(fam_a, fam_b)
            score = ms * 0.5 + fams * 0.3 + ts_ * 0.2
            if score < 0.25: continue
            same_aud = not blank(P[pa].get("Audience")) and P[pa].get("Audience") == P[pb].get("Audience")
            diff_tables = []
            for m in sorted(ma & mb):
                sa, sb = tables_for(m, pa), tables_for(m, pb)
                if sa != sb: diff_tables.append({"metric": mname(m), "metric_id": m, "tables_a": names(tname, sorted(sa)), "tables_b": names(tname, sorted(sb))})
            poverlaps.append({"a_name": pname(pa), "b_name": pname(pb), "a_id": pa, "b_id": pb, "score": round(score, 2),
                              "shared_metrics": names(mname, sorted(ma & mb)), "shared_metric_ids": sorted(ma & mb), "shared_families": sorted(fam_a & fam_b),
                              "shared_tables": names(tname, sorted(ta & tb)), "shared_table_ids": sorted(ta & tb), "same_audience": bool(same_aud),
                              "shared_metric_different_tables": [d["metric"] for d in diff_tables], "shared_metric_different_tables_detail": diff_tables,
                              "verdict": ("Same audience and largely the same metrics: why do both exist?" if same_aud and ms > 0.5 else "Overlapping content for different audiences: candidates to serve from one certified source" if ms > 0.3 or fams > 0.5 else "Share sources more than content")})
    poverlaps.sort(key=lambda x: -x["score"])

    # ---- automation per product, from the whole chain
    automation = {}
    for pid, c in chains.items():
        p = P[pid]; order, scripts = c["order"], c["scripts"]
        last_hop = p.get("Last hop into the product"); last_hop_source = "product row"
        if blank(last_hop):
            hops = how_in.get(pid, set())
            if len(hops) == 1: last_hop = next(iter(hops)); last_hop_source = "Product inputs (How it gets in)"
            elif MANUAL_LAST_HOP in hops: last_hop = MANUAL_LAST_HOP; last_hop_source = "Product inputs (one input is pasted by hand)"
            else: last_hop = "Unknown"; last_hop_source = "not recorded"
        manual_tables = [t for t, _ in order if T[t].get("Kind") == "Manual spreadsheet"]
        manual_scripts = [s for s in scripts if S[s].get("Trigger") == "Manual run" or S[s].get("Kind") == "Manual process"]
        unknown_scripts = [s for s in scripts if S[s].get("Trigger") not in ("Scheduled", "On demand", "Manual run")]
        pasted = last_hop == MANUAL_LAST_HOP
        steps = []
        for t in manual_tables: steps.append(f"{tname(t)} is a spreadsheet kept by hand")
        for s in manual_scripts: steps.append(f"{sname(s)} is run by a person ({S[s].get('Kind') or 'kind not recorded'}, trigger {S[s].get('Trigger') or 'not recorded'})")
        if pasted: steps.append(f"the last hop into {pname(pid)} is pasted by hand")
        if not blank(p.get("Manual steps")): steps.append(f"recorded on the product: {p.get('Manual steps')}")
        if pasted and not scripts: derived = "Manual"
        elif manual_scripts or manual_tables or pasted: derived = "Partly manual"
        elif scripts and not unknown_scripts and last_hop in AUTOMATED_LAST_HOPS: derived = "Automated"
        else: derived = "Unknown"
        recorded = p.get("Automation level") if not blank(p.get("Automation level")) else None
        hours = num(p.get("Manual effort (hours per cycle)"))
        depth = max([d for _, d in order], default=0)
        only_last_hop = pasted and not manual_tables and not manual_scripts
        lhf = round(hours * (1 / (1 + depth)) + (0.5 if only_last_hop else 0), 2)
        no_notice = [s for s in scripts if S[s].get("Failure notice") in NO_NOTICE or blank(S[s].get("Failure notice"))]
        automation[pid] = {"product": pname(pid), "product_id": pid, "derived": derived, "recorded": recorded, "agree": (recorded == derived) if recorded else None,
                           "last_hop": last_hop, "last_hop_source": last_hop_source, "manual_steps": steps, "hours_per_cycle": hours, "depth": depth,
                           "tables": len(order), "manual_spreadsheets": names(tname, manual_tables), "manual_spreadsheet_ids": manual_tables,
                           "scripts": names(sname, scripts), "script_ids": scripts, "manual_scripts": names(sname, manual_scripts), "manual_script_ids": manual_scripts,
                           "metrics": len(c["metrics"]), "only_manual_step_is_last_hop": only_last_hop, "low_hanging_score": lhf,
                           "no_failure_notice": [f"{sname(s)} ({S[s].get('Failure notice') or 'not recorded'})" for s in no_notice], "no_failure_notice_ids": no_notice}

    # ---- stages
    stages = {}
    for i_ in inc:
        s = i_.get("Root stage") if not blank(i_.get("Root stage")) else "Unknown"
        d = stages.setdefault(s, {"incidents": 0, "hours": 0.0, "recurring": 0, "products": set(), "product_ids": set()})
        d["incidents"] += 1; d["hours"] += num(i_.get("Time to resolve (hours)"))
        if i_.get("Recurring?") == "Yes": d["recurring"] += 1
        pi = rid("Products", i_.get("Product"))
        if pi: d["products"].add(pname(pi)); d["product_ids"].add(pi)
    for d in stages.values(): d["products"] = sorted(d["products"]); d["product_ids"] = sorted(d["product_ids"])
    field_stages = {}
    for f in F.values():
        if f.get("Data quality") == "Issue":
            st = f.get("Root stage of issue") if not blank(f.get("Root stage of issue")) else "Unknown"
            field_stages[st] = field_stages.get(st, 0) + 1

    # ---- validation queue: every Proposed row, impact = number of products reached
    def reach(sheet, row):
        if sheet == "Products": return [row["Product ID"]] if row.get("Product ID") in P else []
        if sheet == "Metrics": return sorted(products_of_metric.get(row.get("Metric ID"), []))
        if sheet == "Tables": return products_reading_table(row.get("Table ID"))
        if sheet == "Scripts": return products_of_script(row["Script ID"]) if row.get("Script ID") in S else []
        if sheet == "Fields": return products_of_field(row.get("Field ID"))
        if sheet in ("Product inputs", "Dimension usage", "Incidents"):
            pi = rid("Products", row.get("Product")); return [pi] if pi else []
        if sheet == "Metric to Product":
            pi = rid("Products", row.get("Product")); return [pi] if pi else []
        if sheet == "Metric to Field": return sorted(products_of_metric.get(rid("Metrics", row.get("Metric")), []))
        if sheet == "Dimensions": return sorted(products_of_dimension.get(row.get("Dimension ID"), []))
        return []
    def row_name(sheet, row):
        key = W.SHEETS[sheet].get("key")
        if key: return row.get(key)
        if sheet == "Product inputs": return f"{row.get('Product')} reads {row.get('Table')}"
        if sheet == "Metric to Product": return f"{row.get('Metric')} shown in {row.get('Product')}"
        if sheet == "Metric to Field": return f"{row.get('Metric')} uses {row.get('Field')}"
        if sheet == "Dimension usage": return f"{row.get('Product')} maps {row.get('Dimension')} from {row.get('Mapping source table')}"
        if sheet == "Incidents": return f"{row.get('Product')}: {row.get('What was reported') or row.get('Symptom') or ''}".strip(": ")
        return None
    queue = []
    for sheet in QUEUE_SHEETS:
        pcols = propose_cols(sheet); idc = W.SHEETS[sheet]["columns"][0]["name"]
        for row in rows(sheet):
            if row.get("Review") != "Proposed": continue
            reached = reach(sheet, row)
            queue.append({"sheet": sheet, "row": row["_row"], "id": row.get(idc) if W.SHEETS[sheet]["id_prefix"] else None, "name": row_name(sheet, row),
                          "impact": len(reached), "products_reached": names(pname, reached), "product_ids_reached": reached,
                          "proposed": {k: row.get(k) for k in pcols if not blank(row.get(k))},
                          "source": row.get("Source (where found)"), "confidence": row.get("Confidence")})
    queue.sort(key=lambda q: (-q["impact"], q["sheet"], q["row"]))

    # ---- front page counts
    defs = {}
    for mid in live_mids:
        k = norm_def(M[mid].get("Definition (plain words)"))
        if k: defs.setdefault(k, []).append(mid)
    fam_defs = {}
    for mid in live_mids:
        fam, k = M[mid].get("Metric family"), norm_def(M[mid].get("Definition (plain words)"))
        if not blank(fam) and k: fam_defs.setdefault(fam, set()).add(k)
    open_q = [q for q in questions if q.get("Status") == "Open"]
    pasted_products = [pid for pid in P if automation[pid]["last_hop"] == MANUAL_LAST_HOP]
    manual_readers = [pid for pid in P if automation[pid]["manual_spreadsheets"]]
    levels = ["Automated", "Partly manual", "Manual", "Unknown"]
    front = {
        "metrics": {"total": len(live_mids), "distinct_definitions": len(defs), "same_definition_groups": sum(1 for v in defs.values() if len(v) > 1),
                    "families_with_more_than_one_definition": sum(1 for v in fam_defs.values() if len(v) > 1),
                    "reading_two_or_more_tables": sum(1 for m in live_mids if len(tables_of_metric[m]) >= 2),
                    "no_definition": sum(1 for m in live_mids if blank(M[m].get("Definition (plain words)")))},
        "tables": {"total": len(T), "depth_2_or_more": sum(1 for t in T if tdepth[t] >= 2), "manual_spreadsheets": sum(1 for t in T.values() if t.get("Kind") == "Manual spreadsheet"),
                   "custom_with_no_builder": sum(1 for t in T.values() if t.get("Kind") == "Team custom" and not [s for s in W.split_ids(t.get("h_built_by_id")) if s in S])},
        "products": {"total": len(P), "by_automation_derived": {lv: sum(1 for a in automation.values() if a["derived"] == lv) for lv in levels},
                     "by_automation_recorded": {lv: sum(1 for a in automation.values() if a["recorded"] == lv) for lv in levels} | {"not recorded": sum(1 for a in automation.values() if not a["recorded"])},
                     "pasted_by_hand": len(pasted_products), "reading_manual_spreadsheets": len(manual_readers)},
        "scripts": {"total": len(S), "manual_run": sum(1 for s in S.values() if s.get("Trigger") == "Manual run"), "nobody_told": sum(1 for s in S.values() if s.get("Failure notice") == "Nobody is told")},
        "review": {"proposed_rows": len(queue), "open_questions": len(open_q)},
    }

    return {"generated": datetime.date.today().isoformat(), "front_page": front,
            "counts": {"products": len(P), "metrics": len(live_mids), "tables": len(T), "fields": len(F), "scripts": len(S), "incidents": len(inc), "proposed": len(queue), "open_questions": len(open_q)},
            "metric_overlaps": overlaps, "product_overlaps": poverlaps, "automation": automation, "stages": stages, "field_issue_stages": field_stages, "queue": queue,
            "chains": {pid: {"product": pname(pid), "metrics": names(mname, c["metrics"]), "metric_ids": c["metrics"], "fields": names(fname, c["fields"]), "field_ids": c["fields"],
                             "tables": [{"name": tname(t), "id": t, "depth": d, "kind": T[t].get("Kind")} for t, d in c["order"]],
                             "scripts": names(sname, c["scripts"]), "script_ids": c["scripts"], "fed_by": names(sname, c["fed_by"]), "fed_by_ids": c["fed_by"]} for pid, c in chains.items()}}


# ---------------------------------------------------------------- markdown
def to_md(a):
    L = [f"# Analysis ({a['generated']})", ""]
    fp = a["front_page"]; m, t, p, s, r = fp["metrics"], fp["tables"], fp["products"], fp["scripts"], fp["review"]
    L.append("## Front page")
    L.append(f"- **Metrics**: {m['total']} total; {m['distinct_definitions']} distinct definitions; {m['same_definition_groups']} groups sharing a definition; {m['families_with_more_than_one_definition']} families with more than one definition; {m['reading_two_or_more_tables']} reading two or more tables; {m['no_definition']} with no definition")
    L.append(f"- **Tables**: {t['total']} total; {t['depth_2_or_more']} at depth 2 or more; {t['manual_spreadsheets']} manual spreadsheets; {t['custom_with_no_builder']} custom tables with no builder")
    der = ", ".join(f"{k} {v}" for k, v in p["by_automation_derived"].items()); rec = ", ".join(f"{k} {v}" for k, v in p["by_automation_recorded"].items())
    L.append(f"- **Products**: {p['total']} total; derived automation: {der}; recorded automation: {rec}; {p['pasted_by_hand']} pasted by hand; {p['reading_manual_spreadsheets']} reading manual spreadsheets")
    L.append(f"- **Scripts**: {s['total']} total; {s['manual_run']} run by hand; {s['nobody_told']} where nobody is told on failure")
    L.append(f"- **Review**: {r['proposed_rows']} proposed rows; {r['open_questions']} open questions")
    L.append("\n## Metrics that may be the same thing")
    for o in a["metric_overlaps"][:40]:
        L.append(f"- **{o['a_name']}** vs **{o['b_name']}** (score {o['score']}; {', '.join(o['reasons']) or 'weak signals'}). {o['verdict']}")
    if not a["metric_overlaps"]: L.append("- none above the threshold")
    L.append("\n## Products that overlap")
    for o in a["product_overlaps"]:
        L.append(f"- **{o['a_name']}** vs **{o['b_name']}** (score {o['score']}): {len(o['shared_metrics'])} shared metrics, families {', '.join(o['shared_families']) or 'none'}, {len(o['shared_tables'])} shared tables. {o['verdict']}" + (f" Shared metrics pulled from different tables: {', '.join(o['shared_metric_different_tables'])}." if o['shared_metric_different_tables'] else ""))
    if not a["product_overlaps"]: L.append("- none above the threshold")
    L.append("\n## Automation")
    for pid, x in sorted(a["automation"].items(), key=lambda kv: -kv[1]["low_hanging_score"]):
        L.append(f"- **{x['product']}**: {x['derived']}" + (f" (recorded {x['recorded']}, disagrees)" if x['agree'] is False else (" (recorded level not set)" if x['recorded'] is None else "")) + f"; last hop {x['last_hop']}; {x['hours_per_cycle']:g}h/cycle; chain depth {x['depth']}, {x['tables']} tables, scripts {', '.join(x['scripts']) or 'none'}; low-hanging score {x['low_hanging_score']}" + (f"; manual steps: " + "; ".join(x['manual_steps']) if x['manual_steps'] else "") + (f"; scripts with no failure notice: {', '.join(x['no_failure_notice'])}" if x['no_failure_notice'] else ""))
    L.append("\n## Incidents by root stage")
    for st, d in sorted(a["stages"].items(), key=lambda kv: -kv[1]["incidents"]):
        L.append(f"- **{st}**: {d['incidents']} incidents, {d['hours']:.0f} hours, {d['recurring']} recurring, products {', '.join(d['products']) or 'none'}")
    if not a["stages"]: L.append("- no incidents logged")
    L.append("\n## Field issues by root stage")
    for st, n in sorted(a["field_issue_stages"].items(), key=lambda kv: -kv[1]): L.append(f"- **{st}**: {n} fields")
    if not a["field_issue_stages"]: L.append("- no field issues recorded")
    L.append("\n## Validation queue (top 30)")
    for q in a["queue"][:30]:
        prop = "; ".join(f"{k} = {v}" for k, v in q['proposed'].items()) or "nothing proposed in the Propose columns"
        L.append(f"- [{q['sheet']}] **{q['name']}** (reaches {q['impact']} product{'s' if q['impact'] != 1 else ''}{': ' + ', '.join(q['products_reached']) if q['products_reached'] else ''}): {prop}")
    if not a["queue"]: L.append("- nothing awaiting review")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out", default="analysis.json"); ap.add_argument("--md")
    a = ap.parse_args()
    res = analyze(a.path)
    json.dump(res, open(a.out, "w"), indent=2, default=str)
    if a.md: open(a.md, "w").write(to_md(res))
    c = res["counts"]; print(f"wrote {a.out}: {len(res['metric_overlaps'])} metric overlap pairs, {len(res['product_overlaps'])} product overlaps, {c['proposed']} proposed rows in queue, {c['open_questions']} open questions")


if __name__ == "__main__":
    main()
