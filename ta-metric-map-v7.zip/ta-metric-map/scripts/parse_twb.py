#!/usr/bin/env python3
"""
Extract the inventory from a Tableau workbook (.twb or .twbx) into JSON.

Usage:
    python3 parse_twb.py <workbook.twb|.twbx> [-o out.json]

What it pulls out, per workbook:
  datasources      name, caption, connection class, database/schema/table or custom SQL
  fields           per datasource: name, caption, datatype, role, and for calculated
                   fields the formula (with Tableau's internal names translated to captions)
  worksheets       name, which datasource(s) it uses, which fields appear, filters applied
  dashboards       name and the worksheets on it
  refresh          extract refresh settings, when present

Nothing here interprets meaning. It reports what the file says, so the caller can
decide what is a metric, what is a dimension, and what is a table.
"""
import argparse, json, re, sys, zipfile, io
from xml.etree import ElementTree as ET


def load_xml(path):
    if path.lower().endswith(".twbx"):
        with zipfile.ZipFile(path) as z:
            twbs = [n for n in z.namelist() if n.lower().endswith(".twb")]
            if not twbs:
                raise SystemExit(f"No .twb inside {path}")
            return ET.fromstring(z.read(twbs[0]))
    return ET.parse(path).getroot()


def strip_brackets(s):
    """[A] -> A ; [A].[B] -> A.B"""
    if not s:
        return s
    parts = re.findall(r"\[([^\]]+)\]", s)
    return ".".join(parts) if parts else s


def parse(path):
    root = load_xml(path)
    out = {"file": path, "datasources": [], "worksheets": [], "dashboards": [], "notes": []}

    # ---- datasources
    top = root.find("datasources")
    ds_list = list(top.findall("datasource")) if top is not None else []
    for ds in ds_list:
        name = ds.get("name"); caption = ds.get("caption") or name
        if name == "Parameters":
            continue
        d = {"name": name, "caption": caption, "connections": [], "fields": [], "field_map": {}}
        for conn in ds.iter("connection"):
            cls = conn.get("class")
            if cls in (None, "federated"):
                continue
            d["connections"].append({
                "class": cls, "server": conn.get("server"), "dbname": conn.get("dbname"),
                "schema": conn.get("schema"), "warehouse": conn.get("warehouse"),
            })
        for rel in ds.iter("relation"):
            typ = rel.get("type")
            if typ == "table":
                d.setdefault("tables", []).append({"name": rel.get("name"), "table": strip_brackets(rel.get("table") or "")})
            elif typ == "text":
                d.setdefault("custom_sql", []).append({"name": rel.get("name"), "sql": (rel.text or "").strip()})
        # columns (fields)
        for col in ds.findall("column"):
            fname = col.get("name"); fcap = col.get("caption") or strip_brackets(fname)
            calc = col.find("calculation")
            f = {
                "name": fname, "caption": fcap, "datatype": col.get("datatype"), "role": col.get("role"),
                "type": col.get("type"), "hidden": col.get("hidden") == "true",
                "calculated": calc is not None, "formula": calc.get("formula") if calc is not None else None,
            }
            d["fields"].append(f); d["field_map"][fname] = fcap
        # metadata-records give the physical column names behind each field
        for mr in ds.iter("metadata-record"):
            if mr.get("class") != "column":
                continue
            local = mr.findtext("local-name"); remote = mr.findtext("remote-name"); parent = mr.findtext("parent-name")
            if local:
                for f in d["fields"]:
                    if f["name"] == local:
                        f["physical_column"] = remote; f["physical_table"] = strip_brackets(parent or "")
                if local not in d["field_map"]:
                    d["fields"].append({"name": local, "caption": strip_brackets(local), "datatype": mr.findtext("local-type"),
                                        "role": None, "type": None, "hidden": False, "calculated": False, "formula": None,
                                        "physical_column": remote, "physical_table": strip_brackets(parent or "")})
                    d["field_map"][local] = strip_brackets(local)
        # translate internal names in formulas to captions
        for f in d["fields"]:
            if f["formula"]:
                def sub(m):
                    return "[" + d["field_map"].get(m.group(0), strip_brackets(m.group(0))) + "]"
                f["formula_readable"] = re.sub(r"\[[^\]]+\]", sub, f["formula"])
        # extract refresh
        ext = ds.find("extract")
        if ext is not None:
            d["extract"] = {"enabled": ext.get("enabled"), "count": ext.get("count")}
        out["datasources"].append(d)

    # ---- worksheets
    for wsx in root.iter("worksheet"):
        w = {"name": wsx.get("name"), "datasources": [], "fields_used": [], "filters": [], "title": None}
        for dep in wsx.iter("datasource-dependencies"):
            dsname = dep.get("datasource"); w["datasources"].append(dsname)
            for col in dep.findall("column"):
                w["fields_used"].append({"datasource": dsname, "name": col.get("name"), "caption": col.get("caption") or strip_brackets(col.get("name"))})
        for flt in wsx.iter("filter"):
            w["filters"].append({"column": flt.get("column"), "class": flt.get("class")})
        t = wsx.find(".//title")
        if t is not None:
            w["title"] = "".join(t.itertext()).strip() or None
        out["worksheets"].append(w)

    # ---- dashboards
    for db in root.iter("dashboard"):
        zones = [z.get("name") for z in db.iter("zone") if z.get("name")]
        out["dashboards"].append({"name": db.get("name"), "worksheets": sorted(set(zones))})

    if not out["datasources"]:
        out["notes"].append("No datasources found. Is this a .twb exported from Tableau Desktop or Server?")
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out")
    a = ap.parse_args()
    data = parse(a.path)
    js = json.dumps(data, indent=2)
    if a.out:
        open(a.out, "w").write(js); print(f"wrote {a.out}: {len(data['datasources'])} datasources, {len(data['worksheets'])} worksheets, {len(data['dashboards'])} dashboards")
    else:
        print(js)


if __name__ == "__main__":
    main()
