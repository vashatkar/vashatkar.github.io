#!/usr/bin/env python3
"""
Mechanical self-check for the TA metric map workbook (v7). Standard library + openpyxl.

    python3 check_quality.py <map.xlsx> [-o findings.json] [--batches review_dir]

Writes findings.json (list of {sheet,row,id,name,column,severity,rule,message,value,suggest,auto}), prints a
per-rule summary, exits 1 if any error. With --batches, writes review_dir/<sheet>_<n>.json (50 rows per file)
holding every row that has a finding or is still Proposed, for the LLM reviewer.

Rules. "Proposed" rules run only on rows whose Review is Proposed (sheets without a Review column count as
Proposed); the rest run on every row.
  R1  fragment (Proposed, error): free text under 25 chars, ending in a stop word, or a prefix of the row's name.
  R2  sentence (Proposed, warn, auto): free text not ending in . ? ) or starting lowercase.
  R3  ID leak (error, auto when every ID resolves): a code like M-012 in a name/text/dropdown/link column.
  R4  code-speak (Proposed, error): formula functions, NULL, [bracketed fields], snake_case in Definition/Logic/Why/Who.
  R5  filler (Proposed, warn): "This metric/table/field ...", em dash, bullet list in free text.
  R6  family (error): Metric family not on the Families list, or equal to the first words of the metric name.
  R7  family lonely (info): a family used by exactly one metric.
  R8  duplicate definition (error): two metrics whose normalised definition+counted+left out match (Jaccard >= 0.9).
  R9  same name, two definitions (warn if the names carry brackets, else error).
  R10 same "Formula:" text in Notes on two metrics (error).
  R11 metric reads 2+ tables and Notes does not say "join" (warn).
  R12 two metrics with the same field names but disjoint tables (warn).
  R13 Team custom table with no Built by and no open question (error).
  R14 product with nothing feeding it: blank Reads from and no Metric to Product row (error).
  R15 metric orphan: no Metric to Field / Metric to Product row (warn); blank Definition (error unless questioned).
  R16 Proposed row with blank Source (error).
  R17 Proposed row with blank Machine-owned columns (in/dd/link; Notes and a Raw field's Logic excluded) and no open question (warn).
  R18 value not in the column's dropdown (error).
  R19 Disposition filled on a Proposed row (error).
  R20 linkid cached as "Not found", or a link / names value that does not resolve (error).
  R21 duplicate key name on an entity sheet, case-insensitive (error).
  R22 script with blank Writes and blank Feeds (warn).
  R23 HRDW / Platform extract table with blank Platform (info).
"""
import json, os, re, sys
from collections import defaultdict
from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import workbook as W

FREE_TEXT = {"Definition (plain words)", "Why it exists", "Manual steps", "Logic (the business rule)", "How it is shown",
             "Who runs it", "Root cause (plain words)", "Issue / note", "What was reported", "Question"}
CODE_COLS = {"Definition (plain words)", "Logic (the business rule)", "Why it exists", "Who is counted", "Who is left out"}
STOP_END = {"of", "the", "per", "and", "to", "avg", "by", "with", "for"}
STOP_WORDS = STOP_END | {"a", "an", "in", "on", "or", "is", "are", "from", "at", "as", "that", "this", "it", "its", "be", "all", "any"}
ID_RE = re.compile(r"\b(P|M|T|S|F|D|I|DL|Q)-\d{3,}\b")
CODE_RE = re.compile(r"DATEDIFF|COUNTD|SUMIFS?\(|AVERAGEIFS?\(|COUNTIFS?\(|\bIF\(|\bNULL\b|\[[A-Za-z_ ]+\]|\w+_\w+_\w+")
FAMILIES = W.SCHEMA["families"]
COMPUTED = ("f", "h", "linkid", "ids")


def txt(v): return "" if v is None else str(v).strip()
def blank(v): return txt(v) == ""
def split_names(v): return [x.strip() for x in re.split(r"[,;]\s*", txt(v)) if x.strip()]
def norm_tokens(s): return {t for t in re.sub(r"[^\w\s]", " ", s.lower()).split() if t not in STOP_WORDS}
def strip_bracket(s): return re.sub(r"\s*\([^)]*\)\s*$", "", txt(s))
def jaccard(a, b): return len(a & b) / len(a | b) if (a | b) else 0.0


class Checker:
    def __init__(self, path):
        self.wb = load_workbook(path); self.cached = load_workbook(path, data_only=True)
        self.idx = W.Index(self.wb); self.findings = []
        self.names_by_id = {i: n for s in self.idx.by_id for i, n in self.idx.by_id[s].items()}
        self.rows = {s: W.rows_raw(self.wb[s], s) for s in W.SHEETS}
        self.open_q = defaultdict(list)  # sheet -> [(row id, about lower)]
        for r, q in self.rows["Questions"]:
            if q.get("Status") == "Open": self.open_q[txt(q.get("Sheet"))].append((txt(q.get("h_row_id")), txt(q.get("About")).lower()))

    # ---- helpers -------------------------------------------------------------------------------------------
    def ident(self, sheet, row):
        d = W.SHEETS[sheet]; rid = txt(row.get(d["columns"][0]["name"])) if d["id_prefix"] else None
        if d.get("key"): name = txt(row.get(d["key"]))
        elif sheet == "Questions": name = txt(row.get("About"))
        else: name = " -> ".join(txt(row.get(c)) for c in W.link_cols(sheet)[:2])
        return rid, name

    def questioned(self, sheet, rid, name):
        return any((rid and q[0] == rid) or (name and q[1] == name.lower()) for q in self.open_q.get(sheet, []))

    def add(self, sheet, r, rid, name, col, sev, rule, msg, value=None, suggest=None, auto=False):
        self.findings.append({"sheet": sheet, "row": r, "id": rid, "name": name, "column": col, "severity": sev, "rule": rule,
                              "message": msg, "value": None if value is None else str(value)[:300], "suggest": suggest, "auto": auto})

    def is_proposed(self, sheet, row):
        return "Review" not in W.cols(sheet) or row.get("Review") == "Proposed"

    # ---- per-row rules -------------------------------------------------------------------------------------
    def check_row(self, sheet, r, row):
        rid, name = self.ident(sheet, row); proposed = self.is_proposed(sheet, row); cs = W.cols(sheet)
        A = lambda col, sev, rule, msg, value=None, suggest=None, auto=False: self.add(sheet, r, rid, name, col, sev, rule, msg, value, suggest, auto)
        blanks = []; raw_field = sheet == "Fields" and row.get("Type") == "Raw"
        for c in W.SHEETS[sheet]["columns"]:
            n, k = c["name"], c["kind"]; v = row.get(n); s = txt(v)
            if k == "linkid":
                if self.cached[sheet].cell(row=r, column=cs[n]).value == "Not found":
                    A(n, "error", "R20", "A link on this row does not match any row on the target sheet.", "Not found")
                continue
            if k in COMPUTED: continue
            if proposed and c["who"] == "Machine" and k in ("in", "dd", "link") and n != "Notes" and blank(v):
                if not (raw_field and n in ("Logic (the business rule)", "Where the rule lives")): blanks.append(n)
            if blank(v): continue
            if c.get("dropdown") and s not in c["dropdown"]:
                A(n, "error", "R18", f"'{s}' is not one of the allowed values ({', '.join(c['dropdown'])}).", s)
            if k == "link" and n in W.SINGLE_LINK_TARGET and self.idx.resolve(W.SINGLE_LINK_TARGET[n], s)[0] is None:
                A(n, "error", "R20", f"'{s}' is not a row on {W.SINGLE_LINK_TARGET[n]}.", s)
            if k == "names" and W.LINK_TARGET.get((sheet, n)):
                bad = self.idx.resolve_list(W.LINK_TARGET[(sheet, n)], s)[2]
                if bad: A(n, "error", "R20", f"{', '.join(bad)} not found on {W.LINK_TARGET[(sheet, n)]}.", s)
            if k in ("in", "names", "link", "key", "dd") and ID_RE.search(s):
                ids = ID_RE.findall(s); fixed = ID_RE.sub(lambda m: self.names_by_id.get(m.group(0), m.group(0)), s)
                ok = not ID_RE.search(fixed)
                A(n, "error", "R3", "Shows a code where a name belongs.", s, fixed if ok else None, ok)
            if proposed and n in FREE_TEXT: self.check_text(sheet, r, rid, name, n, s)
            if proposed and n in CODE_COLS and CODE_RE.search(s):
                A(n, "error", "R4", "Formula-speak; move to Notes and write it in words.", s)
        if proposed:
            if "Source (where found)" in cs and blank(row.get("Source (where found)")): A("Source (where found)", "error", "R16", "Proposed row with no source.")
            if blanks and not self.questioned(sheet, rid, name): A(", ".join(blanks), "warn", "R17", f"Blank and no open question about this row: {', '.join(blanks)}.")
            if "Disposition" in cs and not blank(row.get("Disposition")): A("Disposition", "error", "R19", "Disposition is a person's decision; it must be blank while the row is Proposed.", row.get("Disposition"))
        if sheet == "Tables":
            if row.get("Kind") == "Team custom" and blank(row.get("Built by")) and not self.questioned(sheet, rid, name): A("Built by", "error", "R13", "Team custom table with nothing recorded as building it.")
            if row.get("Kind") in ("HRDW", "Platform extract") and blank(row.get("Platform")): A("Platform", "info", "R23", "Source table without a platform; a person fills it.")
        if sheet == "Scripts" and blank(row.get("Writes")) and blank(row.get("Feeds")): A("Writes", "warn", "R22", "Nothing recorded: the script writes no table and feeds no product.")

    def check_text(self, sheet, r, rid, name, col, s):
        A = lambda sev, rule, msg, suggest=None, auto=False: self.add(sheet, r, rid, name, col, sev, rule, msg, s, suggest, auto)
        last = re.sub(r"[^\w]+$", "", s.lower()).split()[-1:] or [""]
        frag = len(s) < 25 or last[0] in STOP_END or (name and name.lower().startswith(s.lower()))
        if frag: A("error", "R1", "Fragment, not a full statement: too short, ends mid-phrase or just repeats the name.")
        else:
            fix = s
            if fix[0].islower(): fix = fix[0].upper() + fix[1:]
            if fix[-1] not in ".?)": fix += "."
            if fix != s: A("warn", "R2", "Not a sentence: start with a capital and end with a full stop.", fix, True)
        if re.match(r"(?i)this (metric|table|field)\b", s) or " — " in s or "\n- " in s: A("warn", "R5", "Filler or list formatting; say it plainly in one or two sentences.")

    # ---- cross-row rules -----------------------------------------------------------------------------------
    def check_metrics(self):
        S = "Metrics"; fam_q = {f["question"] for f in FAMILIES}; old = {f["old_name"].lower(): f["question"] for f in FAMILIES}
        m2f, m2p = defaultdict(list), set()
        for r, row in self.rows["Metric to Field"]: m2f[txt(row.get("Metric")).lower()].append(strip_bracket(row.get("Field")).lower())
        for r, row in self.rows["Metric to Product"]: m2p.add(txt(row.get("Metric")).lower())
        fam_use, defs, formulas, by_base = defaultdict(list), [], defaultdict(list), defaultdict(list)
        for r, row in self.rows[S]:
            rid, name = self.ident(S, row); A = lambda col, sev, rule, msg, value=None, suggest=None: self.add(S, r, rid, name, col, sev, rule, msg, value, suggest)
            fam = txt(row.get("Metric family")); words = name.lower().split()
            if fam:
                if fam in fam_q: fam_use[fam].append(name)
                if fam not in fam_q: A("Metric family", "error", "R6", "Not one of the families on the Families sheet.", fam, old.get(fam.lower()))
                elif fam.lower() in {" ".join(words[:i]) for i in (1, 2, 3)}: A("Metric family", "error", "R6", "The family just repeats the metric name; pick the question it answers.", fam)
            d = txt(row.get("Definition (plain words)"))
            if not d:
                if not self.questioned(S, rid, name): A("Definition (plain words)", "error", "R15", "No definition; where is it computed?")
            else: defs.append((r, rid, name, norm_tokens(" ".join([d, txt(row.get("Who is counted")), txt(row.get("Who is left out"))]))))
            missing = [j for j, has in (("Metric to Field", name.lower() in m2f), ("Metric to Product", name.lower() in m2p)) if not has]
            if missing: A("Metric name", "warn", "R15", f"No {' or '.join(missing)} row links this metric.")
            tables = split_names(row.get("Reads from tables"))
            if len(tables) > 1 and "join" not in txt(row.get("Notes")).lower(): A("Reads from tables", "warn", "R11", "Same metric reads from more than one table; confirm which is the source of truth.", row.get("Reads from tables"))
            m = re.search(r"Formula:\s*(.+?)(?:\n|\.\s+(?=[A-Z])|$)", txt(row.get("Notes")))
            if m: formulas[re.sub(r"\s+", "", m.group(1).rstrip(".").lower())].append((r, rid, name))
            by_base[strip_bracket(name).lower()].append((r, rid, name, d, norm_tokens(d), set(t.lower() for t in tables)))
        for fam, users in fam_use.items():
            if len(users) == 1:
                r, row = next((r, row) for r, row in self.rows[S] if txt(row.get("Metric family")) == fam); rid, name = self.ident(S, row)
                self.add(S, r, rid, name, "Metric family", "info", "R7", f"Only metric in the family '{fam}'.", fam)
        for i in range(len(defs)):
            for j in range(i + 1, len(defs)):
                a, b = defs[i], defs[j]
                if a[3] and (a[3] == b[3] or jaccard(a[3], b[3]) >= 0.9):
                    for x, y in ((a, b), (b, a)): self.add(S, x[0], x[1], x[2], "Definition (plain words)", "error", "R8", f"Same definition as '{y[2]}'; merge them or say what differs.", None, f"merge with {y[2]}")
        for key, hits in formulas.items():
            if len(hits) > 1:
                for r, rid, name in hits: self.add(S, r, rid, name, "Notes", "error", "R10", f"Same formula as {', '.join(n for _, _, n in hits if n != name)}; merge them.", key, "merge")
        for base, hits in by_base.items():
            if len(hits) > 1 and len({h[4] and tuple(sorted(h[4])) for h in hits}) > 1:
                bracketed = len({h[2].lower() for h in hits}) == len(hits)
                for r, rid, name, *_ in hits: self.add(S, r, rid, name, "Metric name", "warn" if bracketed else "error", "R9", f"'{base}' has more than one definition; " + ("the bracketed qualifiers must say how they differ." if bracketed else "same name, different meaning."))
        rows = [(r, rid, name, frozenset(m2f.get(name.lower(), [])), tables) for base, hits in by_base.items() for (r, rid, name, _, _, tables) in hits]
        for i in range(len(rows)):
            for j in range(i + 1, len(rows)):
                a, b = rows[i], rows[j]
                if a[3] and a[3] == b[3] and a[4] and b[4] and not (a[4] & b[4]):
                    for x, y in ((a, b), (b, a)): self.add(S, x[0], x[1], x[2], "Reads from tables", "warn", "R12", f"Same metric pulled from different tables: same fields as '{y[2]}' but no table in common.")

    def check_products(self):
        linked = {txt(row.get("Product")).lower() for r, row in self.rows["Metric to Product"]}
        for r, row in self.rows["Products"]:
            rid, name = self.ident("Products", row)
            if blank(row.get("Reads from")) and name.lower() not in linked: self.add("Products", r, rid, name, "Reads from", "error", "R14", "Nothing feeds this product: no table read and no metric shown.")

    def check_keys(self):
        for s, d in W.SHEETS.items():
            if not d.get("key") or s in W.JOIN_SHEETS: continue
            seen = defaultdict(list)
            for r, row in self.rows[s]: seen[txt(row.get(d["key"])).lower()].append((r, row))
            for k, hits in seen.items():
                if k and len(hits) > 1:
                    for r, row in hits: rid, name = self.ident(s, row); self.add(s, r, rid, name, d["key"], "error", "R21", f"Duplicate {d['key']}: also at rows {', '.join(str(x) for x, _ in hits if x != r)}.", name)

    def run(self):
        for s in W.SHEETS:
            for r, row in self.rows[s]: self.check_row(s, r, row)
        self.check_metrics(); self.check_products(); self.check_keys()
        self.findings.sort(key=lambda f: (list(W.SHEETS).index(f["sheet"]), f["row"], f["rule"]))
        return self.findings


def write_batches(ck, out_dir):
    os.makedirs(out_dir, exist_ok=True); by_row = defaultdict(list)
    for f in ck.findings: by_row[(f["sheet"], f["row"])].append(f)
    for s in W.SHEETS:
        keep = [c["name"] for c in W.SHEETS[s]["columns"] if c["kind"] not in COMPUTED]; rows = []
        for r, row in ck.rows[s]:
            if (s, r) in by_row or row.get("Review") == "Proposed":
                rows.append({**{k: row.get(k) for k in keep}, "_row": r, "findings": by_row.get((s, r), [])})
        for n, i in enumerate(range(0, len(rows), 50), 1):
            fn = os.path.join(out_dir, f"{s.replace(' ', '_')}_{n}.json")
            json.dump({"sheet": s, "rows": rows[i:i + 50]}, open(fn, "w"), indent=1, ensure_ascii=False, default=str)


def summary(findings):
    rules = defaultdict(lambda: defaultdict(int)); first = defaultdict(list)
    for f in findings:
        rules[f["rule"]][f["severity"]] += 1
        if len(first[f["rule"]]) < 3: first[f["rule"]].append(f"{f['sheet']} row {f['row']} ({f['name'] or f['id']}) {f['column']}: {f['message']}")
    print(f"{'rule':6}{'error':>7}{'warn':>7}{'info':>7}")
    for rule in sorted(rules, key=lambda x: int(x[1:])):
        c = rules[rule]; print(f"{rule:6}{c['error']:>7}{c['warn']:>7}{c['info']:>7}")
        for m in first[rule]: print("      - " + m)
    tot = defaultdict(int)
    for f in findings: tot[f["severity"]] += 1
    print(f"total: {tot['error']} error, {tot['warn']} warn, {tot['info']} info")


def main():
    a = sys.argv[1:]
    if not a or a[0].startswith("-"): print(__doc__); sys.exit(2)
    out = a[a.index("-o") + 1] if "-o" in a else "findings.json"; batches = a[a.index("--batches") + 1] if "--batches" in a else None
    ck = Checker(a[0]); findings = ck.run()
    json.dump(findings, open(out, "w"), indent=1, ensure_ascii=False)
    if batches: write_batches(ck, batches)
    summary(findings); print(f"wrote {out}" + (f" and batches in {batches}" if batches else ""))
    sys.exit(1 if any(f["severity"] == "error" for f in findings) else 0)


if __name__ == "__main__":
    main()
