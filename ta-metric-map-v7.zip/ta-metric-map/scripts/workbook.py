#!/usr/bin/env python3
"""
Read from and write to the TA metric map workbook (v7) without breaking its formulas, names, IDs or dropdowns.
The sheet layout comes from ../references/schema.json, written by the workbook generator; both must match.

    python3 workbook.py list     <map.xlsx> <sheet>                       # rows as JSON (names, not IDs)
    python3 workbook.py next-id  <map.xlsx> <sheet>
    python3 workbook.py append   <map.xlsx> <sheet> <rows.json>           # append rows keyed by header text; link columns take names or IDs
    python3 workbook.py fill     <map.xlsx> <sheet> "<column>" <by_id.json> [--source "..."]   # fill blank cells / Proposed rows only; conflicts become Questions
    python3 workbook.py set      <map.xlsx> <sheet> "<column>" <by_id.json> [--force]           # overwrite; refuses rows not marked Proposed unless --force
    python3 workbook.py question <map.xlsx> <sheet> <row_id_or_name> "<question>" "<what was seen>"
    python3 workbook.py merge    <map.xlsx> Metrics <keep> <merge...>     # fold rows into one; re-points join rows (names or IDs)
    python3 workbook.py sync     <map.xlsx>                               # resolve names<->IDs in every multi-value column, rebuild derived name columns
    python3 workbook.py check    <map.xlsx>                               # every name resolves, keys unique, IDs unique, nothing Not found
    python3 workbook.py card     <map.xlsx> <product name or ID> [out.md]

Rules enforced here:
  * Humans and the skill write NAMES in link columns. The grey ID columns are formulas (single links) or are
    maintained by `sync` (multi-value links). Nobody types an ID.
  * Never writes a formula or helper column. Never overwrites a row a person has Accepted or Corrected,
    except `set --force`.
  * Never duplicates: same key name (entity sheets) or same link pair (join sheets) is skipped and reported.
  * Every appended row gets Review = Proposed (unless given) and Confidence = Proposed (unless given).
  * Disposition is never written by a tool; a value in a row dict is dropped with a warning.
  * A link that does not resolve means the row is NOT written; a Question is raised instead.
"""
import json, sys, re, os, datetime
from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
SCHEMA = json.load(open(os.path.join(HERE, "..", "references", "schema.json")))
H = SCHEMA["header_row"]; R1 = SCHEMA["first_row"]
SHEETS = SCHEMA["sheets"]
TODAY = datetime.date.today().isoformat()
ID_RE = re.compile(r"^(P|M|T|S|F|D|I|DL|Q)-\d{3,}$")
LOCKED_REVIEW = ("Accepted", "Corrected")
JOIN_SHEETS = {"Product inputs", "Metric to Product", "Metric to Field", "Dimension usage"}


def cols(sheet):
    return {c["name"]: i + 1 for i, c in enumerate(SHEETS[sheet]["columns"])}

def coldef(sheet, name):
    for c in SHEETS[sheet]["columns"]:
        if c["name"] == name: return c
    return None

def ws_headers_ok(ws, sheet):
    want = [c["name"] for c in SHEETS[sheet]["columns"]]
    got = [ws.cell(row=H, column=i + 1).value for i in range(len(want))]
    return want == got, want, got

def key_col(sheet): return SHEETS[sheet]["key"]

def probe_cols(sheet):
    """columns that tell whether a row is in use: the ID/key, plus the first two link columns (never a formula column)"""
    cs = cols(sheet); d = SHEETS[sheet]; out = []
    if d["columns"][0]["kind"] in ("id", "key", "link"): out.append(1)
    if key_col(sheet) and sheet not in JOIN_SHEETS: out.append(cs[key_col(sheet)])
    out += [cs[c["name"]] for c in d["columns"] if c["kind"] == "link"][:2]
    return sorted(set(out))

def rows_raw(ws, sheet):
    cs = cols(sheet); out = []; probe = probe_cols(sheet)
    for r in range(R1, R1 + SHEETS[sheet]["cap"]):
        if all(ws.cell(row=r, column=c).value in (None, "") for c in probe):
            continue
        out.append((r, {n: ws.cell(row=r, column=c).value for n, c in cs.items()}))
    return out

def first_empty_row(ws, sheet):
    r = R1; cap = SHEETS[sheet]["cap"]; probe = probe_cols(sheet)
    while r < R1 + cap and any(ws.cell(row=r, column=c).value not in (None, "") for c in probe):
        r += 1
    if r >= R1 + cap: raise SystemExit(f"{sheet} is full ({cap} rows); extend the workbook")
    return r


class Index:
    """id <-> name for every entity sheet, built once from the workbook."""
    def __init__(self, wb):
        self.by_id, self.by_name, self.rows = {}, {}, {}
        for s, d in SHEETS.items():
            if not d.get("key") or s in JOIN_SHEETS: continue
            ws = wb[s]; cs = cols(s); kc = cs[d["key"]]; self.by_id[s] = {}; self.by_name[s] = {}; self.rows[s] = {}
            for r in range(R1, R1 + d["cap"]):
                idv = ws.cell(row=r, column=1).value if d["id_prefix"] else None
                nm = ws.cell(row=r, column=kc).value
                if nm in (None, ""): continue
                key = idv if d["id_prefix"] else nm
                if key in (None, ""): continue
                self.by_id[s][key] = nm; self.by_name[s][str(nm).strip().lower()] = key; self.rows[s][key] = r
    def resolve(self, sheet, value):
        """name or id -> (id, name) or (None, None)"""
        if value in (None, "") or sheet not in self.by_id: return None, None
        v = str(value).strip()
        if v in self.by_id[sheet]: return v, self.by_id[sheet][v]
        k = self.by_name[sheet].get(v.lower())
        if k is not None: return k, self.by_id[sheet][k]
        return None, None
    def resolve_list(self, sheet, value):
        ids, names, bad = [], [], []
        items = value if isinstance(value, list) else [x for x in re.split(r"[,;]\s*", str(value)) if x.strip()]
        for it in items:
            i, n = self.resolve(sheet, it)
            if i is None: bad.append(str(it).strip())
            elif i not in ids: ids.append(i); names.append(n)
        return ids, names, bad


LINK_TARGET = {  # names columns -> target sheet (None = any entity sheet)
 ("Products", "Reads from"): "Tables", ("Products", "Fed by scripts"): "Scripts",
 ("Metrics", "Reads from tables"): "Tables",
 ("Tables", "Built from"): "Tables", ("Tables", "Built by"): "Scripts",
 ("Scripts", "Reads"): "Tables", ("Scripts", "Writes"): "Tables", ("Scripts", "Feeds"): "Products",
 ("Fields", "Derived from"): "Fields",
 ("Incidents", "Tables or fields involved"): None, ("Decision log", "Relates to"): None, ("Questions", "About"): None,
}
IDS_COL = {  # names column -> its grey ids column
 ("Products", "Reads from"): "h_reads_ids", ("Products", "Fed by scripts"): "h_fed_ids", ("Metrics", "Reads from tables"): "h_tables_ids",
 ("Tables", "Built from"): "h_built_from_ids", ("Tables", "Built by"): "h_built_by_id", ("Scripts", "Reads"): "h_reads_ids", ("Scripts", "Writes"): "h_writes_ids",
 ("Scripts", "Feeds"): "h_feeds_ids", ("Fields", "Derived from"): "h_derived_ids", ("Incidents", "Tables or fields involved"): "h_involved_ids",
 ("Decision log", "Relates to"): "h_relates_ids", ("Questions", "About"): "h_row_id",
}
SINGLE_LINK_TARGET = {"Product": "Products", "Table": "Tables", "Metric": "Metrics", "Field": "Fields", "Dimension": "Dimensions",
                      "Mapping source table": "Tables", "Agreed source table": "Tables", "Platform": "Platforms"}
DERIVED_NAMES = {("Products", "Reads from"), ("Products", "Fed by scripts"), ("Tables", "Built by"), ("Metrics", "Reads from tables"), ("Questions", "About")}
ANY_SHEETS = ("Metrics", "Tables", "Products", "Fields", "Scripts", "Dimensions")


def next_id(wb, sheet):
    prefix = SHEETS[sheet]["id_prefix"]
    if not prefix: return None
    ws = wb[sheet]; mx = 0
    for r in range(R1, R1 + SHEETS[sheet]["cap"]):
        v = ws.cell(row=r, column=1).value
        if isinstance(v, str):
            m = re.fullmatch(prefix + r"-(\d+)", v.strip())
            if m: mx = max(mx, int(m.group(1)))
    return f"{prefix}-{mx + 1:03d}"


def add_question(wb, sheet, row_ref, question, seen, idx=None):
    ws = wb["Questions"]; cs = cols("Questions"); r = first_empty_row(ws, "Questions"); qid = next_id(wb, "Questions")
    idx = idx or Index(wb)
    rid, name = idx.resolve(sheet, row_ref)
    if rid is None and isinstance(row_ref, str) and ID_RE.match(row_ref.strip()): rid = row_ref.strip()  # row not written yet; sync fills the name later
    vals = {"Question ID": qid, "Raised on": TODAY, "Sheet": sheet, "About": name or (row_ref or ""), "h_row_id": rid or "",
            "Question": question, "What was seen": (seen or "")[:600], "Status": "Open"}
    for h, v in vals.items(): ws.cell(row=r, column=cs[h], value=v)
    return qid


def any_resolver(idx, value):
    for s in ANY_SHEETS:
        i, n = idx.resolve(s, value)
        if i: return s, i, n
    return None, None, None


def link_cols(sheet):
    return [c["name"] for c in SHEETS[sheet]["columns"] if c["kind"] == "link"]


def find_duplicate(ws, sheet, nr, idx):
    cs = cols(sheet)
    if sheet in JOIN_SHEETS:
        pairs = link_cols(sheet)[:2]; want = []
        for ln in pairs:
            i, n = idx.resolve(SINGLE_LINK_TARGET[ln], nr.get(ln)); want.append(i)
        if not all(want): return None
        for r, row in rows_raw(ws, sheet):
            got = [idx.resolve(SINGLE_LINK_TARGET[ln], row.get(ln))[0] for ln in pairs]
            if got == want: return r
        return None
    if key_col(sheet):
        name = str(nr.get(key_col(sheet)) or "").strip().lower()
        if not name: return None
        k = idx.by_name.get(sheet, {}).get(name)
        return idx.rows[sheet].get(k) if k is not None else None
    return None


def resolve_names_cell(idx, sheet, col, value, warnings, qsheet, qrow, wb):
    tgt = LINK_TARGET.get((sheet, col))
    if tgt:
        ids, names, bad = idx.resolve_list(tgt, value)
        for b in bad:
            add_question(wb, qsheet, qrow, f"'{b}' in {col} does not match any name on {tgt}. Which is meant?", str(value), idx)
        if bad: warnings.append(f"{col}: {len(bad)} name(s) not found ({', '.join(bad)}); left out and questioned")
        return ", ".join(names), ", ".join(ids)
    sids, snames = [], []
    for it in (value if isinstance(value, list) else [x for x in re.split(r"[,;]\s*", str(value)) if x.strip()]):
        s_, i, nm = any_resolver(idx, it)
        if i: sids.append(i); snames.append(nm)
        else: snames.append(str(it).strip()); warnings.append(f"{col}: '{str(it).strip()}' matched nothing; kept as text")
    return ", ".join(snames), ", ".join(sids)


def append_rows(wb, sheet, new_rows, default_source=None):
    ws = wb[sheet]; ok, want, got = ws_headers_ok(ws, sheet)
    if not ok: raise SystemExit(f"{sheet}: headers do not match schema.json. Expected {want[:5]}..., got {got[:5]}...")
    cs = cols(sheet); results = []; idcol = SHEETS[sheet]["columns"][0]["name"]
    for nr in new_rows:
        idx = Index(wb); warnings = []; nr = dict(nr)
        if nr.get("Disposition"): warnings.append("Disposition is a person's decision; value dropped"); nr["Disposition"] = None
        dup = find_duplicate(ws, sheet, nr, idx)
        if dup:
            warnings.append(f"already present at row {dup} (same {'link pair' if sheet in JOIN_SHEETS else 'name'}); not appended")
            results.append((ws.cell(row=dup, column=1).value, dup, warnings)); continue
        qrow = nr.get(key_col(sheet)) if key_col(sheet) and sheet not in JOIN_SHEETS else ""
        broken = False
        for c in SHEETS[sheet]["columns"]:
            n, k = c["name"], c["kind"]
            if nr.get(n) in (None, ""): continue
            if k == "link":
                tgt = SINGLE_LINK_TARGET[n]; i, nm = idx.resolve(tgt, nr[n])
                if i is None:
                    add_question(wb, sheet, qrow, f"A row was proposed that links to '{nr[n]}' on {tgt}, but no row with that name exists. Which {tgt[:-1].lower()} is meant? The row was not written.", json.dumps({a: b for a, b in nr.items() if b}, ensure_ascii=False)[:400], idx)
                    warnings.append(f"{n} '{nr[n]}' not found on {tgt}; row NOT written, question raised"); broken = True
                else: nr[n] = nm
            elif k == "names":
                if (sheet, n) in DERIVED_NAMES: warnings.append(f"'{n}' is maintained by sync; value ignored"); nr[n] = None; continue
                nr[n], nr[IDS_COL[(sheet, n)]] = resolve_names_cell(idx, sheet, n, nr[n], warnings, sheet, qrow, wb)
        if broken: results.append((None, None, warnings)); continue
        r = first_empty_row(ws, sheet); rid = None
        if SHEETS[sheet]["id_prefix"]:
            rid = nr.get(idcol)
            if not rid or rid in idx.by_id.get(sheet, {}): rid = next_id(wb, sheet)
            nr[idcol] = rid
        if "Confidence" in cs and not nr.get("Confidence"): nr["Confidence"] = "Proposed"; warnings.append("Confidence missing; set to Proposed")
        if "Review" in cs and not nr.get("Review"): nr["Review"] = "Proposed"
        if "Source (where found)" in cs and not nr.get("Source (where found)") and default_source: nr["Source (where found)"] = default_source
        for h, v in nr.items():
            if h not in cs: warnings.append(f"unknown column '{h}' ignored"); continue
            cd = coldef(sheet, h)
            if cd["kind"] in ("f", "h", "linkid"):
                if v not in (None, ""): warnings.append(f"'{h}' is computed; value ignored")
                continue
            if cd.get("dropdown") and v not in (None, "") and v not in cd["dropdown"]:
                add_question(wb, sheet, rid or qrow, f"Value '{v}' for {h} is not one of the allowed options ({', '.join(cd['dropdown'])}). Which applies?", str(v), idx)
                warnings.append(f"'{h}' value '{v}' not allowed; left blank and questioned"); v = None
            ws.cell(row=r, column=cs[h], value=v)
        results.append((rid or qrow, r, warnings))
    return results


def guarded_write(wb, sheet, column, mapping, mode, force=False, source=None):
    ws = wb[sheet]; cs = cols(sheet); cd = coldef(sheet, column); idx = Index(wb); n = 0; report = []
    if not cd: raise SystemExit(f"{column} is not a column on {sheet}")
    if cd["kind"] in ("f", "h", "linkid", "id"): raise SystemExit(f"{column} is computed; nothing to {mode}")
    if column == "Disposition": raise SystemExit("Disposition is a person's decision; tools never write it")
    if (sheet, column) in DERIVED_NAMES: raise SystemExit(f"{column} is maintained by sync")
    rev = cs.get("Review")
    for key, val in mapping.items():
        i, nm = idx.resolve(sheet, key)
        r = idx.rows.get(sheet, {}).get(i)
        if r is None: report.append(f"{key}: not found on {sheet}"); continue
        if cd.get("dropdown") and val not in (None, "") and val not in cd["dropdown"]:
            add_question(wb, sheet, key, f"Value '{val}' for {column} is not one of the allowed options ({', '.join(cd['dropdown'])}). Which applies?", str(val), idx); report.append(f"{key}: '{val}' not allowed; questioned"); continue
        if cd["kind"] == "link" and val not in (None, ""):
            ti, tn = idx.resolve(SINGLE_LINK_TARGET[column], val)
            if ti is None: add_question(wb, sheet, key, f"{column} was to be set to '{val}', but no such row exists on {SINGLE_LINK_TARGET[column]}.", str(val), idx); report.append(f"{key}: '{val}' not found; questioned"); continue
            val = tn
        ids_val = None
        if cd["kind"] == "names" and val not in (None, ""):
            w = []; val, ids_val = resolve_names_cell(idx, sheet, column, val, w, sheet, key, wb); report.extend(f"{key}: {x}" for x in w)
        cur = ws.cell(row=r, column=cs[column]).value
        review = ws.cell(row=r, column=rev).value if rev else None
        locked = review in LOCKED_REVIEW
        if mode == "fill":
            if cur not in (None, "") and str(cur).strip() == str(val).strip(): continue
            if cur in (None, "") or not locked:
                ws.cell(row=r, column=cs[column], value=val); n += 1
                if ids_val is not None: ws.cell(row=r, column=cs[IDS_COL[(sheet, column)]], value=ids_val)
                if source and "Source (where found)" in cs:
                    old = str(ws.cell(row=r, column=cs["Source (where found)"]).value or "")
                    if source not in old: ws.cell(row=r, column=cs["Source (where found)"], value=(old + "; " + source).strip("; "))
            else:
                add_question(wb, sheet, key, f"{column} on {nm or key} is '{cur}' in the sheet (a person validated it) but the files show '{val}'. Which is right?", f"sheet: {cur} | files: {val}", idx)
                report.append(f"{key}: conflict on {column}; questioned")
        else:
            if locked and not force: report.append(f"{key}: row is {review}; not changed (use --force)"); continue
            ws.cell(row=r, column=cs[column], value=val); n += 1
            if ids_val is not None: ws.cell(row=r, column=cs[IDS_COL[(sheet, column)]], value=ids_val)
    return n, report


def split_ids(v): return [x for x in re.split(r",\s*", str(v or "")) if x]


def sync(wb):
    """Resolve names<->IDs on every multi-value column and rebuild derived name columns. Returns a report."""
    rep = []; idx = Index(wb)
    for (sheet, col), idcol in IDS_COL.items():
        if (sheet, col) in DERIVED_NAMES: continue
        ws = wb[sheet]; cs = cols(sheet); tgt = LINK_TARGET.get((sheet, col))
        for r, row in rows_raw(ws, sheet):
            names = row.get(col); ids = row.get(idcol)
            if names in (None, "") and ids in (None, ""): continue
            if tgt:
                if names not in (None, ""):
                    i_, n_, bad = idx.resolve_list(tgt, names)
                    for b in bad:
                        rep.append(f"{sheet} row {r}: '{b}' in {col} matches no {tgt} name; question raised")
                        add_question(wb, sheet, row.get(SHEETS[sheet]["columns"][0]["name"]) or "", f"'{b}' in {col} does not match any name on {tgt}. Which is meant?", str(names), idx)
                    ws.cell(row=r, column=cs[col], value=", ".join(n_ + bad)); ws.cell(row=r, column=cs[idcol], value=", ".join(i_))
                else:
                    i_, n_, bad = idx.resolve_list(tgt, ids); ws.cell(row=r, column=cs[col], value=", ".join(n_))
            else:
                sids, snames = [], []
                for it in [x for x in re.split(r"[,;]\s*", str(names or ids)) if x.strip()]:
                    s_, i, n = any_resolver(idx, it)
                    if i: sids.append(i); snames.append(n)
                    else: snames.append(it.strip())
                ws.cell(row=r, column=cs[col], value=", ".join(snames)); ws.cell(row=r, column=cs[idcol], value=", ".join(sids))
    T, P, M = cols("Tables"), cols("Products"), cols("Metrics")
    scripts = {row["Script ID"]: row for r, row in rows_raw(wb["Scripts"], "Scripts")}
    writes, feeds = {}, {}
    for sid, row in scripts.items():
        for tid in split_ids(row.get("h_writes_ids")): writes.setdefault(tid, []).append(sid)
        for pid in split_ids(row.get("h_feeds_ids")): feeds.setdefault(pid, []).append(sid)
    wsT = wb["Tables"]
    for r, row in rows_raw(wsT, "Tables"):
        tid = row["Table ID"]; sids = writes.get(tid, [])
        wsT.cell(row=r, column=T["h_built_by_id"], value=", ".join(sids)); wsT.cell(row=r, column=T["Built by"], value=", ".join(idx.by_id["Scripts"].get(s, s) for s in sids))
        mech = None
        if row.get("Kind") == "Manual spreadsheet": mech = "Manual spreadsheet"
        elif sids:
            trig = [scripts[s].get("Trigger") for s in sids]
            mech = "Manual run" if "Manual run" in trig else ("Scheduled job" if ("Scheduled" in trig or "On demand" in trig) else "Unknown")
        if mech and row.get("Review") not in LOCKED_REVIEW: wsT.cell(row=r, column=T["Refresh mechanism"], value=mech)
    reads = {}
    for r, row in rows_raw(wb["Product inputs"], "Product inputs"):
        pi, _ = idx.resolve("Products", row.get("Product")); ti, _ = idx.resolve("Tables", row.get("Table"))
        if pi and ti and ti not in reads.setdefault(pi, []): reads[pi].append(ti)
    wsP = wb["Products"]
    for r, row in rows_raw(wsP, "Products"):
        pid = row["Product ID"]
        wsP.cell(row=r, column=P["h_reads_ids"], value=", ".join(reads.get(pid, []))); wsP.cell(row=r, column=P["Reads from"], value=", ".join(idx.by_id["Tables"].get(t, t) for t in reads.get(pid, [])))
        wsP.cell(row=r, column=P["h_fed_ids"], value=", ".join(feeds.get(pid, []))); wsP.cell(row=r, column=P["Fed by scripts"], value=", ".join(idx.by_id["Scripts"].get(s, s) for s in feeds.get(pid, [])))
    ftable = {}
    for r, row in rows_raw(wb["Fields"], "Fields"):
        ti, _ = idx.resolve("Tables", row.get("Table"))
        if ti: ftable[row["Field ID"]] = ti
    mt = {}
    for r, row in rows_raw(wb["Metric to Field"], "Metric to Field"):
        mi, _ = idx.resolve("Metrics", row.get("Metric")); fi, _ = idx.resolve("Fields", row.get("Field"))
        if mi and fi and ftable.get(fi) and ftable[fi] not in mt.setdefault(mi, []): mt[mi].append(ftable[fi])
    wsM = wb["Metrics"]
    for r, row in rows_raw(wsM, "Metrics"):
        mid = row["Metric ID"]
        wsM.cell(row=r, column=M["h_tables_ids"], value=", ".join(mt.get(mid, []))); wsM.cell(row=r, column=M["Reads from tables"], value=", ".join(idx.by_id["Tables"].get(t, t) for t in mt.get(mid, [])))
    wsQ = wb["Questions"]; Q = cols("Questions")
    for r, row in rows_raw(wsQ, "Questions"):
        rid = row.get("h_row_id"); sh = row.get("Sheet"); about = row.get("About")
        if not rid and isinstance(about, str) and ID_RE.match(about.strip()): rid = about.strip(); wsQ.cell(row=r, column=Q["h_row_id"], value=rid)
        if rid and sh in idx.by_id and rid in idx.by_id[sh]: wsQ.cell(row=r, column=Q["About"], value=idx.by_id[sh][rid])
    rep.append("sync done: IDs resolved, Built by / Refresh mechanism / Reads from / Fed by scripts / Reads from tables rebuilt")
    return rep


def check(wb):
    problems = []; idx = Index(wb)
    for s, d in SHEETS.items():
        ws = wb[s]; ok, want, got = ws_headers_ok(ws, s)
        if not ok: problems.append(f"{s}: headers differ from schema.json"); continue
        seen_ids, seen_keys = {}, {}
        for r, row in rows_raw(ws, s):
            if d["id_prefix"]:
                v = row.get(d["columns"][0]["name"])
                if not v: problems.append(f"{s} row {r}: no ID")
                elif v in seen_ids: problems.append(f"{s}: duplicate ID {v} at rows {seen_ids[v]} and {r}")
                seen_ids[v] = r
            if d.get("key") and s not in JOIN_SHEETS:
                k = str(row.get(d["key"]) or "").strip().lower()
                if not k: problems.append(f"{s} row {r}: no {d['key']}")
                elif k in seen_keys: problems.append(f"{s}: duplicate {d['key']} '{row.get(d['key'])}' at rows {seen_keys[k]} and {r}")
                seen_keys[k] = r
            for c in d["columns"]:
                n, k = c["name"], c["kind"]; v = row.get(n)
                if v in (None, ""): continue
                if k == "link":
                    tgt = SINGLE_LINK_TARGET.get(n)
                    if tgt and idx.resolve(tgt, v)[0] is None: problems.append(f"{s} row {r}: {n} '{v}' not found on {tgt}")
                if k == "names" and LINK_TARGET.get((s, n)):
                    ids, names, bad = idx.resolve_list(LINK_TARGET[(s, n)], v)
                    for b in bad: problems.append(f"{s} row {r}: '{b}' in {n} not found on {LINK_TARGET[(s, n)]}")
                if c.get("dropdown") and v not in c["dropdown"]: problems.append(f"{s} row {r}: {n} '{v}' is not an allowed value")
                if isinstance(v, str) and k in ("in", "names", "link", "key") and re.search(r"\b(P|M|T|S|F|D|I|DL|Q)-\d{3,}\b", v): problems.append(f"{s} row {r}: {n} shows a code where a name belongs: {v[:60]}")
    return problems


def list_rows(wb, sheet):
    out = []
    for r, row in rows_raw(wb[sheet], sheet):
        clean = {k: (None if isinstance(v, str) and v.startswith("=") else v) for k, v in row.items()}
        clean["_row"] = r; out.append(clean)
    return out


def merge(wb, sheet, keep, merge_refs):
    idx = Index(wb); ws = wb[sheet]; cs = cols(sheet); rep = []
    keep_id, keep_name = idx.resolve(sheet, keep)
    if not keep_id: raise SystemExit(f"{keep} not found on {sheet}")
    merged = [idx.resolve(sheet, m) for m in merge_refs]
    merged_names = {n.strip().lower() for i, n in merged if n}
    for js in JOIN_SHEETS:
        jws = wb[js]; jcs = cols(js); links = link_cols(js); mine = [ln for ln in links if SINGLE_LINK_TARGET[ln] == sheet]
        if not mine: continue
        pairs = links[:2]; seen = set()
        for r, row in rows_raw(jws, js): seen.add(tuple(str(row.get(p) or "").strip().lower() for p in pairs))
        for r, row in rows_raw(jws, js):
            for ln in mine:
                if str(row.get(ln) or "").strip().lower() in merged_names:
                    newkey = tuple((keep_name if p == ln else str(row.get(p) or "")).strip().lower() for p in pairs)
                    if newkey in seen:
                        surv = next((rr for rr, rw in rows_raw(jws, js) if tuple(str(rw.get(p) or "").strip().lower() for p in pairs) == newkey and rr != r), None)
                        if surv:
                            for col in ("How it is shown", "Role in the metric", "Notes"):
                                if col in jcs:
                                    a = jws.cell(row=surv, column=jcs[col]).value or ""; b = jws.cell(row=r, column=jcs[col]).value or ""
                                    if b and b not in a: jws.cell(row=surv, column=jcs[col], value=(a + "; " + b).strip("; "))
                        for c in SHEETS[js]["columns"]:
                            if c["kind"] not in ("f", "h", "linkid"): jws.cell(row=r, column=jcs[c["name"]], value=None)
                        rep.append(f"{js} row {r}: folded into row {surv}")
                    else:
                        jws.cell(row=r, column=jcs[ln], value=keep_name); seen.add(newkey); rep.append(f"{js} row {r}: -> {keep_name}")
    for i, n in merged:
        if not i: rep.append("a merge target was not found"); continue
        r = idx.rows[sheet][i]
        ws.cell(row=r, column=cs[key_col(sheet)], value=f"(merged into {keep_name}) {n}")
        if "Notes" in cs: ws.cell(row=r, column=cs["Notes"], value=(f"Merged into {keep_name} on {TODAY}. " + str(ws.cell(row=r, column=cs['Notes']).value or "")).strip())
        if "Metric family" in cs: ws.cell(row=r, column=cs["Metric family"], value=None)
        rep.append(f"{sheet}: {n} marked merged into {keep_name}")
    return rep


def card(wb, product_ref):
    idx = Index(wb); pid, pname = idx.resolve("Products", product_ref)
    if not pid: raise SystemExit(f"{product_ref} not on Products")
    def byid(s): return {row[SHEETS[s]["columns"][0]["name"]]: row for r, row in rows_raw(wb[s], s)}
    def allrows(s): return [row for r, row in rows_raw(wb[s], s)]
    P = byid("Products")[pid]; tables = byid("Tables"); scripts = byid("Scripts"); fields = byid("Fields"); metrics = byid("Metrics")
    m2p = [x for x in allrows("Metric to Product") if idx.resolve("Products", x.get("Product"))[0] == pid]
    mids = [m for m in (idx.resolve("Metrics", x.get("Metric"))[0] for x in m2p) if m]
    fids = {f for f in (idx.resolve("Fields", x.get("Field"))[0] for x in allrows("Metric to Field") if idx.resolve("Metrics", x.get("Metric"))[0] in mids) if f}
    direct = [t for t in (idx.resolve("Tables", x.get("Table"))[0] for x in allrows("Product inputs") if idx.resolve("Products", x.get("Product"))[0] == pid) if t]
    via_fields = [t for t in (idx.resolve("Tables", fields[f].get("Table"))[0] for f in fids if f in fields) if t]
    seen, order = set(), []
    def walk(tid, depth=0):
        if not tid or tid in seen or tid not in tables: return
        seen.add(tid); order.append((tid, depth))
        for p in split_ids(tables[tid].get("h_built_from_ids")): walk(p, depth + 1)
    for t in direct + via_fields: walk(t)
    manual = [t for t, _ in order if tables[t].get("Kind") == "Manual spreadsheet"]
    manual_scripts = sorted({s for t, _ in order for s in split_ids(tables[t].get("h_built_by_id")) if scripts.get(s, {}).get("Trigger") == "Manual run"})
    issues = [f for f in fids if f in fields and fields[f].get("Data quality") == "Issue"]
    incidents = [i for i in allrows("Incidents") if idx.resolve("Products", i.get("Product"))[0] == pid]
    openq = [q for q in allrows("Questions") if q.get("Status") == "Open" and q.get("h_row_id") in (set(mids) | fids | seen | {pid})]
    L = [f"# {pname}", f"{P.get('Type') or ''} in {P.get('Tool') or ''}. Audience: {P.get('Audience') or 'not recorded'}. Owner: {P.get('Owner (team)') or 'not recorded'}. Contact: **{P.get('Point of contact') or 'NOT RECORDED'}**.",
         f"Refreshes: {P.get('Refresh frequency') or 'not recorded'}. Last hop: {P.get('Last hop into the product') or 'not recorded'}. Automation: {P.get('Automation level') or 'not recorded'}. Manual steps: {P.get('Manual steps') or 'none recorded'}"]
    if P.get("Review") == "Proposed": L.append("_This product row is a proposal awaiting review._")
    flags = []
    if manual: flags.append(f"reads {len(manual)} hand-maintained spreadsheet(s)")
    if manual_scripts: flags.append(f"{len(manual_scripts)} script(s) in its chain are started by hand")
    if issues: flags.append(f"{len(issues)} field(s) with a known issue")
    if incidents: flags.append(f"{len(incidents)} incident(s) logged")
    if openq: flags.append(f"{len(openq)} open question(s)")
    if flags: L.append("\n**Watch:** " + "; ".join(flags) + ".")
    L.append(f"\n## Reads directly ({len(direct)})")
    for t in direct: L.append(f"- {tables[t]['Short name']} ({tables[t].get('Kind')}){'  **HAND-MAINTAINED**' if t in manual else ''}")
    L.append(f"\n## Metrics shown ({len(mids)})")
    for x in m2p:
        m = metrics.get(idx.resolve("Metrics", x.get("Metric"))[0])
        if m: L.append(f"- **{m['Metric name']}** [{m.get('Metric family') or 'no family'}]: {m.get('Definition (plain words)') or 'no definition'}  \n  shown as: {x.get('How it is shown') or ''}; reads {m.get('Reads from tables') or 'no tables traced'}")
    L.append(f"\n## Everything underneath ({len(order)} tables)"); L.append("Indented rows are upstream of the row above them.")
    for t, d in order:
        T = tables[t]; by = T.get("Built by"); trig = ""
        if T.get("h_built_by_id"):
            s = scripts.get(split_ids(T["h_built_by_id"])[0], {}); trig = f" ({s.get('Trigger') or 'trigger?'}, {s.get('Schedule') or 'no schedule'})"
        L.append(f"{'  ' * d}- {T['Short name']} ({T.get('Kind')}){'  **HAND-MAINTAINED**' if t in manual else ''}  \n{'  ' * d}  owner {T.get('Owner (team)') or '?'} · contact {T.get('Point of contact') or '**none**'} · refresh {T.get('Refresh mechanism') or '?'} {T.get('Refresh frequency') or ''}{(' · built by ' + by + trig) if by else ''} · why: {T.get('Why it exists') or '_not recorded_'}")
    rules = [f for f in fids if f in fields and fields[f].get("Type") == "Derived"]
    if rules:
        L.append("\n## Business rules it depends on")
        for f in rules: L.append(f"- {fields[f]['Field name']} ({fields[f].get('Where the rule lives') or 'where?'}): {fields[f].get('Logic (the business rule)') or '_not recorded_'}")
    if issues:
        L.append("\n## Known data issues")
        for f in issues: L.append(f"- {fields[f]['Field name']}: {fields[f].get('Issue / note') or ''} (root stage: {fields[f].get('Root stage of issue') or '?'})")
    if incidents:
        L.append("\n## Incidents")
        for i in incidents: L.append(f"- {i.get('Date')} · {i.get('Symptom')} · {i.get('Root stage') or '?'} · {i.get('Root cause (plain words)') or ''}")
    if openq:
        L.append("\n## Open questions")
        for q in openq: L.append(f"- {q.get('Question')}")
    return "\n".join(L)


def main():
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    cmd, path = sys.argv[1], sys.argv[2]; wb = load_workbook(path); a = sys.argv[3:]
    if cmd == "list": print(json.dumps(list_rows(wb, a[0]), indent=2, default=str))
    elif cmd == "next-id": print(next_id(wb, a[0]))
    elif cmd == "append":
        res = append_rows(wb, a[0], json.load(open(a[1]))); wb.save(path)
        for rid, r, w in res: print((f"{a[0]} row {r}: {rid or 'link row'}" if r else f"{a[0]}: row skipped") + (f"  WARNINGS: {'; '.join(w)}" if w else ""))
    elif cmd in ("fill", "set"):
        force = "--force" in a; src = a[a.index("--source") + 1] if "--source" in a else None
        n, rep = guarded_write(wb, a[0], a[1], json.load(open(a[2])), cmd, force=force, source=src); wb.save(path)
        print(f"{cmd} {a[1]} on {n} rows of {a[0]}"); [print("  " + x) for x in rep]
    elif cmd == "question":
        qid = add_question(wb, a[0], a[1], a[2], a[3] if len(a) > 3 else ""); wb.save(path); print(qid)
    elif cmd == "merge":
        rep = merge(wb, a[0], a[1], a[2:]); wb.save(path); print("\n".join(rep) or "nothing to merge")
    elif cmd == "sync":
        rep = sync(wb); wb.save(path); print("\n".join(rep))
    elif cmd == "check":
        p = check(wb); print("\n".join(p) if p else "OK: every name resolves, keys and IDs unique, no codes where names belong")
    elif cmd == "card":
        out = card(wb, a[0])
        if len(a) > 1: open(a[1], "w").write(out); print(f"wrote {a[1]}")
        else: print(out)
    else: print(__doc__); sys.exit(1)


if __name__ == "__main__":
    main()
