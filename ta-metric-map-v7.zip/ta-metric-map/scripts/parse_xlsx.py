#!/usr/bin/env python3
"""
Extract the metric inventory from an Excel scorecard workbook (.xlsx / .xlsm) into JSON.

Usage:
    python3 parse_xlsx.py <workbook.xlsx> [-o out.json]

Needs only the standard library and openpyxl. The workbook is opened twice (once for
formulas, once with data_only=True for the values Excel cached at the last save) and the
zip is read directly for the parts openpyxl does not surface: connections, query tables,
external link targets, Power Query (DataMashup) presence.

What it reports
---------------
properties      lastModifiedBy, modified, creator, created, calcMode/fullCalcOnLoad, merged ranges
sheets          one entry per worksheet:
                  name, kind ("data dump" | "scorecard" | "hidden"), hidden (bool), rows, formulas,
                  header_row, column_headers (strings on the header row), columns (data dumps only:
                  name/type/example per column), comments [[cell, text], ...],
                  read_by_visible_formulas (hidden sheets only: cells on visible sheets that read it),
                  unlabelled_values (numbers/formulas with no label to the left or above).
                A sheet is a "data dump" when it has no formulas, its first populated row holds 3+
                strings and it has at least 20 rows. Hidden sheets never contribute metrics.
metrics         one entry per (normalised label, formula shape) across all visible scorecard sheets:
                  label, normalised_label, kind ("formula" | "pasted value" | "connection value"),
                  shape, formula_example, reads, reads_labels [[ref, label], ...], names_used,
                  where ["Sheet!B3", ...], tabs, cached (parallel to where), parameters,
                  dimension {axis, headers}, unit_hint ("percent" | "days" | "count" | "unknown"),
                  comments (any comment on one of the metric's cells).
                A label is a string cell whose right-hand neighbours (or the cells below it)
                hold numbers or formulas. "shape" is the formula with relative references
                rewritten as R[dr]C[dc], absolute references and sheet prefixes kept, and text
                literals replaced by "<sheet>", "<column header>" or "<period>"/"<literal_n>"
                when they vary with the cell's position (recorded under "parameters"), kept
                verbatim when constant, and left as "<str>" when they vary for no visible reason.
                A "pasted value" is a constant that sits outside any table fed by a connection.
tables          data-dump sheets and ListObjects: sheet, kind_guess ("Script output" |
                "Manual spreadsheet" | "Unknown"), columns, rows, listobject, connection, ref.
named_ranges    name -> target (sheet-scoped names are keyed "Sheet!name")
external_links  [{index, path}] from xl/externalLinks (index is the [n] used in formulas) plus
                any [file.xlsx] literal found in a formula
connections     [{name, type, command, connection}] from xl/connections.xml, plus query tables
power_query     true when a customXml DataMashup part exists (not decoded)
questions       plain-sentence questions a reviewer must answer

Everything here is evidence from the file, not interpretation. The orientation guess (label
to the left vs. label above) and the kind_guess on tables are heuristics; the questions list
says where the file is silent.
"""
import argparse
import datetime as dt
import json
import re
import sys
import zipfile
from collections import OrderedDict, defaultdict
from xml.etree import ElementTree as ET

try:
    from openpyxl import load_workbook
    from openpyxl.formula import Tokenizer
    from openpyxl.utils import column_index_from_string, get_column_letter
    from openpyxl.utils.cell import range_boundaries
except ImportError:  # pragma: no cover
    raise SystemExit("openpyxl is required: pip install openpyxl")

NS_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"
NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
NS_ODR = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
CONN_TYPES = {"1": "ODBC", "2": "DAO", "3": "file", "4": "web query", "5": "OLEDB", "6": "text", "7": "ADO", "8": "DSP", "100": "Power Query"}

MONTHS = "jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|january|february|march|april|june|july|august|september|october|november|december"
RE_PERIOD = re.compile(
    r"^\s*(?:(?:%s)\.?(?:[\s\-'/]*\d{2,4})?|\d{4}[-/]\d{1,2}(?:[-/]\d{1,2})?|\d{1,2}[-/]\d{4}|(?:fy|cy)?\s*\d{4}|q[1-4](?:[\s\-'/]*(?:fy)?\d{2,4})?|h[12](?:[\s\-'/]*\d{2,4})?|w(?:ee)?k\s*\d+|(?:mtd|qtd|ytd|wtd|ttm|ltm|l12m)|(?:this|last|prior|previous|current)\s+(?:month|quarter|year|week)|total|ytd)\s*$" % MONTHS,
    re.I)


# ----------------------------------------------------------------------------- helpers
def is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def formula_text(v):
    """Return the formula string for a cell value, or None if it is not a formula."""
    if isinstance(v, str):
        return v if v.startswith("=") else None
    text = getattr(v, "text", None)          # ArrayFormula
    if isinstance(text, str):
        return text if text.startswith("=") else "=" + text
    if v.__class__.__name__ == "DataTableFormula":
        return "=TABLE(" + ",".join(f"{k}={val}" for k, val in sorted(vars(v).items()) if val) + ")"
    return None


def is_text(v):
    if isinstance(v, str):
        return not v.startswith("=")
    return v.__class__.__name__ == "CellRichText"


def as_text(v):
    return str(v)


def norm_label(s):
    return re.sub(r"\s+", " ", as_text(s).strip().lower()).rstrip(":")


def looks_period(v):
    if isinstance(v, (dt.date, dt.datetime)):
        return True
    if is_text(v):
        return bool(RE_PERIOD.match(as_text(v)))
    return False


def jsonable(v):
    if isinstance(v, (dt.date, dt.datetime, dt.time)):
        return v.isoformat()
    if is_num(v) or isinstance(v, (bool, str)) or v is None:
        return v
    return str(v)


def unit_hint(label, formula, number_format):
    text = (label or "") + " " + (formula or "")
    low = text.lower()
    if "%" in text or re.search(r"\brate\b|\bpct\b|\bpercent", low) or (number_format and "%" in number_format):
        return "percent"
    if re.search(r"\bdays?\b|datedif|networkdays", low) or re.search(r"\btime\b.*\bdays\b", low):
        return "days"
    if "count" in low or re.search(r"\b(number|no\.|#)\s", low) or re.search(r"\bcount(?:ifs?|a|blank)?\(", low):
        return "count"
    return "unknown"


def strip_sheet(ref):
    """'Data'!$A:$A -> ('Data', '$A:$A'); A1 -> (None, 'A1')"""
    sheet, bang, cell = ref.rpartition("!")
    if not bang:
        return None, ref
    sheet = sheet.strip("'")
    return sheet, cell


def conn_type_name(code):
    return CONN_TYPES.get(code, f"type {code}") if code else "unknown"


# ----------------------------------------------------------------------------- zip parts
def read_zip_parts(path, questions):
    out = {"external_links": [], "connections": [], "power_query": False, "query_tables": {}, "table_connections": {}}
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        questions.append(f"{path} is not a valid zip container; the file may be corrupt or not an .xlsx.")
        return out
    names = set(z.namelist())

    def xml(name):
        try:
            return ET.fromstring(z.read(name))
        except Exception:
            return None

    def rels(name):
        d, _, base = name.rpartition("/")
        rel_name = f"{d}/_rels/{base}.rels" if d else f"_rels/{base}.rels"
        root = xml(rel_name) if rel_name in names else None
        return {r.get("Id"): (r.get("Target"), r.get("TargetMode")) for r in root} if root is not None else {}

    # external links, in the [n] order of workbook.xml <externalReferences>
    wb_rels = rels("xl/workbook.xml")
    wb_xml = xml("xl/workbook.xml")
    if wb_xml is not None:
        ext = wb_xml.find(f"{NS_MAIN}externalReferences")
        if ext is not None:
            for i, er in enumerate(ext, start=1):
                rid = er.get(f"{NS_ODR}id")
                target = wb_rels.get(rid, (None, None))[0]
                link_path = None
                if target:
                    part = "xl/" + target.lstrip("/").replace("xl/", "", 1) if not target.startswith("/") else target.lstrip("/")
                    link_rels = rels(part)
                    for tgt, mode in link_rels.values():
                        link_path = tgt
                out["external_links"].append({"index": i, "path": link_path, "part": target})
    # fallback: any externalLinks parts not reached through the workbook rels
    for n in sorted(names):
        if n.startswith("xl/externalLinks/_rels/") and not any(e["part"] and n.endswith(e["part"].split("/")[-1] + ".rels") for e in out["external_links"]):
            for tgt, mode in rels(n[: -len(".rels")].replace("/_rels/", "/")).values():
                out["external_links"].append({"index": None, "path": tgt, "part": n})

    # connections
    if "xl/connections.xml" in names:
        root = xml("xl/connections.xml")
        for c in root if root is not None else []:
            entry = {"id": c.get("id"), "name": c.get("name"), "type": conn_type_name(c.get("type")), "command": None, "connection": None, "refresh_on_load": c.get("refreshOnLoad")}
            for child in c:
                tag = child.tag.split("}")[-1]
                if tag in ("dbPr", "olapPr", "textPr", "webPr"):
                    entry["command"] = child.get("command") or child.get("url") or child.get("sourceFile")
                    entry["connection"] = child.get("connection")
                    if entry["connection"] and "Mashup" in entry["connection"]:
                        entry["type"] = "Power Query"
            out["connections"].append(entry)
    # query tables -> connection id
    for n in sorted(names):
        if n.startswith("xl/queryTables/") and n.endswith(".xml"):
            root = xml(n)
            if root is not None:
                out["query_tables"][n] = {"name": root.get("name"), "connectionId": root.get("connectionId")}
    # tables -> query table -> connection
    for n in sorted(names):
        if n.startswith("xl/tables/") and n.endswith(".xml"):
            root = xml(n)
            if root is None:
                continue
            tname = root.get("name") or root.get("displayName")
            for tgt, _ in rels(n).values():
                qt = "xl/" + tgt.replace("../", "")
                q = out["query_tables"].get(qt)
                if q:
                    out["table_connections"][tname] = q["connectionId"]
    # Power Query
    for n in names:
        if n.startswith("customXml/item") and n.endswith(".xml"):
            try:
                if b"DataMashup" in z.read(n)[:4000]:
                    out["power_query"] = True
            except Exception:
                pass
    # pivot caches are another "where did this number come from" source
    out["pivot_caches"] = sorted(n for n in names if n.startswith("xl/pivotCache/pivotCacheDefinition"))
    return out


# ----------------------------------------------------------------------------- formula shape
class Shaper:
    def __init__(self, names):
        self.names = {k.lower(): v for k, v in names.items()}

    def norm_cell(self, cell, row, col):
        m = re.fullmatch(r"(\$?)([A-Za-z]{1,3})?(\$?)(\d+)?", cell)
        if not m or not (m.group(2) or m.group(4)):
            return cell
        ac, c, ar, r = m.groups()
        cs = ""
        if c:
            ci = column_index_from_string(c.upper())
            cs = f"C{ci}" if ac else f"C[{ci - col}]"
        rs = ""
        if r:
            rs = f"R{r}" if ar else f"R[{int(r) - row}]"
        return rs + cs

    def shape(self, formula, row, col):
        """Returns (shape_with_<str>, literals, refs, names_used, external_literal_paths)."""
        out, lits, refs, names_used, ext = [], [], [], {}, []
        for t in Tokenizer(formula).items:
            if t.type == "OPERAND" and t.subtype == "RANGE":
                val = t.value
                key = val.lower()
                if key in self.names:
                    names_used[val] = self.names[key]
                    out.append(val)
                    continue
                sheet, _, ref = val.rpartition("!")
                m = re.search(r"\[([^\]]+\.xls[xmb]?)\]", sheet)
                if m:
                    ext.append(m.group(1))
                refs.append(val)
                if "[" in sheet and not m and re.search(r"\[\d+\]", sheet):
                    pass
                if re.fullmatch(r"\$?[A-Za-z]{1,3}:\$?[A-Za-z]{1,3}|\$?\d+:\$?\d+", ref):
                    out.append(val)                       # whole column / whole row: keep raw
                    continue
                parts = [self.norm_cell(p, row, col) for p in ref.split(":")]
                out.append((sheet + "!" if sheet else "") + ":".join(parts))
            elif t.type == "OPERAND" and t.subtype == "TEXT":
                lits.append(t.value[1:-1] if len(t.value) >= 2 else t.value)
                out.append("<str>")
            elif t.type == "FUNC":
                out.append(t.value.upper())
            elif t.type == "WHITE-SPACE":
                continue
            else:
                out.append(t.value)
        return "".join(out), lits, refs, names_used, ext


# ----------------------------------------------------------------------------- sheet scanning
class SheetView:
    """Cheap access to a worksheet with merged-cell awareness."""

    def __init__(self, ws):
        self.ws = ws
        self.max_row, self.max_col = ws.max_row or 1, ws.max_column or 1
        self.merged_master = {}
        self.merged_group = {}
        try:
            for rng in ws.merged_cells.ranges:
                min_c, min_r, max_c, max_r = rng.bounds
                for r in range(min_r, max_r + 1):
                    for c in range(min_c, max_c + 1):
                        self.merged_master[(r, c)] = (min_r, min_c)
                        self.merged_group[(r, c)] = rng.coord
        except Exception:
            pass

    def value(self, r, c):
        if r < 1 or c < 1:
            return None
        m = self.merged_master.get((r, c))
        if m:
            r, c = m
        return self.ws.cell(row=r, column=c).value

    def same_merge(self, a, b):
        return (a in self.merged_group) and self.merged_group.get(a) == self.merged_group.get(b)

    def label_left(self, r, c):
        for k in range(c - 1, 0, -1):
            v = self.value(r, k)
            if is_text(v) or isinstance(v, (dt.date, dt.datetime)):
                return (r, k, v)
        return None

    def label_above(self, r, c):
        for k in range(r - 1, 0, -1):
            v = self.value(k, c)
            if is_text(v) or isinstance(v, (dt.date, dt.datetime)):
                return (k, c, v)
        return None


def first_header_row(sv, min_strings=3):
    for r in range(1, min(sv.max_row, 50) + 1):
        vals = [sv.ws.cell(row=r, column=c).value for c in range(1, sv.max_col + 1)]
        strings = [v for v in vals if is_text(v)]
        if len(strings) >= min_strings:
            return r, [jsonable(v) for v in vals]
    return None, []


def column_profile(ws, header_row, max_col):
    cols = []
    for c in range(1, max_col + 1):
        name = ws.cell(row=header_row, column=c).value
        kinds, example = set(), None
        for r in range(header_row + 1, min(ws.max_row, header_row + 500) + 1):
            v = ws.cell(row=r, column=c).value
            if v is None:
                continue
            if example is None:
                example = jsonable(v)
            kinds.add("date" if isinstance(v, (dt.date, dt.datetime)) else "number" if is_num(v) else "bool" if isinstance(v, bool) else "string")
        t = "empty" if not kinds else (kinds.pop() if len(kinds) == 1 else "mixed")
        cols.append({"name": jsonable(name), "type": t, "example": example})
    return cols


def cell_label(sv, r, c):
    """Label text for a single cell: 'left label / header above' with Nones dropped."""
    left, above = sv.label_left(r, c), sv.label_above(r, c)
    parts = [as_text(x[2]).strip() for x in (left, above) if x]
    return " / ".join(parts) if parts else None


def label_for_ref(ref, views, header_rows, home_sheet):
    """Best-effort label for a range reference (used for reads_labels)."""
    sheet, cell = strip_sheet(ref)
    if sheet is None:
        sheet = home_sheet
    if re.search(r"\[", sheet or ""):
        return None
    sv = views.get(sheet)
    if sv is None:
        return None
    cell = cell.replace("$", "")
    try:
        if re.fullmatch(r"[A-Za-z]{1,3}:[A-Za-z]{1,3}", cell):           # whole columns
            hr = header_rows.get(sheet)
            if hr is None:
                return None
            a, b = cell.split(":")
            labels = [sv.value(hr, k) for k in range(column_index_from_string(a.upper()), column_index_from_string(b.upper()) + 1)]
            labels = [as_text(x) for x in labels if x is not None]
            return ", ".join(labels) or None
        if re.fullmatch(r"\d+:\d+", cell):                                # whole rows
            a, b = cell.split(":")
            labels = [sv.label_left(int(k), sv.max_col + 1) for k in range(int(a), int(b) + 1)]
            return ", ".join(as_text(x[2]) for x in labels if x) or None
        min_c, min_r, max_c, max_r = range_boundaries(cell)
        if (min_c, min_r) == (max_c, max_r):
            return cell_label(sv, min_r, min_c)
        hr = header_rows.get(sheet)
        if hr is not None and min_r > hr:
            labels = [sv.value(hr, k) for k in range(min_c, max_c + 1)]
            labels = [as_text(x) for x in labels if x is not None]
            if labels:
                return ", ".join(labels)
        left = sv.label_left(min_r, min_c)
        above = sv.label_above(min_r, min_c)
        parts = [as_text(x[2]) for x in (left, above) if x]
        return " / ".join(parts) or None
    except Exception:
        return None


# ----------------------------------------------------------------------------- main parse
def parse(path):
    questions = []
    try:
        wb = load_workbook(path)
    except Exception as e:
        raise SystemExit(f"cannot open {path}: {e}")
    try:
        wv = load_workbook(path, data_only=True)
    except Exception as e:
        wv = None
        questions.append(f"Could not open the workbook for cached values ({e}); every 'cached' entry is null.")

    parts = read_zip_parts(path, questions)
    props = wb.properties
    properties = {
        "lastModifiedBy": props.lastModifiedBy, "modified": jsonable(props.modified),
        "creator": props.creator, "created": jsonable(props.created), "title": props.title,
        "calcMode": getattr(wb.calculation, "calcMode", None), "fullCalcOnLoad": getattr(wb.calculation, "fullCalcOnLoad", None),
        "sheet_order": wb.sheetnames,
    }

    # defined names, workbook- and sheet-scoped
    names = OrderedDict()
    try:
        for n, d in wb.defined_names.items():
            names[n] = d.attr_text
    except Exception:
        pass
    for ws in wb.worksheets:
        try:
            for n, d in ws.defined_names.items():
                names[f"{ws.title}!{n}"] = d.attr_text
                names.setdefault(n, d.attr_text)
        except Exception:
            pass
    shaper = Shaper(names)

    views = {ws.title: SheetView(ws) for ws in wb.worksheets}
    sheets, header_rows, sheet_kind = [], {}, {}
    tables = []
    table_cells = {}   # sheet -> list of (bounds, listobject name, connection id)

    # ---- pass 1: classify sheets, tables, comments
    for ws in wb.worksheets:
        sv = views[ws.title]
        info = {"name": ws.title, "kind": None, "hidden": ws.sheet_state != "visible", "sheet_state": ws.sheet_state,
                "rows": ws.max_row, "max_column": ws.max_column, "formulas": 0, "constants": 0, "strings": 0,
                "header_row": None, "column_headers": [], "comments": [], "merged_ranges": len(sv.merged_group) and len(set(sv.merged_group.values()))}
        try:
            for row in ws.iter_rows():
                for c in row:
                    v = c.value
                    if v is None:
                        continue
                    if formula_text(v):
                        info["formulas"] += 1
                    elif is_text(v):
                        info["strings"] += 1
                    elif is_num(v):
                        info["constants"] += 1
                    if c.comment:
                        info["comments"].append([c.coordinate, c.comment.text.strip()])
            hr, headers = first_header_row(sv)
            info["header_row"], info["column_headers"] = hr, headers
            header_rows[ws.title] = hr
            header_like = hr is not None and sum(1 for h in headers if isinstance(h, str)) >= 3
            if info["hidden"]:
                info["kind"] = "hidden"
            elif info["formulas"] == 0 and header_like and ws.max_row >= 20:
                info["kind"] = "data dump"
            else:
                info["kind"] = "scorecard"
            if info["kind"] == "data dump":
                info["columns"] = column_profile(ws, hr, ws.max_column)
                info["data_rows"] = ws.max_row - hr
            # ListObjects
            table_cells[ws.title] = []
            for t in list((ws.tables or {}).values()):
                tname = t.displayName or t.name
                try:
                    cols = [tc.name for tc in t.tableColumns]
                except Exception:
                    cols = []
                conn = parts["table_connections"].get(tname)
                bounds = range_boundaries(t.ref)
                table_cells[ws.title].append((bounds, tname, conn))
                tables.append({"sheet": ws.title, "listobject": tname, "ref": t.ref, "tableType": t.tableType,
                               "columns": cols, "rows": bounds[3] - bounds[1], "connection": conn, "kind_guess": None})
        except Exception as e:
            info["error"] = f"{type(e).__name__}: {e}"
            info["kind"] = info["kind"] or ("hidden" if info["hidden"] else "scorecard")
            questions.append(f"Sheet '{ws.title}' could not be fully read ({type(e).__name__}: {e}); its contents were skipped and must be checked by hand.")
        sheet_kind[ws.title] = info["kind"]
        sheets.append(info)

    # tables entries for data dumps without a ListObject
    for info in sheets:
        if info["kind"] == "data dump":
            covered = any(t["sheet"] == info["name"] and range_boundaries(t["ref"])[1] <= info["header_row"] for t in tables)
            if not covered:
                tables.append({"sheet": info["name"], "listobject": None, "ref": None, "tableType": None,
                               "columns": [c["name"] for c in info["columns"]], "rows": info["data_rows"], "connection": None, "kind_guess": None})
    all_comment_text = " ".join(t for s in sheets for _, t in s["comments"]).lower()
    for t in tables:
        sheet_comments = " ".join(txt for s in sheets if s["name"] == t["sheet"] for _, txt in s["comments"]).lower()
        cols = [c for c in t["columns"] if isinstance(c, str)]
        snake = cols and all(re.fullmatch(r"[a-z0-9_]+", c) for c in cols)
        if t["connection"] or t["tableType"] == "queryTable":
            t["kind_guess"] = "Script output"
            t["kind_reason"] = "ListObject fed by a connection"
        elif re.search(r"notebook|databricks|export|query|script|pasted|sql|pipeline|job", sheet_comments):
            t["kind_guess"] = "Script output"
            t["kind_reason"] = "a comment on the sheet says so"
        elif snake:
            t["kind_guess"] = "Script output"
            t["kind_reason"] = "column headers are snake_case identifiers"
        elif cols and any(" " in c for c in cols) and any(s["name"] == t["sheet"] and s["formulas"] > 0 for s in sheets):
            t["kind_guess"] = "Manual spreadsheet"
            t["kind_reason"] = "human-style headers and formulas on the sheet"
        else:
            t["kind_guess"] = "Unknown"
            t["kind_reason"] = "no connection, comment or naming pattern to go on"

    # ---- pass 2: value cells on visible scorecard sheets
    records = []
    hidden_reads = defaultdict(list)
    ext_literal_paths = set()
    for ws in wb.worksheets:
        if sheet_kind[ws.title] != "scorecard":
            continue
        sv = views[ws.title]
        wsv = wv[ws.title] if wv is not None and ws.title in wv.sheetnames else None
        unlabelled = []
        shape_cache = {}

        def shape_of(cell):
            key = (cell.row, cell.column)
            if key in shape_cache:
                return shape_cache[key]
            v = cell.value
            f = formula_text(v)
            if f is None:
                res = ("<constant>", [], [], {}, []) if is_num(v) else None
            else:
                try:
                    res = shaper.shape(f, cell.row, cell.column)
                except Exception as e:
                    res = ("<unparsed>", [], [], {}, [])
                    questions.append(f"Formula in {ws.title}!{cell.coordinate} could not be tokenised ({e}): {f}")
            shape_cache[key] = res
            return res

        try:
            for row in ws.iter_rows():
                for c in row:
                    v = c.value
                    f = formula_text(v)
                    if f is None and not is_num(v):
                        continue
                    if (c.row, c.column) in sv.merged_master and sv.merged_master[(c.row, c.column)] != (c.row, c.column):
                        continue
                    left, above = sv.label_left(c.row, c.column), sv.label_above(c.row, c.column)
                    if left and sv.same_merge((c.row, c.column), (left[0], left[1])):
                        left = None
                    if not left and not above:
                        unlabelled.append(c.coordinate)
                        continue
                    shp = shape_of(c)
                    # orientation: label to the left (row block) or above (column block)?
                    if left and not above:
                        orient = "row"
                    elif above and not left:
                        orient = "column"
                    elif looks_period(above[2]) and not looks_period(left[2]):
                        orient = "row"
                    elif looks_period(left[2]) and not looks_period(above[2]):
                        orient = "column"
                    else:
                        # neither header looks like a period: does the same formula shape run
                        # sideways (row block) or downwards (calculated column)?
                        def same(r, k):
                            if r < 1 or k < 1 or r > sv.max_row or k > sv.max_col:
                                return False
                            other = shape_of(ws.cell(row=r, column=k))
                            return other is not None and other[0] == shp[0]
                        same_h = same(c.row, c.column - 1) or same(c.row, c.column + 1)
                        same_v = same(c.row - 1, c.column) or same(c.row + 1, c.column)
                        orient = "column" if (same_v and not same_h) else "row"
                    lab, dim = (left, above) if orient == "row" else (above, left)
                    label = as_text(lab[2]).strip()
                    dim_header = jsonable(dim[2]) if dim else None
                    in_table = None
                    for bounds, tname, conn in table_cells.get(ws.title, []):
                        if bounds[0] <= c.column <= bounds[2] and bounds[1] <= c.row <= bounds[3]:
                            in_table = (tname, conn)
                    rec = {"sheet": ws.title, "coord": c.coordinate, "row": c.row, "col": c.column,
                           "label": label, "nlabel": norm_label(label), "orient": orient,
                           "dim_header": dim_header, "dim_pos": get_column_letter(c.column) if orient == "row" else str(c.row),
                           "number_format": c.number_format, "comment": c.comment.text.strip() if c.comment else None,
                           "cached": None, "formula": f, "in_table": in_table}
                    if wsv is not None:
                        try:
                            rec["cached"] = jsonable(wsv[c.coordinate].value)
                        except Exception:
                            pass
                    rec["shape"], rec["lits"], rec["refs"], rec["names"], ext = shp
                    ext_literal_paths.update(ext)
                    if f is None:
                        rec["cached"] = jsonable(v)
                        rec["kind"] = "connection value" if (in_table and in_table[1]) else "pasted value"
                    else:
                        rec["kind"] = "formula"
                        for r in list(rec["refs"]) + list(rec["names"].values()):
                            sh, _ = strip_sheet(r)
                            if sh and sheet_kind.get(sh) == "hidden":
                                hidden_reads[sh].append(f"{ws.title}!{c.coordinate}")
                    if v.__class__.__name__ == "ArrayFormula":
                        rec["array"] = getattr(v, "ref", None)
                    records.append(rec)
        except Exception as e:
            questions.append(f"Sheet '{ws.title}' failed while scanning values ({type(e).__name__}: {e}); metrics from it may be incomplete.")
        for info in sheets:
            if info["name"] == ws.title:
                info["unlabelled_values"] = unlabelled
                if unlabelled:
                    questions.append(f"Sheet '{ws.title}' has {len(unlabelled)} numbers or formulas with no label to the left or above (e.g. {', '.join(unlabelled[:4])}); what are they?")

    # ---- pass 3: group into metrics and resolve literals
    groups = OrderedDict()
    for rec in records:
        groups.setdefault((rec["nlabel"], rec["kind"], rec["shape"]), []).append(rec)

    metrics = []
    uncalculated, pasted_silent = defaultdict(list), []
    for (nlabel, kind, shape_key), recs in groups.items():
        first = recs[0]
        n_lits = len(first["lits"])
        parameters, pieces = {}, shape_key.split("<str>")
        resolved = [pieces[0]]
        unresolved = []
        for i in range(n_lits):
            vals = [r["lits"][i] if i < len(r["lits"]) else None for r in recs]
            distinct = sorted(set(v for v in vals if v is not None))
            token = None
            if len(distinct) <= 1:
                token = '"' + (distinct[0] if distinct else "") + '"'
            else:
                by_sheet = defaultdict(set)
                by_dim = defaultdict(set)
                for r, v in zip(recs, vals):
                    by_sheet[r["sheet"]].add(v)
                    by_dim[(r["sheet"], r["dim_pos"])].add(v)
                sheet_const = all(len(s) == 1 for s in by_sheet.values()) and len(by_sheet) > 1
                if sheet_const and all(next(iter(s)).lower() == sh.lower() for sh, s in by_sheet.items()):
                    token = '"<sheet>"'
                elif sheet_const:
                    pname = f"literal_{i + 1}"
                    parameters[pname] = {"varies_with": "sheet", "values": {sh: next(iter(s)) for sh, s in by_sheet.items()}}
                    token = f'"<{pname}>"'
                else:
                    by_pos = defaultdict(set)
                    for r, v in zip(recs, vals):
                        by_pos[r["dim_pos"]].add(v)
                    pos_const = all(len(s) == 1 for s in by_pos.values()) and len(by_pos) > 1
                    if pos_const:
                        headers = {}
                        for r, v in zip(recs, vals):
                            headers[str(r["dim_header"]) if r["dim_header"] is not None else r["dim_pos"]] = v
                        if all(str(r["dim_header"]) == v for r, v in zip(recs, vals) if r["dim_header"] is not None) and any(r["dim_header"] is not None for r in recs):
                            token = '"<column header>"' if first["orient"] == "row" else '"<row header>"'
                        else:
                            pname = "period" if all(looks_period(v) for v in distinct) else f"literal_{i + 1}"
                            if pname in parameters:
                                pname = f"{pname}_{i + 1}"
                            parameters[pname] = {"varies_with": "column" if first["orient"] == "row" else "row", "values": headers}
                            token = f'"<{pname}>"'
                    else:
                        token = '"<str>"'
                        unresolved.append((i + 1, distinct))
            resolved.append(token)
            resolved.append(pieces[i + 1] if i + 1 < len(pieces) else "")
        shape = "".join(resolved)
        reads = []
        for r in recs:
            for x in r["refs"]:
                if x not in reads:
                    reads.append(x)
            for nm, tgt in r["names"].items():
                if tgt not in reads:
                    reads.append(tgt)
        names_used = {}
        for r in recs:
            names_used.update(r["names"])
        reads_labels = []
        for x in reads:
            lbl = label_for_ref(x, views, header_rows, first["sheet"])
            if lbl:
                reads_labels.append([x, lbl])
        tabs = []
        for r in recs:
            if r["sheet"] not in tabs:
                tabs.append(r["sheet"])
        dim_headers = []
        for r in recs:
            if r["dim_header"] is not None and r["dim_header"] not in dim_headers:
                dim_headers.append(r["dim_header"])
        comments = [[f"{r['sheet']}!{r['coord']}", r["comment"]] for r in recs if r["comment"]]
        m = {
            "label": first["label"], "normalised_label": nlabel, "kind": kind, "shape": shape,
            "formula_example": first["formula"], "reads": reads, "reads_labels": reads_labels, "names_used": names_used,
            "where": [f"{r['sheet']}!{r['coord']}" for r in recs], "tabs": tabs,
            "cached": [r["cached"] for r in recs], "parameters": parameters,
            "dimension": {"axis": "columns" if first["orient"] == "row" else "rows", "headers": dim_headers},
            "unit_hint": unit_hint(first["label"], first["formula"], first["number_format"]),
            "number_format": first["number_format"], "comments": comments,
        }
        if any(r.get("array") for r in recs):
            m["array_formula"] = [r["array"] for r in recs if r.get("array")]
        if any(r["in_table"] for r in recs):
            m["listobject"] = sorted({r["in_table"][0] for r in recs if r["in_table"]})
        metrics.append(m)
        for i, distinct in unresolved:
            questions.append(f"Metric '{first['label']}' ({shape_key}) uses text literal #{i} with values {distinct} that do not follow the sheet or the column; are these different metrics or a parameter?")
        if kind == "formula":
            for w, cv in zip(m["where"], m["cached"]):
                if cv is None:
                    uncalculated[w.split("!")[0]].append((first["label"], w))
        if kind == "pasted value" and not comments:
            pasted_silent.append(m)

    for sheet_name, items in uncalculated.items():
        labels = []
        for lbl, _ in items:
            if lbl not in labels:
                labels.append(lbl)
        questions.append(f"Sheet '{sheet_name}' has {len(items)} formula cell(s) with no cached value ({', '.join(w for _, w in items[:3])}{'...' if len(items) > 3 else ''}) across {len(labels)} metric(s) ({', '.join(labels[:5])}{'...' if len(labels) > 5 else ''}); the workbook was never calculated after they were written, so the numbers readers see cannot be checked here.")
    if len(pasted_silent) <= 20:
        for m in pasted_silent:
            questions.append(f"Metric '{m['label']}' is pasted constants in {', '.join(m['where'][:6])}{'...' if len(m['where']) > 6 else ''} with no comment saying where they came from; which notebook, query or person produces them?")
    else:
        per_sheet = defaultdict(list)
        for m in pasted_silent:
            for t in m["tabs"]:
                per_sheet[t].append(m["label"])
        for t, labels in per_sheet.items():
            questions.append(f"Sheet '{t}' has {len(labels)} labelled blocks of pasted constants with no comment saying where they came from (e.g. {', '.join(labels[:5])}); which notebook, query or person produces them?")

    # same label, several shapes or kinds
    by_label = defaultdict(list)
    for m in metrics:
        by_label[m["normalised_label"]].append(m)
    for nlabel, ms in by_label.items():
        if len(ms) > 1:
            desc = "; ".join(f"{m['kind']} {m['shape']} in {', '.join(m['tabs'])}" for m in ms)
            questions.append(f"Label '{ms[0]['label']}' is computed {len(ms)} different ways ({desc}); are these meant to be the same metric?")

    # hidden sheets
    for info in sheets:
        if info["kind"] == "hidden":
            readers = sorted(set(hidden_reads.get(info["name"], [])))
            info["read_by_visible_formulas"] = readers
            if readers:
                questions.append(f"Hidden sheet '{info['name']}' ({info['sheet_state']}) is read by visible formulas ({', '.join(readers[:5])}); what does it hold and who maintains it?")
            else:
                questions.append(f"Hidden sheet '{info['name']}' ({info['sheet_state']}) is not read by any visible formula; is it stale, or an input for something outside this file?")

    # external links, connections, power query
    external_links = parts["external_links"]
    for p in sorted(ext_literal_paths):
        if not any(e.get("path") and p in e["path"] for e in external_links):
            external_links.append({"index": None, "path": p, "part": "formula literal"})
    for e in external_links:
        questions.append(f"Formulas reach into another workbook ({e.get('path') or 'path not recorded'}); is that file still where the link points, and who updates it?")
    connections = [{"name": c["name"], "type": c["type"], "command": c["command"], "connection": c["connection"]} for c in parts["connections"]]
    for c in connections:
        questions.append(f"Workbook has a data connection '{c['name']}' ({c['type']}) running: {c['command'] or c['connection'] or 'command not recorded'}; is it refreshed, and by whom?")
    if parts["power_query"]:
        questions.append("Workbook contains Power Query (DataMashup) definitions that this script does not decode; open Data > Queries & Connections to list the queries and their sources.")
    if parts.get("pivot_caches"):
        questions.append(f"Workbook has {len(parts['pivot_caches'])} pivot cache(s); pivot tables are summarised data whose source must be confirmed in Excel.")
    for t in tables:
        if t["listobject"] is None and t["kind_guess"] != "Script output":
            questions.append(f"Sheet '{t['sheet']}' is a data dump ({t['rows']} rows, {len(t['columns'])} columns) with no connection or comment saying which notebook or query produced it; what writes it?")
        elif t["listobject"] is None and t["kind_reason"] != "a comment on the sheet says so":
            questions.append(f"Sheet '{t['sheet']}' looks like script output ({t['kind_reason']}) but nothing in the file names the script; which notebook writes it?")
    if not metrics:
        questions.append("No labelled numbers or formulas were found on any visible sheet; is this workbook a scorecard at all, or does it hold only data dumps?")

    return {"file": path, "properties": properties, "sheets": sheets, "metrics": metrics, "tables": tables,
            "named_ranges": names, "external_links": external_links, "connections": connections,
            "power_query": parts["power_query"], "questions": questions}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out")
    a = ap.parse_args()
    data = parse(a.path)
    js = json.dumps(data, indent=2, default=str)
    if a.out:
        open(a.out, "w").write(js)
        print(f"wrote {a.out}: {len(data['sheets'])} sheets, {len(data['metrics'])} metrics, {len(data['tables'])} tables, {len(data['questions'])} questions")
    else:
        print(js)


if __name__ == "__main__":
    main()
