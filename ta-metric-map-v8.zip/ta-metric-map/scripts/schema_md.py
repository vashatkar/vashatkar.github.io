#!/usr/bin/env python3
"""Write references/schema.md from references/schema.json (v8). Run after build_v8.py."""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__)); REF = os.path.join(HERE, "..", "references")
S = json.load(open(os.path.join(REF, "schema.json")))
WHO = {"Tool": "sync (never typed)", "Machine": "the skill, from files", "Propose": "the skill proposes; a person confirms", "Human": "a person only"}
KIND = {"key": "name (the key, unique)", "in": "text", "dd": "drop-down", "names": "one name per line, each '- '", "link": "one name, drop-down from a sheet", "derived": "filled by sync"}
L = ["# Workbook schema (v8)", "", f"Header row {S['header_row']}, data from row {S['first_row']}. Plain database: every column visible, no helpers, no merged cells, no ID codes. Names are the keys.", ""]
for sheet, d in S["sheets"].items():
    L += [f"## {sheet}", "", "| Column | Kind | Who | Values / links to | Meaning |", "|---|---|---|---|---|"]
    for c in d["columns"]:
        extra = ", ".join(c["dropdown"]) if c.get("dropdown") else (("names on " + (c["link_to"][0] if isinstance(c["link_to"], list) else c["link_to"])) if c.get("link_to") else "")
        L.append(f"| {c['name']} | {KIND.get(c['kind'], c['kind'])} | {WHO.get(c['who'], c['who'])} | {extra} | {(c.get('meaning') or '').replace(chr(10), ' ')} |")
    L.append("")
open(os.path.join(REF, "schema.md"), "w").write("\n".join(L) + "\n"); print("wrote schema.md")
