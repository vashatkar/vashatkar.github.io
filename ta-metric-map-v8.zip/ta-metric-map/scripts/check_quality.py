#!/usr/bin/env python3
"""
Text-quality check for the v8 workbook, on top of workbook.py check (which covers duplicates, names, codes).

    python3 check_quality.py <map.xlsx> [-o findings.json]

Rules (error unless marked warn):
  Q1  Metrics: "What the code does" has a formula but no plain sentence above it           (warn: the finishing step not done yet)
  Q2  Metrics: neither a definition, nor code, nor an open Question naming the row
  Q3  Metrics: Family set but not on the Families list (references/families.md)
  Q4  Metrics: Family is a fragment of the metric name
  Q5  Any sheet: plain-words cell contains formula syntax or snake_case column names  (Definition in plain words, Why, Rule words)
  Q6  Any sheet: plain-words cell starts with "This metric/table/field", or contains filler words (leverage, robust, holistic, streamline, ensure, comprehensive, seamless, delve, crucial)
  Q7  Metrics: a cut on Metrics is not spelled as on Dimensions
  Q8  Legacy tables: a "View we built" or "Script output file" row with no Built by and no open Question
  Q9  Legacy tables: an HRDW row whose Built by is not "delivered by PDP" (sync not run)
  Q10 Products: no Reads from and no open Question
  Q11 Legacy to target: Why or Business logic empty  (warn: the analyst's note is missing)
  Q12 Metrics: Who is left out filled but has no quoted filter (no WHERE / = / IN / NOT in it)
Exit 1 on any error.
"""
import sys, os, re, json
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import workbook as W
from openpyxl import load_workbook

FAM = []
try:
    for line in open(os.path.join(HERE, "..", "references", "families.md")):
        m = re.match(r"\|\s*([A-Z][^|]*\?)\s*\|", line)
        if m: FAM.append(m.group(1).strip())
except Exception: pass
FILLER = re.compile(r"\b(leverage|robust|holistic|streamline|ensure|comprehensive|seamless|delve|crucial|utili[sz]e)\b", re.I)
CODEY = re.compile(r"(DATEDIFF|COUNTD|SUMIFS?\(|AVERAGEIFS?\(|COUNTIFS?\(|\bIF\(|\bNULL\b|\[[A-Za-z_ ]+\]|\b\w+_\w+_\w+\b)")


def main():
    path = sys.argv[1]; out = sys.argv[sys.argv.index("-o") + 1] if "-o" in sys.argv else None
    wb = load_workbook(path); F = []
    def add(sev, rule, sheet, r, name, col, msg): F.append({"severity": sev, "rule": rule, "sheet": sheet, "row": r, "name": name, "column": col, "message": msg})
    openq = {str(row.get("About") or "").lower() for r, row in W.rows_raw(wb["Questions"], "Questions") if row.get("Status") == "Open"}
    def questioned(sheet, name): return f"{sheet}: {name}".lower() in openq
    dims = {str(row.get("Cut name") or "").strip().lower() for r, row in W.rows_raw(wb["Dimensions"], "Dimensions")}
    for r, row in W.rows_raw(wb["Metrics"], "Metrics"):
        name = row.get("Metric name"); code = str(row.get("What the code does") or ""); dfn = str(row.get("Definition in plain words") or "")
        if code.strip().startswith("Formula:") or (code and "\n" not in code and "Formula:" in code): add("warn", "Q1", "Metrics", r, name, "What the code does", "Formula only; the plain sentence above it is still to write.")
        if not code and not dfn and not questioned("Metrics", name): add("error", "Q2", "Metrics", r, name, "Definition in plain words", "No definition, no code, and no open Question about this row.")
        fam = row.get("Family")
        if fam and FAM and fam not in FAM: add("error", "Q3", "Metrics", r, name, "Family", f"'{fam}' is not on the Families list.")
        if fam and name and str(name).lower().startswith(str(fam).lower().rstrip("?")[:12]) and "?" not in str(fam): add("error", "Q4", "Metrics", r, name, "Family", "Family is a fragment of the metric name.")
        words = code.split("Formula:")[0] if "Formula:" in code else ""
        for col, text in (("Definition in plain words", dfn), ("What the code does (words)", words), ("Why", str(row.get("Why") or ""))):
            if text and CODEY.search(text): add("error", "Q5", "Metrics", r, name, col, "Formula syntax or column names in a plain-words cell.")
            if text and (re.match(r"\s*This (metric|table|field)", text) or FILLER.search(text)): add("error", "Q6", "Metrics", r, name, col, "Filler wording.")
        for cut in W.split_lines(row.get("Cuts")):
            if cut.lower() not in dims: add("error", "Q7", "Metrics", r, name, "Cuts", f"Cut '{cut}' is not spelled as on the Dimensions sheet.")
        left = str(row.get("Who is left out") or "")
        if left and not re.search(r"WHERE|=|\bIN\b|\bNOT\b|<>|!=", left, re.I): add("error", "Q12", "Metrics", r, name, "Who is left out", "Filled without a quoted filter from the code.")
    for r, row in W.rows_raw(wb["Legacy tables"], "Legacy tables"):
        name = row.get("Table name"); kind = row.get("Kind"); by = str(row.get("Built by") or "")
        if kind in ("View we built", "Script output file") and not by and not questioned("Legacy tables", name): add("error", "Q8", "Legacy tables", r, name, "Built by", "Nothing in the files builds this table and no Question says so.")
        if kind == "HRDW" and by != "delivered by PDP": add("error", "Q9", "Legacy tables", r, name, "Built by", "HRDW row not marked delivered by PDP; run sync.")
        for col in ("What PDP changes on load",):
            t = str(row.get(col) or "")
            if t and FILLER.search(t): add("error", "Q6", "Legacy tables", r, name, col, "Filler wording.")
    for r, row in W.rows_raw(wb["Products"], "Products"):
        name = row.get("Product name")
        if not row.get("Reads from") and not questioned("Products", name): add("error", "Q10", "Products", r, name, "Reads from", "Nothing recorded as feeding this product.")
    for r, row in W.rows_raw(wb["Legacy to target"], "Legacy to target"):
        name = f"{row.get('Legacy table')} -> {row.get('Target table')}"
        if not row.get("Why we need this") or not row.get("Business logic that will apply"): add("warn", "Q11", "Legacy to target", r, name, "Why we need this", "The analyst's note is missing on this arrow.")
    errs = [f for f in F if f["severity"] == "error"]
    for f in F: print(f"{f['severity']:5} {f['rule']:4} {f['sheet']} row {f['row']} ({f['name']}) {f['column']}: {f['message']}")
    print(f"total: {len(errs)} error, {len(F) - len(errs)} warn")
    if out: json.dump(F, open(out, "w"), indent=1)
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
