#!/usr/bin/env python3
"""
Read the restructure sheet ("Legacy <> New tables mapping", exported as .csv or .xlsx) into JSON.

Usage:
    python3 parse_restructure.py <restructure.csv|.xlsx> [-o out.json]

The sheet usually starts with legend rows ("Already Existed - HRDW Table", "Completed", ...)
before the real header. The header row is the first row with a cell containing "Legacy" and
"Table" (case-insensitive). Header names are matched loosely:
  Legacy Table              header containing "legacy" and "table"
  Legacy Logic/Issue        header containing "logic" or "issue"
  Data Domain               header containing "domain"
  Target Layer 2            header containing "layer" and "2"  (or "target" and "2")
  Target Layer 3            header containing "layer" and "3"  (or "target" and "3")
  Note - Why we need this   header containing "why" or starting with "note"
  Impacted Metrics          header containing "impact" or "metric"

Output JSON:
  file           path given
  header_row     1-based sheet row taken as the header
  columns        which header was used for each field (null when none was found)
  legend         non-empty cell texts from the rows above the header, in order
  pairs          one entry per (legacy table, target table) on one sheet row:
                   legacy      Legacy Table as written on that row, or carried down from the
                               nearest row above when the cell is blank (legacy_filled_down: true)
                   target      the Target Layer 2 or Target Layer 3 cell, verbatim
                   layer       "2" or "3"
                   why         Note - Why we need this, verbatim, for that sheet row only
                   logic       Legacy Logic/Issue, verbatim, for that sheet row
                   domain      Data Domain as written
                   impacted_metrics_as_written   Impacted Metrics cell verbatim (not split)
                   row         1-based sheet row
                 A row with both a Layer 2 and a Layer 3 value yields two pairs. A blank target
                 cell yields no pair. Notes are never merged across rows.
  no_legacy      rows whose Legacy Table is "-", "Manual Input", "N/A" or similar, with their
                 targets; each also raises a question
  legacy_tables  distinct legacy names in order of first appearance
  questions      plain sentences for the reviewer

Never raises on odd input.
"""
import argparse
import csv
import json
import re
import sys

PLACEHOLDER = re.compile(r"^(?:-+|—|n/?a|none|manual\s*input|tbd|\?+)$", re.I)


# ----------------------------------------------------------------------------- tabular reader
def cell_text(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def read_rows(path, questions):
    low = path.lower()
    if low.endswith((".xlsx", ".xlsm")):
        try:
            from openpyxl import load_workbook
        except ImportError:
            questions.append("openpyxl is not installed, so the .xlsx file could not be read; export it as .csv or pip install openpyxl.")
            return []
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
        except Exception as e:
            questions.append(f"Could not open {path} as a workbook ({e}).")
            return []
        ws = None
        for s in wb.worksheets:
            if "legacy" in s.title.lower() and "mapping" in s.title.lower():
                ws = s; break
        if ws is None:
            ws = wb.worksheets[0]
            if len(wb.worksheets) > 1:
                questions.append(f"No sheet named like 'Legacy <> New tables mapping'; the first sheet ({ws.title!r}) was read.")
        return [[cell_text(v) for v in row] for row in ws.iter_rows(values_only=True)]
    try:
        with open(path, encoding="utf-8-sig", errors="replace", newline="") as f:
            sample = f.read(4096); f.seek(0)
            dialect = csv.excel
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
            except csv.Error:
                pass
            return [[cell_text(c) for c in row] for row in csv.reader(f, dialect)]
    except OSError as e:
        questions.append(f"Could not read {path} ({e}).")
        return []


def norm(h):
    return re.sub(r"[^a-z0-9]+", " ", (h or "").lower()).strip()


def find_col(headers, *tests):
    for t in tests:
        for i, h in enumerate(headers):
            if h and t(h):
                return i
    return None


# ----------------------------------------------------------------------------- parse
def parse(path):
    out = {"file": path, "header_row": None, "columns": {}, "legend": [], "pairs": [], "no_legacy": [], "legacy_tables": [], "questions": []}
    q = out["questions"]
    rows = read_rows(path, q)
    if not rows:
        if not q:
            q.append("The restructure file is empty.")
        return out
    header_idx = None
    for i, row in enumerate(rows):
        if any("legacy" in norm(c) and "table" in norm(c) for c in row):
            header_idx = i
            break
    if header_idx is None:
        q.append("No header row containing 'Legacy Table' was found; nothing was read. Confirm this is the 'Legacy <> New tables mapping' export.")
        return out
    out["header_row"] = header_idx + 1
    for row in rows[:header_idx]:
        out["legend"] += [c for c in row if c]
    raw_headers = rows[header_idx]
    headers = [norm(h) for h in raw_headers]
    cols = {
        "legacy": find_col(headers, lambda h: "legacy" in h and "table" in h),
        "logic": find_col(headers, lambda h: "logic" in h or "issue" in h),
        "domain": find_col(headers, lambda h: "domain" in h),
        "layer2": find_col(headers, lambda h: "layer" in h and re.search(r"\b2\b", h), lambda h: "target" in h and re.search(r"\b2\b", h)),
        "layer3": find_col(headers, lambda h: "layer" in h and re.search(r"\b3\b", h), lambda h: "target" in h and re.search(r"\b3\b", h)),
        "why": find_col(headers, lambda h: "why" in h, lambda h: h.startswith("note")),
        "impacted": find_col(headers, lambda h: "impact" in h, lambda h: "metric" in h),
    }
    out["columns"] = {k: (raw_headers[v] if v is not None else None) for k, v in cols.items()}
    if cols["layer2"] is None and cols["layer3"] is None:
        q.append("Neither a 'Target Layer 2' nor a 'Target Layer 3' column was found; no pairs can be formed.")
    for k, label in (("why", "Note - Why we need this"), ("logic", "Legacy Logic/Issue"), ("impacted", "Impacted Metrics")):
        if cols[k] is None:
            q.append(f"No '{label}' column found; {k} is blank on every pair.")

    def get(row, key):
        c = cols[key]
        return row[c] if c is not None and c < len(row) else ""

    last_legacy = None
    for i in range(header_idx + 1, len(rows)):
        row = rows[i]; rnum = i + 1
        if not any(row):
            continue
        legacy_raw = get(row, "legacy")
        filled_down = False
        targets = [(get(row, "layer2"), "2"), (get(row, "layer3"), "3")]
        targets = [(t, l) for t, l in targets if t]
        if legacy_raw and PLACEHOLDER.match(legacy_raw):
            last_legacy = None
            out["no_legacy"].append({"legacy_as_written": legacy_raw, "targets": [{"target": t, "layer": l} for t, l in targets], "why": get(row, "why"), "row": rnum})
            tgt = ", ".join(t for t, _ in targets) or "no target"
            q.append(f"Row {rnum}: Legacy Table is {legacy_raw!r} ({tgt}). Is this a new table with no legacy source, or a legacy table whose name is missing?")
            continue
        if not legacy_raw:
            if last_legacy and targets:
                legacy_raw, filled_down = last_legacy, True
            elif targets:
                q.append(f"Row {rnum} has a target ({', '.join(t for t, _ in targets)}) but no legacy table and no row above to inherit from; skipped.")
                continue
            else:
                continue
        else:
            last_legacy = legacy_raw
        if legacy_raw not in out["legacy_tables"]:
            out["legacy_tables"].append(legacy_raw)
        if not targets:
            q.append(f"Row {rnum}: legacy table {legacy_raw!r} has no Target Layer 2 or Layer 3 value; where does it go?")
            continue
        for t, l in targets:
            pair = {"legacy": legacy_raw, "target": t, "layer": l, "why": get(row, "why"), "logic": get(row, "logic"), "domain": get(row, "domain"),
                    "impacted_metrics_as_written": get(row, "impacted"), "row": rnum}
            if filled_down:
                pair["legacy_filled_down"] = True
            out["pairs"].append(pair)
    filled = {}
    for p in out["pairs"]:
        if p.get("legacy_filled_down"):
            filled.setdefault(p["legacy"], []).append(str(p["row"]))
    for legacy, rws in filled.items():
        q.append(f"Row(s) {', '.join(dict.fromkeys(rws))}: Legacy Table was blank; {legacy!r} was carried down from the row above. Confirm these rows belong to it.")
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out")
    a = ap.parse_args()
    d = parse(a.path); js = json.dumps(d, indent=2)
    if a.out:
        open(a.out, "w").write(js)
        print(f"wrote {a.out}: {len(d['pairs'])} pairs, {len(d['legacy_tables'])} legacy tables, {len(d['questions'])} questions")
    else:
        print(js)


if __name__ == "__main__":
    main()
