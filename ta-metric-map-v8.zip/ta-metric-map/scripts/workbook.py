#!/usr/bin/env python3
"""
Read from and write to the TA metric map workbook (v8). Layout comes from ../references/schema.json.

    python3 workbook.py list     <map.xlsx> <sheet>
    python3 workbook.py append   <map.xlsx> <sheet> <rows.json>     # rows keyed by header text; link cells take names; multi-value cells take a list
    python3 workbook.py fill     <map.xlsx> <sheet> "<column>" <by_name.json>   # blank cells / Proposed rows only; a conflict becomes a Question
    python3 workbook.py set      <map.xlsx> <sheet> "<column>" <by_name.json> [--force]
    python3 workbook.py question <map.xlsx> "<sheet>: <row name>" "<question>" "<what was seen>" [pass]
    python3 workbook.py merge    <map.xlsx> Metrics "<keep>" "<fold>" ...   # fold duplicate metrics into one; names go to Same rule elsewhere
    python3 workbook.py sync     <map.xlsx>      # rebuild derived columns: Built by, Feeds, Goes to, Layer, Scripts, Used by metrics
    python3 workbook.py check    <map.xlsx>      # names resolve, keys unique, NO duplicate rows, no codes; exit 1 on any problem

Rules:
  * Names are the keys. There are no ID codes anywhere.
  * Multi-value cells hold one name per line, each line "- name". A JSON list or a comma string is accepted on input.
  * Never overwrites an Accepted or Corrected row (set --force excepted). Never writes Decision or Official.
  * A row whose key already exists is skipped and reported. A link to a name that does not exist is refused and questioned.
"""
import json, sys, re, os, datetime
from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
SCHEMA = json.load(open(os.path.join(HERE, "..", "references", "schema.json")))
H = SCHEMA["header_row"]; R1 = SCHEMA["first_row"]; SHEETS = SCHEMA["sheets"]
TODAY = datetime.date.today().isoformat()
LOCKED = ("Accepted", "Corrected")
HUMAN_ONLY = {"Decision", "Official", "Why", "Platform", "What PDP changes on load"}
KEY = {"Metrics": "Metric name", "Legacy tables": "Table name", "Products": "Product name", "Fields": "Field name", "Scripts": "Script name", "Dimensions": "Cut name", "Platforms": "Platform name"}
PAIR = {"Legacy to target": ("Legacy table", "Target table")}
CODE_RE = re.compile(r"\b(P|M|T|S|F|D|I|DL|Q)-\d{3,}\b")


def cols(sheet): return {c["name"]: i + 1 for i, c in enumerate(SHEETS[sheet]["columns"])}
def coldef(sheet, name): return next((c for c in SHEETS[sheet]["columns"] if c["name"] == name), None)
def key_col(sheet): return KEY.get(sheet)

def probe(sheet):
    cs = cols(sheet)
    if sheet in KEY: return [cs[KEY[sheet]]]
    if sheet in PAIR: return [cs[PAIR[sheet][0]], cs[PAIR[sheet][1]]]
    return [1]

def rows_raw(ws, sheet):
    cs = cols(sheet); out = []
    for r in range(R1, R1 + SHEETS[sheet]["cap"]):
        if all(ws.cell(row=r, column=c).value in (None, "") for c in probe(sheet)): continue
        out.append((r, {n: ws.cell(row=r, column=c).value for n, c in cs.items()}))
    return out

def first_empty_row(ws, sheet):
    r = R1
    while r < R1 + SHEETS[sheet]["cap"] and any(ws.cell(row=r, column=c).value not in (None, "") for c in probe(sheet)): r += 1
    if r >= R1 + SHEETS[sheet]["cap"]: raise SystemExit(f"{sheet} is full")
    return r

def headers_ok(ws, sheet):
    want = [c["name"] for c in SHEETS[sheet]["columns"]]; got = [ws.cell(row=H, column=i + 1).value for i in range(len(want))]
    return want == got

def split_lines(v):
    if v in (None, ""): return []
    if isinstance(v, list): return [str(x).strip() for x in v if str(x).strip()]
    s = str(v)
    if "\n" in s or s.strip().startswith("- "): return [x.strip().lstrip("-").strip() for x in s.splitlines() if x.strip().lstrip("-").strip()]
    return [x.strip() for x in re.split(r"[,;]\s*", s) if x.strip()]

def join_lines(items): return "\n".join("- " + x for x in items) if items else None


class Names:
    """name lookups per entity sheet, case-insensitive"""
    def __init__(self, wb):
        self.rows, self.canon = {}, {}
        for s, k in KEY.items():
            self.rows[s], self.canon[s] = {}, {}
            for r, row in rows_raw(wb[s], s):
                nm = str(row.get(k) or "").strip()
                if nm: self.rows[s][nm.lower()] = r; self.canon[s][nm.lower()] = nm
    def get(self, sheet, name):
        if name in (None, ""): return None
        return self.canon.get(sheet, {}).get(str(name).strip().lower())
    def row(self, sheet, name): return self.rows.get(sheet, {}).get(str(name).strip().lower())


def add_question(wb, about, question, seen, by="", names=None):
    ws = wb["Questions"]; cs = cols("Questions"); r = first_empty_row(ws, "Questions")
    for h, v in {"Question": question, "About": about, "What was seen": (seen or "")[:600], "Raised by pass": by, "Status": "Open"}.items(): ws.cell(row=r, column=cs[h], value=v)
    return r


def resolve_multi(nm, target, value, about, col, wb, by, warnings):
    items = split_lines(value); good, bad = [], []
    for it in items:
        c = nm.get(target, it)
        if c: good.append(c) if c not in good else None
        else: bad.append(it)
    for b in bad: add_question(wb, about, f"'{b}' in {col} does not match any name on {target}. Which is meant?", str(value)[:200], by, nm)
    if bad: warnings.append(f"{col}: not found on {target}: {', '.join(bad)}")
    return good


def append_rows(wb, sheet, new_rows, by="", default_source=None):
    ws = wb[sheet]
    if not headers_ok(ws, sheet): raise SystemExit(f"{sheet}: headers differ from schema.json")
    cs = cols(sheet); results = []
    for nr in new_rows:
        nm = Names(wb); warnings = []; nr = dict(nr)
        for h in list(nr):
            if h in HUMAN_ONLY and nr[h] not in (None, "") and sheet != "Legacy to target": warnings.append(f"{h} is a person's; dropped"); nr[h] = None
        k = key_col(sheet)
        about = f"{sheet}: {nr.get(k) or (nr.get(PAIR[sheet][0]) if sheet in PAIR else '')}"
        if k:
            name = str(nr.get(k) or "").strip()
            if not name: warnings.append("no name; skipped"); results.append((None, None, warnings)); continue
            if nm.row(sheet, name): warnings.append(f"already present at row {nm.row(sheet, name)}; not appended"); results.append((nm.get(sheet, name), nm.row(sheet, name), warnings)); continue
        if sheet in PAIR:
            a, b = PAIR[sheet]; dup = next((r for r, row in rows_raw(ws, sheet) if str(row.get(a) or "").strip().lower() == str(nr.get(a) or "").strip().lower() and str(row.get(b) or "").strip().lower() == str(nr.get(b) or "").strip().lower()), None)
            if dup: warnings.append(f"pair already present at row {dup}; not appended"); results.append((f"{nr.get(a)} -> {nr.get(b)}", dup, warnings)); continue
        broken = False
        for c in SHEETS[sheet]["columns"]:
            n, kd = c["name"], c["kind"]; v = nr.get(n)
            if v in (None, ""): continue
            if kd == "link":
                tgt = c["link_to"][0]; canon = nm.get(tgt, v)
                if not canon:
                    add_question(wb, about, f"The row links to '{v}' on {tgt}, but no row with that name exists. Which is meant? The row was not written.", json.dumps({a: b for a, b in nr.items() if b}, ensure_ascii=False)[:300], by, nm)
                    warnings.append(f"{n} '{v}' not on {tgt}; row NOT written"); broken = True
                else: nr[n] = canon
            elif kd == "names":
                nr[n] = join_lines(resolve_multi(nm, c["link_to"], v, about, n, wb, by, warnings))
            elif kd == "derived":
                warnings.append(f"{n} is filled by sync; value ignored"); nr[n] = None
            elif isinstance(v, list):
                nr[n] = join_lines([str(x) for x in v])
        if broken: results.append((None, None, warnings)); continue
        r = first_empty_row(ws, sheet)
        if "Confidence" in cs and not nr.get("Confidence"): nr["Confidence"] = "Proposed"
        if "Review" in cs and not nr.get("Review"): nr["Review"] = "Proposed"
        if "Source" in cs and not nr.get("Source") and default_source: nr["Source"] = default_source
        for h, v in nr.items():
            if h not in cs: warnings.append(f"unknown column '{h}' ignored"); continue
            cd = coldef(sheet, h)
            if cd.get("dropdown") and v not in (None, "") and v not in cd["dropdown"]:
                add_question(wb, about, f"Value '{v}' for {h} is not one of the allowed options ({', '.join(cd['dropdown'])}). Which applies?", str(v), by, nm); warnings.append(f"{h} '{v}' not allowed; left blank"); v = None
            ws.cell(row=r, column=cs[h], value=v)
        results.append((nr.get(k) if k else f"{nr.get(PAIR[sheet][0])} -> {nr.get(PAIR[sheet][1])}", r, warnings))
    return results


def write_col(wb, sheet, column, mapping, mode, force=False, by=""):
    ws = wb[sheet]; cs = cols(sheet); cd = coldef(sheet, column); nm = Names(wb); n = 0; rep = []
    if not cd: raise SystemExit(f"{column} is not on {sheet}")
    if cd["kind"] == "derived": raise SystemExit(f"{column} is filled by sync")
    if column in HUMAN_ONLY: raise SystemExit(f"{column} is a person's; tools never write it")
    for key, val in mapping.items():
        r = nm.row(sheet, key) if sheet in KEY else None
        if r is None: rep.append(f"{key}: not found"); continue
        about = f"{sheet}: {nm.get(sheet, key)}"
        if cd.get("dropdown") and val not in (None, "") and val not in cd["dropdown"]: add_question(wb, about, f"Value '{val}' for {column} is not an allowed option.", str(val), by, nm); rep.append(f"{key}: '{val}' not allowed"); continue
        if cd["kind"] == "link" and val not in (None, ""):
            canon = nm.get(cd["link_to"][0], val)
            if not canon: add_question(wb, about, f"{column} was to be set to '{val}', but no such row exists on {cd['link_to'][0]}.", str(val), by, nm); rep.append(f"{key}: '{val}' not found"); continue
            val = canon
        if cd["kind"] == "names" and val not in (None, ""): w = []; val = join_lines(resolve_multi(nm, cd["link_to"], val, about, column, wb, by, w)); rep += [f"{key}: {x}" for x in w]
        cur = ws.cell(row=r, column=cs[column]).value; review = ws.cell(row=r, column=cs["Review"]).value if "Review" in cs else None
        if mode == "fill":
            if cur not in (None, "") and str(cur).strip() == str(val or "").strip(): continue
            if cur in (None, "") or review not in LOCKED: ws.cell(row=r, column=cs[column], value=val); n += 1
            else: add_question(wb, about, f"{column} is '{str(cur)[:80]}' in the sheet (a person validated it) but the files show '{str(val)[:80]}'. Which is right?", "", by, nm); rep.append(f"{key}: conflict questioned")
        else:
            if review in LOCKED and not force: rep.append(f"{key}: row is {review}; not changed"); continue
            ws.cell(row=r, column=cs[column], value=val); n += 1
    return n, rep


def sync(wb):
    nm = Names(wb); rep = []
    T, S, P, M, F, D = (cols(x) for x in ("Legacy tables", "Scripts", "Products", "Metrics", "Fields", "Dimensions"))
    tables = {row["Table name"]: (r, row) for r, row in rows_raw(wb["Legacy tables"], "Legacy tables")}
    scripts = [row for r, row in rows_raw(wb["Scripts"], "Scripts")]
    products = {row["Product name"]: (r, row) for r, row in rows_raw(wb["Products"], "Products")}
    metrics = [row for r, row in rows_raw(wb["Metrics"], "Metrics")]
    pairs = [row for r, row in rows_raw(wb["Legacy to target"], "Legacy to target")]
    built_by, feeds = {}, {}
    for s in scripts:
        for t in split_lines(s.get("Builds")): built_by.setdefault(t, []).append(s["Script name"])
    for tname, (r, row) in tables.items():
        for parent in split_lines(row.get("Built from")): feeds.setdefault(parent, []).append(tname)
    for pname, (r, row) in products.items():
        for t in split_lines(row.get("Reads from")): feeds.setdefault(t, []).append(pname)
    goes, layers = {}, {}
    for p in pairs:
        goes.setdefault(p["Legacy table"], []).append(p["Target table"]); layers.setdefault(p["Legacy table"], [])
        if p.get("Layer") and str(p["Layer"]) not in layers[p["Legacy table"]]: layers[p["Legacy table"]].append(str(p["Layer"]))
    ws = wb["Legacy tables"]
    for tname, (r, row) in tables.items():
        hrdw = row.get("Kind") == "HRDW"
        ws.cell(row=r, column=T["Built by"], value="delivered by PDP" if hrdw else join_lines(built_by.get(tname, [])))
        ws.cell(row=r, column=T["Feeds"], value=join_lines(feeds.get(tname, [])))
        g = goes.get(tname, [])
        ws.cell(row=r, column=T["Goes to"], value="stays" if hrdw else (f"{len(g)} targets (split)" if len(g) > 1 else (g[0] if g else None)))
        ws.cell(row=r, column=T["Layer"], value="1" if hrdw else ", ".join(sorted(layers.get(tname, []))) or None)
        if hrdw and row.get("Status") in (None, ""): ws.cell(row=r, column=T["Status"], value="Stays")
        if not hrdw and row.get("Status") in (None, ""): ws.cell(row=r, column=T["Status"], value="Mapped" if g else "Not mapped")
        if hrdw and row.get("Owner") in (None, ""): ws.cell(row=r, column=T["Owner"], value="PDP")
    ws = wb["Products"]; fed = {}
    for s in scripts:
        for p in split_lines(s.get("Feeds")): fed.setdefault(p, []).append(s["Script name"])
    for pname, (r, row) in products.items(): ws.cell(row=r, column=P["Scripts"], value=join_lines(fed.get(pname, [])))
    used_f, used_d = {}, {}
    for m in metrics:
        for f in split_lines(m.get("Fields read")): used_f.setdefault(f, []).append(m["Metric name"])
        for d in split_lines(m.get("Cuts")): used_d.setdefault(d, []).append(m["Metric name"])
    ws = wb["Fields"]
    for r, row in rows_raw(ws, "Fields"): ws.cell(row=r, column=F["Used by metrics"], value=join_lines(used_f.get(row["Field name"], [])))
    ws = wb["Dimensions"]
    for r, row in rows_raw(ws, "Dimensions"): ws.cell(row=r, column=D["Used by metrics"], value=join_lines(used_d.get(row["Cut name"], [])))
    rep.append("sync done: Built by, Feeds, Goes to, Layer, Scripts, Used by metrics rebuilt")
    return rep


def norm(s): return re.sub(r"[^a-z0-9 ]", "", re.sub(r"\s+", " ", str(s or "").lower())).strip()


def check(wb):
    problems = []; nm = Names(wb)
    for s, d in SHEETS.items():
        ws = wb[s]
        if not headers_ok(ws, s): problems.append(f"{s}: headers differ from schema.json"); continue
        seen = {}
        for r, row in rows_raw(ws, s):
            if s in KEY:
                k = norm(row.get(KEY[s]))
                if k in seen: problems.append(f"DUPLICATE ROW on {s}: '{row.get(KEY[s])}' at rows {seen[k]} and {r}")
                seen[k] = r
            if s in PAIR:
                a, b = PAIR[s]; k = (norm(row.get(a)), norm(row.get(b)))
                if k in seen: problems.append(f"DUPLICATE ROW on {s}: {row.get(a)} -> {row.get(b)} at rows {seen[k]} and {r}")
                seen[k] = r
            for c in d["columns"]:
                v = row.get(c["name"])
                if v in (None, ""): continue
                if c["kind"] == "link" and not nm.get(c["link_to"][0], v): problems.append(f"{s} row {r}: {c['name']} '{v}' not found on {c['link_to'][0]}")
                if c["kind"] == "names":
                    for it in split_lines(v):
                        if not nm.get(c["link_to"], it): problems.append(f"{s} row {r}: '{it}' in {c['name']} not found on {c['link_to']}")
                if c.get("dropdown") and v not in c["dropdown"]: problems.append(f"{s} row {r}: {c['name']} '{v}' is not an allowed value")
                if isinstance(v, str) and CODE_RE.search(v): problems.append(f"{s} row {r}: {c['name']} contains a code where a name belongs")
    # duplicate calculations on Metrics
    seen = {}
    for r, row in rows_raw(wb["Metrics"], "Metrics"):
        code = norm((row.get("What the code does") or "").split("Formula:")[-1] if "Formula:" in str(row.get("What the code does") or "") else row.get("What the code does"))
        if code:
            if code in seen: problems.append(f"DUPLICATE CALCULATION on Metrics: '{row.get('Metric name')}' (row {r}) and '{seen[code][1]}' (row {seen[code][0]}) have the same code; fold one into the other")
            seen[code] = (r, row.get("Metric name"))
    return problems


def merge(wb, keep, folds, by=""):
    nm = Names(wb); ws = wb["Metrics"]; cs = cols("Metrics"); rep = []
    kr = nm.row("Metrics", keep)
    if not kr: raise SystemExit(f"{keep} not on Metrics")
    keep_name = nm.get("Metrics", keep)
    for f in folds:
        fr = nm.row("Metrics", f)
        if not fr: rep.append(f"{f}: not found"); continue
        fname = nm.get("Metrics", f)
        for col in ("Cuts", "Reads from", "Fields read", "Same rule elsewhere"):
            a = split_lines(ws.cell(row=kr, column=cs[col]).value); b = split_lines(ws.cell(row=fr, column=cs[col]).value)
            ws.cell(row=kr, column=cs[col], value=join_lines(a + [x for x in b if x not in a]))
        sre = split_lines(ws.cell(row=kr, column=cs["Same rule elsewhere"]).value)
        if fname not in sre: ws.cell(row=kr, column=cs["Same rule elsewhere"], value=join_lines(sre + [fname]))
        for c in range(1, len(cs) + 1): ws.cell(row=fr, column=c, value=None)
        rep.append(f"{fname} folded into {keep_name}")
    add_question(wb, f"Metrics: {keep_name}", f"'{keep_name}' and {', '.join(folds)} are the same calculation. Which name is official?", "", by, nm)
    return rep


def list_rows(wb, sheet):
    out = []
    for r, row in rows_raw(wb[sheet], sheet): row = dict(row); row["_row"] = r; out.append(row)
    return out


def main():
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    cmd, path = sys.argv[1], sys.argv[2]; wb = load_workbook(path); a = sys.argv[3:]
    if cmd == "list": print(json.dumps(list_rows(wb, a[0]), indent=2, default=str))
    elif cmd == "append":
        res = append_rows(wb, a[0], json.load(open(a[1])), by=a[2] if len(a) > 2 else ""); wb.save(path)
        for nmx, r, w in res: print((f"{a[0]} row {r}: {nmx}" if r else f"{a[0]}: skipped") + (f"  WARNINGS: {'; '.join(w)}" if w else ""))
    elif cmd in ("fill", "set"):
        n, rep = write_col(wb, a[0], a[1], json.load(open(a[2])), cmd, force="--force" in a); wb.save(path); print(f"{cmd} {a[1]} on {n} rows"); [print("  " + x) for x in rep]
    elif cmd == "question": add_question(wb, a[0], a[1], a[2] if len(a) > 2 else "", a[3] if len(a) > 3 else ""); wb.save(path); print("question added")
    elif cmd == "merge": rep = merge(wb, a[0], a[1:]); wb.save(path); print("\n".join(rep))
    elif cmd == "sync": print("\n".join(sync(wb))); wb.save(path)
    elif cmd == "check":
        p = check(wb); print("\n".join(p) if p else "OK: names resolve, no duplicate rows, no codes"); sys.exit(1 if p else 0)
    else: print(__doc__); sys.exit(1)


if __name__ == "__main__":
    main()
