#!/usr/bin/env python3
"""
One command: read every input in the source folder, fill the workbook, sync, check. Stops once, at the end.

    python3 run_all.py <source_folder> <map.xlsx> [--product "TA scorecard"]

Point it at the project folder. Files are sorted by what they are, not where they sit or what they are called:
.sql = SQL; .py/.ipynb = notebooks; .twb/.twbx = Tableau products; .csv/.xlsx by their headers = catalog, definitions
sheet or restructure sheet; any other .xlsx with data tabs = a product workbook. A file it cannot place raises a Question.
The older six-subfolder layout also still works:
    catalog/      table catalog export (.csv / .xlsx)            -> Legacy tables (kind, owner, code link, active)
    sql/          .sql files (CREATE-less view definitions OK)    -> Legacy tables (built from), Scripts
    notebooks/    Databricks notebooks (.py / .ipynb / .sql)       -> Legacy tables, Scripts, Fields (derived), script output files
    products/     the product workbook(s) (.xlsx)                 -> Products, Metrics, Fields, Dimensions
    definitions/  metric definitions sheet (.csv / .xlsx)         -> Metrics (definition in plain words, TIR, family hint)
    restructure/  restructure sheet export (.csv / .xlsx)         -> Legacy to target

Everything written is Review = Proposed. Nothing is invented: a cell no file fills stays blank and a Question is raised.
What is left for Claude Code afterwards: "What the code does" in plain words (the formula is already there),
Family from references/families.md, and the merge of any calculations the checker reports as duplicates.
"""
import sys, os, re, json, glob, argparse
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import workbook as W
from openpyxl import load_workbook
from parse_catalog import parse as parse_catalog
from parse_definitions import parse as parse_definitions
from parse_restructure import parse as parse_restructure
from parse_notebook import parse as parse_notebook
from parse_xlsx import parse as parse_xlsx

REPORT = []
def say(s): REPORT.append(s); print(s)

def short_from_full(full):
    if "/" in full or full.lower().endswith((".xlsx", ".csv", ".parquet")):
        last = os.path.splitext(os.path.basename(full))[0]
    else:
        last = full.split(".")[-1]
    return re.sub(r"\s+", " ", last.lower().replace("_", " ").strip())

def tokens(s): return set(re.findall(r"[a-z0-9]+", str(s or "").lower())) - {"avg", "average", "the", "of", "in", "per", "a", "an", "rate", "days", "day", "count", "number", "no", "total", "pct", "percent", "percentage"}
def similar(a, b):
    ta, tb = tokens(a), tokens(b)
    return len(ta & tb) / max(1, len(ta | tb)) if ta and tb else 0

SUBS = ("catalog", "sql", "notebooks", "products", "definitions", "restructure")

def _headers(path):
    """first 12 rows of a csv/xlsx, lowercased, to sniff the kind"""
    rows = []
    try:
        if path.lower().endswith(".csv"):
            import csv
            with open(path, encoding="utf-8-sig", errors="replace", newline="") as fh:
                for i, r in enumerate(csv.reader(fh)):
                    rows.append([str(c).strip().lower() for c in r]);
                    if i > 12: break
        else:
            wb = load_workbook(path, read_only=True, data_only=True)
            ws = wb[wb.sheetnames[0]]
            for i, r in enumerate(ws.iter_rows(max_row=13, values_only=True)): rows.append([str(c or "").strip().lower() for c in r])
            wb.close()
    except Exception: pass
    return rows

def classify(path):
    low = path.lower(); base = os.path.basename(low)
    if base.startswith((".", "~$")) or "/.git/" in low or "/__pycache__/" in low: return None
    if low.endswith(".sql"): return "sql"
    if low.endswith((".py", ".ipynb")): return "notebooks"
    if low.endswith((".twb", ".twbx")): return "products"
    if low.endswith((".csv", ".xlsx", ".xlsm")):
        if low.endswith((".xlsx", ".xlsm")):
            try:
                wb = load_workbook(path, read_only=True); names = wb.sheetnames; wb.close()
                if "Legacy tables" in names and "Metrics" in names: return None   # the metric map itself
                if len(names) > 3: return "products"
            except Exception: return "?"
        rows = _headers(path); joined = [" | ".join(r) for r in rows]; text = "\n".join(joined)
        if any("legacy table" in r for r in joined) and any("target layer" in r or "target" in r for r in joined): return "restructure"
        if "table_owner" in text or "table_type" in text or ("table" in text and "active" in text and ("link to code" in text or "owner" in text)): return "catalog"
        if any(("metric" in r and ("definition" in r or "description" in r)) for r in joined): return "definitions"
        if low.endswith((".xlsx", ".xlsm")): return "products"
        return "?"
    return None

def files(folder, sub, exts):
    """files of a kind: by subfolder when the six-subfolder layout is used, else by content across the whole folder"""
    if os.path.isdir(os.path.join(folder, sub)):
        out = []
        for e in exts: out += glob.glob(os.path.join(folder, sub, "**", "*" + e), recursive=True)
        return sorted(set(out))
    return sorted(p for p, k in CLASSIFIED.items() if k == sub and p.lower().endswith(tuple(exts)))

CLASSIFIED = {}
def classify_folder(folder):
    CLASSIFIED.clear()
    if any(os.path.isdir(os.path.join(folder, s)) for s in SUBS): return
    for p in glob.glob(os.path.join(folder, "**", "*"), recursive=True):
        if os.path.isfile(p):
            k = classify(p)
            if k: CLASSIFIED[p] = k

def norm(s): return W.norm(s)

class Run:
    def __init__(self, folder, path, product_name):
        self.folder, self.path, self.product_name = folder, path, product_name
        self.wb = load_workbook(path); self.full_to_name = {}; self.name_to_full = {}; self.pending_feeds = {}; self.file_tabs = {}

    def save(self): self.wb.save(self.path)

    def table_lookup(self, full):
        """resolve a full name (schema.table) to a Legacy tables row name, if present"""
        f = norm(full)
        if f in self.full_to_name: return self.full_to_name[f]
        if " tab " in full.lower() or "/" in full: return None
        last = norm(full.split(".")[-1])
        for k, v in self.full_to_name.items():
            if k.split(" ")[-1] == last or k.endswith(" " + last): return v
        nm = W.Names(self.wb)
        if nm.get("Legacy tables", short_from_full(full)): return nm.get("Legacy tables", short_from_full(full))
        return None

    def refresh_index(self):
        self.full_to_name = {}
        for r, row in W.rows_raw(self.wb["Legacy tables"], "Legacy tables"):
            if row.get("Full name"): self.full_to_name[norm(row["Full name"])] = row["Table name"]

    def ensure_table(self, full, kind=None, source="", by="", conf="Found", extra=None, short=None, script=None):
        self.refresh_index(); name = self.table_lookup(full)
        if name: return name
        short = short or short_from_full(full)
        if kind is None:
            kind = "HRDW" if full.upper().startswith("HRDW_DB") or full.lower().startswith("hrdw.") else ("DEXP" if full.upper().startswith("DEXP") else None)
            if kind is None: W.add_question(self.wb, f"Legacy tables: {short}", f"'{full}' is read by {script or 'a script'} but is not in the catalog. What is it, who owns it, and should it be in the catalog?", full, by)
        row = {"Table name": short, "Kind": kind, "Full name": full, "Source": source, "Confidence": conf}
        if extra: row.update(extra)
        res = W.append_rows(self.wb, "Legacy tables", [row], by=by)
        self.refresh_index(); return res[0][0] or short

    # ---- pass 1: catalog
    def pass_catalog(self):
        fs = files(self.folder, "catalog", [".csv", ".xlsx"])
        if not fs: say("catalog: none found"); return
        rows = []
        for f in fs:
            d = parse_catalog(f)
            for t in d["tables"]:
                kind = {"view we built": "View we built", "HRDW": "HRDW"}.get(t.get("kind_hint"), "Other")
                if t["full_name"].upper().startswith("DEXP"): kind = "DEXP"
                rows.append({"Table name": t["short_name"], "Kind": kind, "Owner": t.get("owner"), "Full name": t["full_name"], "Code link": t.get("code_link"), "Active": "" if t.get("active") is None else ("1" if t["active"] else "0"), "Priority": t.get("priority") or None, "Static": t.get("static") or None, "Source": f"{os.path.basename(f)} row {t.get('row')}", "Confidence": "Found"})
            for q in d.get("questions", []): W.add_question(self.wb, "Legacy tables", q, os.path.basename(f), "catalog")
            for g in d.get("duplicates", []):
                W.add_question(self.wb, f"Legacy tables: {short_from_full(g['names'][0])}", f"The catalog holds {len(g['names'])} versions of this table ({', '.join(g['names'])}; {g.get('reason')}). Which one is live, and can the others retire?", "", "catalog")
        res = W.append_rows(self.wb, "Legacy tables", rows, by="catalog")
        say(f"catalog: {sum(1 for r in res if r[1] and not r[2])} tables added, {sum(1 for r in res if r[2])} skipped or warned")
        self.refresh_index()

    # ---- pass 2: sql + notebooks
    def pass_code(self):
        fs = files(self.folder, "sql", [".sql"]) + files(self.folder, "notebooks", [".py", ".ipynb", ".sql"])
        if not fs: say("code: none found"); return
        n_scripts = 0
        for f in fs:
            d = parse_notebook(f); base = os.path.basename(f); sname = re.sub(r"[_\-]+", " ", os.path.splitext(base)[0]).lower().strip()
            is_sql = f.endswith(".sql"); kind = "SQL file" if is_sql else "Databricks notebook"
            sname = sname + (" sql" if is_sql else " notebook") if not sname.endswith(("sql", "notebook")) else sname
            targets = list(d.get("writes", [])) + ([d["implied_target"]] if d.get("implied_target") else [])
            reads = [t for t in d.get("reads", []) if t not in targets]
            read_names = [self.ensure_table(t, source=f"{base}", by="code", script=sname) for t in reads]
            per_table = {l["writes"]: l["reads"] for l in d.get("lineage", []) if l.get("writes")}
            def reads_for(t):
                rs = per_table.get(t)
                return [self.ensure_table(x, source=base, by="code", script=sname) for x in rs] if rs else read_names
            built = []
            for t in targets:
                self.refresh_index(); existing = self.table_lookup(t)
                if existing:
                    # a file that shows how it is built overrides a schema-based HRDW guess
                    r = W.Names(self.wb).row("Legacy tables", existing); ws = self.wb["Legacy tables"]; cs = W.cols("Legacy tables")
                    if ws.cell(row=r, column=cs["Kind"]).value == "HRDW":
                        ws.cell(row=r, column=cs["Kind"], value="View we built")
                        W.add_question(self.wb, f"Legacy tables: {existing}", f"'{t}' sits in an HRDW schema but {base} builds it, so it is recorded as a view we built. Confirm.", base, "code")
                    elif ws.cell(row=r, column=cs["Kind"]).value in (None, ""):
                        ws.cell(row=r, column=cs["Kind"], value="View we built")
                    name = existing
                else:
                    name = self.ensure_table(t, kind="View we built", source=base, by="code")
                built.append(name)
                W.write_col(self.wb, "Legacy tables", "Built from", {name: reads_for(t)}, "fill", by="code")
            for fw in d.get("file_writes", []):
                name = self.ensure_table(fw["path"], kind="Script output file", source=f"{base} cell {fw.get('cell')}", by="code"); built.append(name)
                # the file is written from the last table built before it, if the cell says nothing else
                cell = next((c for c in d.get("cells", []) if c.get("index") == fw.get("cell")), None)
                cell_reads = [self.table_lookup(x) for x in (cell.get("reads", []) if cell else [])]
                src = [x for x in cell_reads if x] or ([built[-2]] if len(built) > 1 else read_names)
                W.write_col(self.wb, "Legacy tables", "Built from", {name: src}, "fill", by="code")
                if fw.get("sheet_name"): self.file_tabs[fw["sheet_name"].lower()] = name
            feeds = []
            if self.product_name and d.get("file_writes"): self.pending_feeds[sname] = [self.product_name]
            sched = next((h for h in d.get("header_comments", []) if re.search(r"runs|cron|daily|weekly|monthly|every", h, re.I)), None)
            W.append_rows(self.wb, "Scripts", [{"Script name": sname, "Kind": kind, "Builds": built, "Reads": read_names, "Feeds": feeds if W.Names(self.wb).get("Products", self.product_name or "") else [],
                                                "Schedule": sched, "Started by": "A schedule" if sched else None, "Code link": f, "Source": base}], by="code")
            n_scripts += 1
            # derived fields from aliased expressions, on the table the cell writes
            frows = []
            for e in d.get("expressions", []):
                if e.get("rename_only") or not e.get("alias"): continue
                tgt = e.get("written_to") or (targets[0] if targets else None)
                if not tgt: continue
                tname = self.table_lookup(tgt) or self.ensure_table(tgt, kind="View we built", source=base, by="code")
                frows.append({"Field name": f"{e['alias']} ({tname})", "Table": tname, "Type": "Derived", "Rule": f"{e.get('expression') or e.get('expr')}", "Source": f"{base} cell {e.get('cell')}", "Confidence": "Found"})
            if frows: W.append_rows(self.wb, "Fields", frows, by="code")
            for q in d.get("questions", []): W.add_question(self.wb, f"Scripts: {sname}", q, base, "code")
        say(f"code: {n_scripts} scripts read")

    # ---- pass 3: product xlsx + definitions
    def pass_products(self):
        fs = files(self.folder, "products", [".xlsx"])
        defs = {}
        for f in files(self.folder, "definitions", [".csv", ".xlsx"]):
            d = parse_definitions(f)
            for m in d["metrics"]: defs[norm(m["name"])] = dict(m, file=os.path.basename(f))
            for q in d.get("questions", []): W.add_question(self.wb, "Metrics", q, os.path.basename(f), "definitions")
        if not fs: say("products: none found"); return
        for f in fs:
            d = parse_xlsx(f); base = os.path.basename(f); pname = self.product_name or os.path.splitext(base)[0]
            reads, touches = [], []
            for t in d.get("tables", []):
                known = self.file_tabs.get(t["sheet"].lower())
                if known:
                    tname = known; self.refresh_index(); self.full_to_name[norm(f"{base} tab {t['sheet']}")] = known
                    reads.append(tname); touches.append(f"{t['sheet']} tab: the notebook writes it as a file, then it is pasted into the workbook"); continue
                kind = "Script output file" if t.get("kind_guess") == "Script output" else "Hand-kept sheet"
                tname = self.ensure_table(f"{base} tab {t['sheet']}", kind=kind, source=f"{base} tab {t['sheet']}", by="products", conf="Inferred", short=f"{pname} {t['sheet']} tab")
                reads.append(tname)
                touches.append(f"{t['sheet']} tab: {'written by a script, then pasted' if kind == 'Script output file' else 'kept by hand'}")
                if kind == "Hand-kept sheet": W.add_question(self.wb, f"Legacy tables: {tname}", f"Tab '{t['sheet']}' in {base} looks hand-maintained (no formulas, no connection). Who keeps it, and how often?", "", "products")
            for el in d.get("external_links", []):
                tname = self.ensure_table(el.get("path") or f"external link {el.get('index')}", kind="Hand-kept sheet", source=base, by="products", conf="Inferred", short=os.path.splitext(os.path.basename(el.get("path") or "linked file"))[0].replace("_", " ")); reads.append(tname); touches.append(f"{el.get('path')}: linked file, kept by hand")
            pasted = [m["label"] for m in d["metrics"] if m["kind"] == "pasted value"]
            if pasted: touches.append(f"pasted numbers with no formula: {', '.join(pasted)}")
            W.append_rows(self.wb, "Products", [{"Product name": pname, "Kind": "Excel scorecard", "Reads from": reads, "Where a person touches it": W.join_lines(touches), "Source": base, "Confidence": "Found"}], by="products")
            # dimensions from parameters
            dims = set()
            for m in d["metrics"]:
                for pk, pv in (m.get("parameters") or {}).items():
                    dims.add("org (tab)" if pk == "<sheet>" else ("month" if pk == "period" else pk.strip("<>")))
            if any(len(m.get("tabs", [])) > 1 for m in d["metrics"]): dims.add("org (tab)")
            if dims: W.append_rows(self.wb, "Dimensions", [{"Cut name": x} for x in sorted(dims)], by="products")
            # fields on data tabs
            frows = []
            for m in d["metrics"]:
                for ref, label in (m.get("reads_labels") or []):
                    tab = ref.split("!")[0].strip("'") if "!" in ref else None
                    if tab and any(t["sheet"] == tab for t in d.get("tables", [])):
                        tname = self.table_lookup(f"{base} tab {tab}")
                        if tname: frows.append({"Field name": f"{label} ({tname})", "Table": tname, "Type": "Raw", "Source": f"{base} tab {tab}", "Confidence": "Found"})
            if frows: W.append_rows(self.wb, "Fields", frows, by="products")
            # metrics
            mrows = []
            for m in d["metrics"]:
                dfn = defs.pop(norm(m["label"]), None)
                if not dfn:
                    best = max(defs.items(), key=lambda kv: similar(m["label"], kv[1]["name"]), default=None)
                    if best and similar(m["label"], best[1]["name"]) >= 0.5:
                        dfn = defs.pop(best[0]); W.add_question(self.wb, f"Metrics: {m['label']}", f"'{m['label']}' on the product was matched to '{dfn['name']}' on the definitions sheet by name similarity. Is that the same metric?", f"product label: {m['label']} | definitions sheet: {dfn['name']}", "products")
                cuts = ["org (tab)"] if len(m.get("tabs", [])) > 1 else []
                for pk in (m.get("parameters") or {}): cuts.append("org (tab)" if pk == "<sheet>" else ("month" if pk == "period" else pk.strip("<>")))
                reads_t = sorted({self.table_lookup(f"{base} tab {r.split('!')[0].strip(chr(39))}") for r, l in (m.get("reads_labels") or []) if "!" in r} - {None})
                fields = [f"{l} ({self.table_lookup(f'{base} tab {r.split(chr(33))[0]}')})" for r, l in (m.get("reads_labels") or []) if "!" in r and self.table_lookup(f"{base} tab {r.split('!')[0]}")]
                if not reads_t:
                    for ref, label in (m.get("reads_labels") or []):
                        other = next((x for x in mrows if x["Metric name"].lower() == str(label).split(" / ")[0].strip().lower()), None)
                        if other:
                            for x in (other.get("Reads from") or []): reads_t.append(x) if x not in reads_t else None
                            for x in (other.get("Fields read") or []): fields.append(x) if x not in fields else None
                            for x in (other.get("Cuts") or []): cuts.append(x) if x not in cuts else None
                code = f"Formula: {m.get('formula_example')}" if m["kind"] == "formula" else None
                row = {"Metric name": m["label"], "Definition in plain words": dfn["definition"] if dfn else None, "What the code does": code, "Cuts": cuts, "Reads from": reads_t, "TIR": dfn.get("tir") if dfn else None,
                       "Fields read": fields, "Source": f"{base} tabs {', '.join(m.get('tabs', []))}, label {m['label']}", "Confidence": "Found" if m["kind"] == "formula" else "Inferred"}
                if dfn and dfn.get("category"): row["Family"] = None  # category is a hint only; Claude Code sets Family from families.md
                mrows.append(row)
                if m["kind"] == "pasted value": W.add_question(self.wb, f"Metrics: {m['label']}", f"'{m['label']}' is a pasted number in {base} with no formula. Where is it computed, and what is the rule?", "; ".join(c[1] for c in (m.get("comments") or [])) or "no comment on the cell", "products")
                if not dfn and defs: W.add_question(self.wb, f"Metrics: {m['label']}", f"'{m['label']}' appears on the product but not on the definitions sheet. Is it a known metric under another name?", "", "products")
                elif dfn and dfn["name"] != m["label"]: row["Same rule elsewhere"] = [dfn["name"]]
            res = W.append_rows(self.wb, "Metrics", mrows, by="products", default_source=base)
            W.append_rows(self.wb, "Metrics", [{"Metric name": dfn["name"], "Definition in plain words": dfn["definition"], "TIR": dfn.get("tir"), "Source": f"{dfn['file']} row {dfn.get('row')}", "Confidence": "Found"} for dfn in defs.values()], by="definitions")
            for dfn in defs.values(): W.add_question(self.wb, f"Metrics: {dfn['name']}", f"'{dfn['name']}' is on the definitions sheet but no formula for it was found in the product or the code. Where is it computed?", "", "definitions")
            for q in d.get("questions", []): W.add_question(self.wb, f"Products: {pname}", q, base, "products")
            for sname, feeds in self.pending_feeds.items(): W.write_col(self.wb, "Scripts", "Feeds", {sname: feeds}, "fill", by="products")
            say(f"products: {pname}: {len(mrows)} metrics from the file, {len(defs)} from the definitions sheet only")

    # ---- pass 4: restructure
    def pass_restructure(self):
        fs = files(self.folder, "restructure", [".csv", ".xlsx"])
        if not fs: say("restructure: none found"); return
        for f in fs:
            d = parse_restructure(f); base = os.path.basename(f); rows = []
            for p in d["pairs"]:
                self.refresh_index(); legacy = self.table_lookup(p["legacy"])
                if not legacy:
                    W.add_question(self.wb, f"Legacy to target: {p['legacy']}", f"The restructure sheet names '{p['legacy']}' as a legacy table, but nothing with that name is in the inventory. Which table is it?", f"{base} row {p.get('row')}", "restructure"); continue
                rows.append({"Legacy table": legacy, "Target table": p["target"], "Layer": str(p.get("layer") or ""), "Why we need this": p.get("why"), "Business logic that will apply": p.get("logic"), "Status": "Mapped", "Source": f"{base} row {p.get('row')}", "Confidence": "Human"})
            res = W.append_rows(self.wb, "Legacy to target", rows, by="restructure")
            for q in d.get("questions", []): W.add_question(self.wb, "Legacy to target", q, base, "restructure")
            say(f"restructure: {sum(1 for r in res if r[1] and not r[2])} arrows added")

    def run(self):
        classify_folder(self.folder)
        if CLASSIFIED:
            say("files found, and what each was taken as:")
            for p, k in sorted(CLASSIFIED.items(), key=lambda kv: (SUBS.index(kv[1]) if kv[1] in SUBS else 9, kv[0])):
                say(f"  {k:12} {os.path.relpath(p, self.folder)}")
                if k == "?": W.add_question(self.wb, "Products", f"'{os.path.relpath(p, self.folder)}' could not be classified (not a catalog, definitions sheet, restructure sheet or product workbook by its headers). What is it?", "", "intake")
        else:
            say("six-subfolder layout found; reading by subfolder")
        self.pass_catalog(); self.save()
        self.pass_code(); self.save()
        self.pass_products(); self.save()
        self.pass_restructure(); self.save()
        W.sync(self.wb); self.save()
        n = 0
        for r, row in W.rows_raw(self.wb["Legacy tables"], "Legacy tables"):
            if row.get("Kind") in ("View we built", "Script output file") and not row.get("Built by"):
                link = row.get("Code link")
                W.add_question(self.wb, f"Legacy tables: {row['Table name']}", f"Nothing in the source folder builds '{row['Table name']}'." + (f" The catalog says its code is at {link}; add that file to sql/ and rerun." if link else " Is it still built by anything?"), row.get("Full name") or "", "code"); n += 1
        if n: say(f"code: {n} built tables have no build file in the folder (questions raised)")
        self.save()
        probs = W.check(self.wb)
        say("check: " + ("OK" if not probs else f"{len(probs)} problem(s)"))
        for p in probs: say("  " + p)
        q = len(W.rows_raw(self.wb["Questions"], "Questions"))
        say(f"questions open: {q}")
        return 0 if not probs else 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("folder"); ap.add_argument("map"); ap.add_argument("--product", default=None)
    a = ap.parse_args(); sys.exit(Run(a.folder, a.map, a.product).run())

if __name__ == "__main__":
    main()
