#!/usr/bin/env python3
"""
Extract tables, lineage and calculated columns from Databricks notebooks and scripts.

Usage:
    python3 parse_notebook.py <file> [-o out.json]

Accepts:
  .py     Databricks notebook export ("# Databricks notebook source", cells split by "# COMMAND ----------")
          or a plain Python/PySpark script
  .ipynb  Jupyter / Databricks notebook
  .sql    Databricks SQL notebook export or a plain SQL file. A plain .sql with reads but no
          CREATE/INSERT/MERGE target (a bare view definition) gets "implied_target": the file's
          base name without extension, plus a question asking to confirm the table it defines.
  .dbc    not supported; export the notebook as .py or .ipynb first

What it reports, per cell:
  language        sql | python | other (from %sql / %python magics or file type)
  reads           tables named in FROM / JOIN, spark.table(...), spark.read.table(...), .load("...") paths
  writes          CREATE [OR REPLACE] TABLE|VIEW, INSERT INTO/OVERWRITE, MERGE INTO, saveAsTable(...), .write...path
  joins           JOIN <table> ON <condition>, because a join condition is often where a business rule hides
                  (a history table joined on a date range is an attribution rule)
  expressions     SELECT-list items written as  <expression> AS <alias>, with the raw expression text;
                  also withColumn("alias", <expr>) and df["alias"] = <expr>
  sql             the SQL text that was found, so a reviewer can check the extraction

  file_writes     files the cell writes: to_excel / to_csv / to_parquet, .write....save(path),
                  .write.csv|parquet|json|text|orc(path), dbutils.fs.cp/mv (dest; source in "from")
                  -> {cell, path, format (xlsx|csv|parquet|delta|json|unknown), sheet_name, call, unresolved}
  runs            other notebooks this one runs: %run <path> and dbutils.notebook.run(<path>, ...)
  widgets         dbutils.widgets.text/dropdown/combobox/multiselect/get -> {name, default, cell}
  unresolved_tables
                  table or path expressions that are not plain string literals (f-strings, {..},
                  "a" + b concatenation, bare variables) in spark.table / read.table / saveAsTable /
                  insertInto / spark.sql(f"... FROM {schema}.x") -> {cell, expression}; each one
                  also becomes a question
  dynamic_sql     per cell: spark.sql(...) calls whose argument is an f-string, a concatenation
                  or a variable (the SQL text is still scanned when it is an f-string)
  magic           per cell: the %magic that opened the cell (sql, python, run, md, ...) if any

And at the top level, de-duplicated: reads, writes, a table-level lineage list
(write -> [reads in the same cell or the cells feeding it]), every aliased expression with the
cell it came from, file_writes, runs, widgets, unresolved_tables, header_comments (comment lines
in the first cells that mention schedule|cron|runs|owner|author|contact|every|daily|weekly|monthly)
and questions (plain sentences for the reviewer).

This is a text-level extractor, not a SQL parser. It will miss things in unusual syntax and may
over-collect table names in comments. Everything it returns must be read as evidence, not fact.
"""
import argparse, json, os, re, sys

CMD_SPLIT = re.compile(r"^# COMMAND -{5,}\s*$", re.M)
MAGIC = re.compile(r"^# MAGIC\s?(.*)$", re.M)

T = r"[`\"']?([A-Za-z_][\w$]*(?:\.[`\"']?[A-Za-z_][\w$]*[`\"']?){0,2})[`\"']?"
RE_FROM = re.compile(r"\b(?:FROM|JOIN)\s+" + T, re.I)
RE_WRITE = re.compile(r"\b(?:CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMP(?:ORARY)?\s+)?(?:TABLE|VIEW)(?:\s+IF\s+NOT\s+EXISTS)?|INSERT\s+(?:INTO|OVERWRITE)(?:\s+TABLE)?|MERGE\s+INTO)\s+" + T, re.I)
RE_SPARK_TABLE = re.compile(r"\.(?:table|read\.table)\(\s*[\"']([^\"']+)[\"']\s*\)")
RE_SAVE_AS = re.compile(r"\.saveAsTable\(\s*[\"']([^\"']+)[\"']")
RE_INSERT_INTO_PY = re.compile(r"\.insertInto\(\s*[\"']([^\"']+)[\"']")
RE_LOAD = re.compile(r"\.(?:load|csv|parquet|json)\(\s*[\"']([^\"']+)[\"']")
RE_SPARK_SQL = re.compile(r"spark\.sql\(\s*(f?)(\"\"\"|'''|\"|')(.*?)\2", re.S)
RE_WITHCOL = re.compile(r"\.withColumn\(\s*[\"']([^\"']+)[\"']\s*,\s*(.+?)\)\s*(?=\.|\n|$)", re.S)
RE_ASSIGN = re.compile(r"(\w+)\[\s*[\"']([^\"']+)[\"']\s*\]\s*=\s*(.+)")
RE_AS = re.compile(r"(.+?)\s+AS\s+[`\"']?([A-Za-z_]\w*)[`\"']?\s*$", re.I | re.S)
SQL_KEYWORDS = {"select", "from", "where", "and", "or", "on", "as", "join", "left", "right", "inner", "outer", "group", "by", "order", "having", "with", "union", "all", "values", "lateral", "cross", "full"}

RE_TO_FILE = re.compile(r"\.to_(excel|csv|parquet|json)\(")
RE_WRITE_START = re.compile(r"\.write\b")
RE_FS_COPY = re.compile(r"dbutils\.fs\.(cp|mv)\(")
RE_NB_RUN = re.compile(r"dbutils\.notebook\.run\(")
RE_WIDGET_DEF = re.compile(r"dbutils\.widgets\.(text|dropdown|combobox|multiselect)\(")
RE_WIDGET_GET = re.compile(r"dbutils\.widgets\.get\(")
RE_TABLE_CALL = re.compile(r"\.(table|read\.table|saveAsTable|insertInto|load|csv|parquet|json)\(")
RE_SPARK_SQL_CALL = re.compile(r"spark\.sql\(")
RE_DYN_TABLE = re.compile(r"\b(?:FROM|JOIN|INTO|TABLE|UPDATE)\s+([`\w.]*\{[^}]*\}[`\w.{}]*)", re.I)
RE_PLAIN_STR = re.compile(r"^(?:\"\"\"(.*?)\"\"\"|'''(.*?)'''|\"([^\"]*)\"|'([^']*)')$", re.S)
RE_HEADER = re.compile(r"\b(schedule|cron|runs?|owner|author|contact|every|daily|weekly|monthly)\b", re.I)
WRITE_TERMINALS = {"save", "csv", "parquet", "json", "text", "orc", "saveAsTable", "insertInto"}
FORMAT_BY_EXT = {".xlsx": "xlsx", ".xlsm": "xlsx", ".xls": "xlsx", ".csv": "csv", ".parquet": "parquet", ".json": "json", ".txt": "text"}


def call_args(text, open_idx):
    """text[open_idx] is '('. Return (args_text, index_after_close) honouring nested brackets and strings."""
    depth, i, n = 0, open_idx, len(text)
    quote = None
    while i < n:
        ch = text[i]
        if quote:
            if text.startswith(quote, i):
                i += len(quote); quote = None; continue
            if ch == "\\":
                i += 1
        elif text.startswith('"""', i) or text.startswith("'''", i):
            quote = text[i:i + 3]; i += 2
        elif ch in "\"'":
            quote = ch
        elif ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
            if depth == 0:
                return text[open_idx + 1:i], i + 1
        i += 1
    return text[open_idx + 1:], n


def split_args(args):
    out, depth, cur, quote, i = [], 0, [], None, 0
    while i < len(args):
        ch = args[i]
        if quote:
            cur.append(ch)
            if args.startswith(quote, i):
                cur.extend(quote[1:]); i += len(quote); quote = None; continue
            if ch == "\\" and i + 1 < len(args):
                cur.append(args[i + 1]); i += 1
        elif args.startswith('"""', i) or args.startswith("'''", i):
            quote = args[i:i + 3]; cur.extend(quote); i += 2
        elif ch in "\"'":
            quote = ch; cur.append(ch)
        elif ch in "([{":
            depth += 1; cur.append(ch)
        elif ch in ")]}":
            depth -= 1; cur.append(ch)
        elif ch == "," and depth == 0:
            out.append("".join(cur).strip()); cur = []
        else:
            cur.append(ch)
        i += 1
    tail = "".join(cur).strip()
    if tail:
        out.append(tail)
    return out


def positional_and_kw(args):
    pos, kw = [], {}
    for a in split_args(args):
        m = re.match(r"^([A-Za-z_]\w*)\s*=(?!=)\s*(.+)$", a, re.S)
        if m:
            kw[m.group(1)] = m.group(2).strip()
        else:
            pos.append(a)
    return pos, kw


def literal(expr):
    """(value, unresolved). A plain string literal resolves; f-strings, concatenations and names do not."""
    if expr is None:
        return None, False
    e = expr.strip()
    m = RE_PLAIN_STR.match(e)
    if m:
        return next(g for g in m.groups() if g is not None), False
    return e, True


def format_from_path(path):
    if not path:
        return "unknown"
    low = path.lower()
    for ext, fmt in FORMAT_BY_EXT.items():
        if low.endswith(ext):
            return fmt
    return "unknown"


def write_chains(text):
    """Find df.write....<terminal>(args) chains. Returns list of dicts with span, terminal, format, args."""
    out = []
    for m in RE_WRITE_START.finditer(text):
        i, fmt, mode, terminal, args = m.end(), None, None, None, None
        while True:
            mm = re.match(r"\s*\\?\s*\.(\w+)\s*\(", text[i:], re.S)
            if not mm:
                break
            name = mm.group(1)
            a, end = call_args(text, i + mm.end() - 1)
            i = end
            if name == "format":
                fmt = literal(split_args(a)[0] if split_args(a) else None)[0]
            elif name == "mode":
                mode = literal(split_args(a)[0] if split_args(a) else None)[0]
            if name in WRITE_TERMINALS:
                terminal, args = name, a
                break
        if terminal:
            out.append({"span": (m.start(), i), "terminal": terminal, "format": fmt, "mode": mode, "args": args})
    return out


def split_select_list(sql):
    """Return the items of every SELECT list in sql (CTEs and the outer query), respecting parentheses."""
    out = []
    for m in re.finditer(r"\bSELECT\b(.*?)\bFROM\b", sql, re.I | re.S):
        body = m.group(1); items, depth, cur = [], 0, []
        for ch in body:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                items.append("".join(cur).strip()); cur = []
            else:
                cur.append(ch)
        if cur: items.append("".join(cur).strip())
        out += [i for i in items if i and i.lower() not in ("distinct", "*")]
    return out


RE_JOIN_ON = re.compile(r"\bJOIN\s+" + T + r"(?:\s+(?:AS\s+)?\w+)?\s+ON\s+(.+?)(?=\bLEFT\b|\bRIGHT\b|\bINNER\b|\bFULL\b|\bJOIN\b|\bWHERE\b|\bGROUP\b|\)\s*$|\)\s*SELECT|$)", re.I | re.S)


def joins_in_sql(sql):
    return [{"table": m.group(1), "on": re.sub(r"\s+", " ", m.group(2).strip())} for m in RE_JOIN_ON.finditer(sql)]


def expressions_from_sql(sql):
    out = []
    for item in split_select_list(sql):
        m = RE_AS.match(item)
        if m:
            expr, alias = m.group(1).strip(), m.group(2)
            if expr != alias and not re.fullmatch(r"[\w.`\"]+", expr):
                out.append({"alias": alias, "expression": re.sub(r"\s+", " ", expr)})
            elif expr != alias:
                out.append({"alias": alias, "expression": expr, "rename_only": True})
    return out


def tables_in_sql(sql):
    reads = [m.group(1) for m in RE_FROM.finditer(sql) if m.group(1).lower() not in SQL_KEYWORDS and not m.group(1).startswith("(")]
    writes = [m.group(1) for m in RE_WRITE.finditer(sql)]
    # CTE names are not tables
    ctes = set(re.findall(r"\b(\w+)\s+AS\s*\(", sql, re.I))
    reads = [r for r in reads if r not in ctes and r.lower() not in ctes]
    return reads, writes


def python_extras(text, cell):
    """file_writes, runs, widgets, unresolved_tables, dynamic_sql for a python cell. Returns write-chain spans."""
    chains = write_chains(text)
    for ch in chains:
        pos, kw = positional_and_kw(ch["args"])
        if ch["terminal"] in ("saveAsTable", "insertInto"):
            target = kw.get("name") or (pos[0] if pos else None)
            val, unres = literal(target)
            if unres and val:
                cell["unresolved_tables"].append({"expression": val, "call": "." + ch["terminal"]})
            continue
        target = kw.get("path") or (pos[0] if pos else None)
        val, unres = literal(target)
        fmt = (ch["format"] or "").lower() or (ch["terminal"] if ch["terminal"] in ("csv", "parquet", "json", "text", "orc") else format_from_path(val))
        cell["file_writes"].append({"path": val, "format": fmt or "unknown", "sheet_name": None, "call": f".write.{ch['terminal']}", "mode": ch["mode"], "unresolved": bool(unres)})
    for m in RE_TO_FILE.finditer(text):
        a, _ = call_args(text, m.end() - 1)
        pos, kw = positional_and_kw(a)
        target = kw.get("excel_writer") or kw.get("path_or_buf") or kw.get("path") or (pos[0] if pos else None)
        val, unres = literal(target)
        sheet, _ = literal(kw.get("sheet_name")) if m.group(1) == "excel" else (None, False)
        cell["file_writes"].append({"path": val, "format": {"excel": "xlsx"}.get(m.group(1), m.group(1)), "sheet_name": sheet, "call": ".to_" + m.group(1), "mode": None, "unresolved": bool(unres)})
    for m in RE_FS_COPY.finditer(text):
        a, _ = call_args(text, m.end() - 1)
        pos, kw = positional_and_kw(a)
        src, sunres = literal(pos[0] if pos else kw.get("from"))
        dst, dunres = literal(pos[1] if len(pos) > 1 else kw.get("to"))
        cell["file_writes"].append({"path": dst, "format": format_from_path(dst), "sheet_name": None, "call": "dbutils.fs." + m.group(1), "from": src, "mode": None, "unresolved": bool(sunres or dunres)})
    for m in RE_NB_RUN.finditer(text):
        a, _ = call_args(text, m.end() - 1)
        pos, kw = positional_and_kw(a)
        val, unres = literal(kw.get("path") or (pos[0] if pos else None))
        cell["runs"].append({"path": val, "kind": "dbutils.notebook.run", "unresolved": bool(unres), "arguments": kw.get("arguments") or (pos[2] if len(pos) > 2 else None)})
    for m in RE_WIDGET_DEF.finditer(text):
        a, _ = call_args(text, m.end() - 1)
        pos, kw = positional_and_kw(a)
        name, _ = literal(kw.get("name") or (pos[0] if pos else None))
        default, _ = literal(kw.get("defaultValue") or (pos[1] if len(pos) > 1 else None))
        cell["widgets"].append({"name": name, "default": default, "type": m.group(1)})
    for m in RE_WIDGET_GET.finditer(text):
        a, _ = call_args(text, m.end() - 1)
        pos, kw = positional_and_kw(a)
        name, _ = literal(kw.get("name") or (pos[0] if pos else None))
        if not any(w["name"] == name for w in cell["widgets"]):
            cell["widgets"].append({"name": name, "default": None, "type": "get"})
    for m in RE_TABLE_CALL.finditer(text):
        if any(s <= m.start() < e for s, e in (c["span"] for c in chains)):
            continue
        a, _ = call_args(text, m.end() - 1)
        pos, kw = positional_and_kw(a)
        target = kw.get("tableName") or kw.get("name") or kw.get("path") or (pos[0] if pos else None)
        if target is None:
            continue
        val, unres = literal(target)
        if unres:
            cell["unresolved_tables"].append({"expression": val, "call": "." + m.group(1)})
    for m in RE_SPARK_SQL_CALL.finditer(text):
        a, _ = call_args(text, m.end() - 1)
        pos, kw = positional_and_kw(a)
        arg = kw.get("sqlQuery") or (pos[0] if pos else "")
        val, unres = literal(arg)
        if unres:
            cell["dynamic_sql"].append(val)
            fm = re.match(r"^f(\"\"\"|'''|\"|')(.*)\1$", val.strip(), re.S)
            if fm:
                for t in RE_DYN_TABLE.findall(fm.group(2)):
                    cell["unresolved_tables"].append({"expression": t, "call": "spark.sql(f-string)"})
            else:
                cell["unresolved_tables"].append({"expression": val, "call": "spark.sql(built at runtime)"})
    return [c["span"] for c in chains]


def analyse_cell(text, language):
    cell = {"language": language, "reads": [], "writes": [], "expressions": [], "joins": [], "sql": [],
            "file_writes": [], "runs": [], "widgets": [], "unresolved_tables": [], "dynamic_sql": []}
    sqls = []
    if language == "sql":
        sqls.append(text)
        for t in RE_DYN_TABLE.findall(text):
            cell["unresolved_tables"].append({"expression": t, "call": "%sql ${...}"})
    else:
        for m in RE_SPARK_SQL.finditer(text):
            sqls.append(m.group(3))
        write_spans = python_extras(text, cell)
        cell["reads"] += RE_SPARK_TABLE.findall(text)
        cell["reads"] += [m.group(1) for m in RE_LOAD.finditer(text) if not any(s <= m.start() < e for s, e in write_spans)]
        cell["writes"] += RE_SAVE_AS.findall(text) + RE_INSERT_INTO_PY.findall(text)
        for m in RE_WITHCOL.finditer(text):
            cell["expressions"].append({"alias": m.group(1), "expression": re.sub(r"\s+", " ", m.group(2).strip())})
        for line in text.splitlines():
            m = RE_ASSIGN.match(line.strip())
            if m and not line.strip().startswith("#"):
                cell["expressions"].append({"alias": m.group(2), "expression": m.group(3).strip()})
    for s in sqls:
        masked = RE_DYN_TABLE.sub(lambda m: m.group(0).replace(m.group(1), "__dynamic__"), s)
        r, w = tables_in_sql(masked)
        cell["reads"] += [x for x in r if "__dynamic__" not in x]; cell["writes"] += [x for x in w if "__dynamic__" not in x]
        cell["expressions"] += expressions_from_sql(s); cell["joins"] += joins_in_sql(s); cell["sql"].append(s.strip())
    cell["reads"] = sorted(set(cell["reads"])); cell["writes"] = sorted(set(cell["writes"]))
    return cell


def split_magic(body):
    """'%sql\\nSELECT..' -> ('sql', 'SELECT..', 'sql'); '%run ./x' -> ('other', './x', 'run'); no magic -> ('python', body, None)"""
    m = re.match(r"^\s*%%?(\w+)[ \t]*(.*)$", body, re.S)
    if not m:
        return "python", body, None
    magic, rest = m.group(1).lower(), m.group(2)
    lang = "sql" if magic == "sql" else "python" if magic in ("python", "py") else "other"
    return lang, rest, magic


def cells_from_py(text):
    """Returns (language, body, magic, raw_text) per cell."""
    if "# Databricks notebook source" in text or CMD_SPLIT.search(text):
        parts = CMD_SPLIT.split(text)
        out = []
        for p in parts:
            magics = MAGIC.findall(p)
            if magics:
                lang, body, magic = split_magic("\n".join(magics))
                out.append((lang, body, magic, p))
            else:
                out.append(("python", p, None, p))
        return out
    return [("python", text, None, text)]


def cells_from_ipynb(path):
    nb = json.load(open(path))
    out = []
    for c in nb.get("cells", []):
        src = "".join(c.get("source", []))
        if c.get("cell_type") == "markdown":
            out.append(("other", src, "md", src))
            continue
        if c.get("cell_type") != "code":
            continue
        lang, body, magic = split_magic(src)
        out.append((lang, body, magic, src))
    return out


def cells_from_sql_file(text):
    if "-- Databricks notebook source" in text or re.search(r"^-- COMMAND -{5,}", text, re.M):
        parts = re.split(r"^-- COMMAND -{5,}\s*$", text, flags=re.M)
        out = []
        for p in parts:
            if not p.strip():
                continue
            magics = MAGIC.findall(p)
            if magics:
                lang, body, magic = split_magic("\n".join(magics))
                out.append((lang, body, magic, p))
            else:
                out.append(("sql", p, None, p))
        return out
    return [("sql", text, None, text)]


def header_comments(cells):
    """Comment lines in the first two cells that mention a schedule, owner or contact."""
    found = []
    for lang, body, magic, raw in cells[:2]:
        for line in raw.splitlines():
            s = re.sub(r"^\s*#\s?MAGIC\s?", "", line).strip()
            if re.match(r"^(# Databricks notebook source|-- Databricks notebook source|# COMMAND|-- COMMAND)", s):
                continue
            if s.startswith("%"):
                s = re.sub(r"^%%?\w+\s*", "", s)
            is_comment = s.startswith("#") or s.startswith("--") or magic == "md"
            if is_comment:
                clean = s.lstrip("#- ").strip()
                if clean and RE_HEADER.search(clean):
                    found.append(clean)
    return found


def parse(path):
    low = path.lower()
    if low.endswith(".ipynb"):
        cells = cells_from_ipynb(path)
    elif low.endswith(".py"):
        cells = cells_from_py(open(path, encoding="utf-8", errors="replace").read())
    elif low.endswith(".sql"):
        cells = cells_from_sql_file(open(path, encoding="utf-8", errors="replace").read())
    elif low.endswith(".dbc"):
        raise SystemExit(".dbc archives are not supported; export the notebook as .py or .ipynb")
    else:
        raise SystemExit(f"unsupported file type: {path}")
    out = {"file": path, "cells": [], "reads": set(), "writes": set(), "lineage": [], "expressions": [],
           "file_writes": [], "runs": [], "widgets": [], "unresolved_tables": [], "header_comments": header_comments(cells), "questions": []}
    seen_widgets = {}
    for i, (lang, body, magic, raw) in enumerate(cells):
        if not body.strip():
            continue
        if magic == "run":
            out["runs"].append({"cell": i, "path": body.strip().split()[0] if body.strip() else body.strip(), "kind": "%run", "unresolved": "$" in body or "{" in body})
            out["cells"].append({"language": lang, "magic": magic, "index": i, "reads": [], "writes": [], "expressions": [], "joins": [], "sql": [],
                                 "file_writes": [], "runs": [out["runs"][-1]], "widgets": [], "unresolved_tables": [], "dynamic_sql": []})
            continue
        if magic == "md":
            continue
        c = analyse_cell(body, lang); c["index"] = i; c["magic"] = magic
        out["cells"].append(c)
        out["reads"].update(c["reads"]); out["writes"].update(c["writes"])
        for w in c["writes"]:
            out["lineage"].append({"writes": w, "reads": c["reads"], "cell": i})
        for e in c["expressions"]:
            out["expressions"].append(dict(e, cell=i, written_to=c["writes"][0] if c["writes"] else None))
        for fw in c["file_writes"]:
            out["file_writes"].append(dict(fw, cell=i))
        for r in c["runs"]:
            out["runs"].append(dict(r, cell=i))
        for w in c["widgets"]:
            if w["name"] in seen_widgets:
                if seen_widgets[w["name"]]["default"] is None and w["default"] is not None:
                    seen_widgets[w["name"]]["default"] = w["default"]
                continue
            seen_widgets[w["name"]] = dict(w, cell=i); out["widgets"].append(seen_widgets[w["name"]])
        for u in c["unresolved_tables"]:
            if not any(x["expression"] == u["expression"] and x["cell"] == i for x in out["unresolved_tables"]):
                out["unresolved_tables"].append({"cell": i, "expression": u["expression"], "call": u["call"]})
    out["reads"] = sorted(out["reads"]); out["writes"] = sorted(out["writes"])
    widget_names = {w["name"] for w in out["widgets"]}
    for u in out["unresolved_tables"]:
        names = set(re.findall(r"\{([A-Za-z_]\w*)", u["expression"])) | ({u["expression"]} if re.fullmatch(r"[A-Za-z_]\w*", u["expression"]) else set())
        via = [f"widget '{n}'" + (f" (default {seen_widgets[n]['default']!r})" if seen_widgets[n]["default"] is not None else "") for n in sorted(names) if n in widget_names]
        hint = f"; it is set by {', '.join(via)}" if via else ""
        out["questions"].append(f"Cell {u['cell']} reads or writes a table named at runtime ({u['expression']} in {u['call']}){hint}. Which table does it resolve to in production?")
    for fw in out["file_writes"]:
        if fw.get("unresolved"):
            out["questions"].append(f"Cell {fw['cell']} writes a {fw['format']} file to a path built at runtime ({fw['path']} in {fw['call']}). Where does it land in production?")
    for r in out["runs"]:
        if r.get("unresolved"):
            out["questions"].append(f"Cell {r['cell']} runs another notebook at a path built at runtime ({r['path']}). Which notebook is it?")
        else:
            out["questions"].append(f"Cell {r['cell']} runs notebook {r['path']} ({r['kind']}); its tables and rules are not in this file, so it must be parsed separately.")
    if out["widgets"] and not out["header_comments"]:
        out["questions"].append("The notebook takes widget parameters (" + ", ".join(w["name"] for w in out["widgets"]) + ") and no header comment says who runs it or with which values; ask for the job definition.")
    if not out["reads"] and not out["writes"]:
        out["notes"] = ["No tables found. If this notebook reads via a connector or widgets, the table names may be in parameters; ask."]
    if low.endswith(".sql") and out["reads"] and not out["writes"]:
        # a bare view definition (SELECT * FROM (WITH ...)) with no CREATE/INSERT: the file name is the only target
        out["writes"] = []
        out["implied_target"] = os.path.splitext(os.path.basename(path))[0]
        out["questions"].append(f"This SQL file defines a view with no CREATE statement; its target was taken from the file name ({out['implied_target']}). Confirm the table it defines.")
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out")
    a = ap.parse_args()
    d = parse(a.path); js = json.dumps(d, indent=2)
    if a.out:
        open(a.out, "w").write(js); print(f"wrote {a.out}: {len(d['cells'])} cells, reads {len(d['reads'])}, writes {len(d['writes'])}, {len(d['expressions'])} aliased expressions, {len(d['file_writes'])} file writes, {len(d['runs'])} runs, {len(d['unresolved_tables'])} unresolved tables, {len(d['questions'])} questions")
    else:
        print(js)


if __name__ == "__main__":
    main()
