#!/usr/bin/env python3
"""
Read a table catalog exported from Google Sheets (.csv or .xlsx) into JSON.

Usage:
    python3 parse_catalog.py <catalog.csv|.xlsx> [-o out.json]

The catalog is one row per warehouse object. Header names are matched loosely (case,
spacing and punctuation ignored), so "TABLE_NAME", "Table name" and "table_name" all work.
Columns looked for:
  full table name     a header containing "table" and "name", or "full name", or "object";
                      failing that, the first column whose values look like DB.SCHEMA.TABLE
  TABLE_OWNER         header containing "owner"
  TABLE_TYPE          header containing "type"  (VIEW / TABLE)
  Active?             header containing "active"  (1/0, yes/no, true/false)
  Collab to prod priority
                      header containing "priority"
  Static or not static
                      header containing "static"
  Link to code        header containing "link", "code", "url" or "github"

Output JSON:
  file         path given
  header_row   1-based sheet row that was taken as the header
  columns      which header was used for each field (null when none was found)
  tables       one entry per row with a table name:
                 full_name   as written, whitespace trimmed
                 short_name  last part of the dotted name, lowercased, underscores to spaces
                             ("METIS_FUNNEL_V2" -> "metis funnel v2"; version suffixes are kept)
                 schema      everything before the last dot ("" when the name has no dot)
                 owner, type, priority, static, code_link   as written (empty string when blank)
                 active      true / false / null (null when blank or unrecognised; unrecognised
                             values raise a question)
                 kind_hint   "view we built" when type is VIEW and the owner is not a
                             PDP/warehouse owner; otherwise "HRDW". A PDP/warehouse owner is an
                             owner string containing PDP, HRDW or WAREHOUSE (case-insensitive).
                             This is a hint for the Layer column, not a decision.
                 row         1-based sheet row
  duplicates   groups of full names that differ only by a _V2/_V3/_VW/_VWW style suffix, or whose
               last part is one character apart (CODE vs CODEE): [{names, reason}]
  questions    plain sentences for the reviewer (missing columns, rows without a name,
               unrecognised Active values, each duplicate group)

Never raises on odd input: a file it cannot read returns an empty tables list and a question.
"""
import argparse
import csv
import json
import os
import re
import sys

RE_DOTTED = re.compile(r"^[A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*){1,3}$")
RE_SUFFIX = re.compile(r"_(?:V\d+|VW+)$", re.I)
PDP_OWNER = re.compile(r"PDP|HRDW|WAREHOUSE", re.I)
TRUE_WORDS = {"1", "true", "yes", "y", "active", "t"}
FALSE_WORDS = {"0", "false", "no", "n", "inactive", "f"}


# ----------------------------------------------------------------------------- tabular reader
def cell_text(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def read_rows(path, questions):
    """Return rows as lists of strings. CSV via the csv module; .xlsx via openpyxl (first sheet)."""
    low = path.lower()
    if low.endswith((".xlsx", ".xlsm")):
        try:
            from openpyxl import load_workbook
        except ImportError:
            questions.append("openpyxl is not installed, so the .xlsx catalog could not be read; export it as .csv or pip install openpyxl.")
            return []
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
        except Exception as e:
            questions.append(f"Could not open {path} as a workbook ({e}).")
            return []
        ws = wb.worksheets[0]
        if len(wb.worksheets) > 1:
            questions.append(f"The workbook has {len(wb.worksheets)} sheets; only the first ({ws.title!r}) was read as the catalog.")
        return [[cell_text(v) for v in row] for row in ws.iter_rows(values_only=True)]
    try:
        with open(path, encoding="utf-8-sig", errors="replace", newline="") as f:
            sample = f.read(4096); f.seek(0)
            dialect = csv.excel
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
            except csv.Error:
                pass
            return [[cell_text(c) for c in row] for row in csv.reader(f, dialect)]
    except OSError as e:
        questions.append(f"Could not read {path} ({e}).")
        return []


def norm(h):
    return re.sub(r"[^a-z0-9]+", " ", (h or "").lower()).strip()


def find_col(headers, *tests):
    """tests are callables on the normalised header; first header passing any test wins."""
    for t in tests:
        for i, h in enumerate(headers):
            if h and t(h):
                return i
    return None


# ----------------------------------------------------------------------------- parse
def short_name(full):
    last = full.rsplit(".", 1)[-1]
    return re.sub(r"\s+", " ", last.lower().replace("_", " ")).strip()


def parse_active(v, row, questions):
    s = v.strip().lower()
    if s == "":
        return None
    if s in TRUE_WORDS:
        return True
    if s in FALSE_WORDS:
        return False
    questions.append(f"Row {row}: Active value {v!r} is not 1/0 or yes/no; treated as unknown.")
    return None


def one_char_apart(a, b):
    """True when a and b differ by one substitution, insertion or deletion."""
    if a == b:
        return False
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) == 1
    if len(a) > len(b):
        a, b = b, a
    i = 0
    while i < len(a) and a[i] == b[i]:
        i += 1
    return a[i:] == b[i + 1:]


def duplicate_groups(names):
    """names: list of full names. Union-find on suffix-stripped base and on one-char-apart last parts."""
    parent = {n: n for n in names}
    reason = {}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x

    def union(a, b, why):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra
        reason.setdefault(frozenset([a, b]), why)

    def base(n):
        up = n.upper()
        while True:
            new = RE_SUFFIX.sub("", up)
            if new == up:
                return new
            up = new

    by_base = {}
    for n in names:
        by_base.setdefault(base(n), []).append(n)
    for group in by_base.values():
        for other in group[1:]:
            union(group[0], other, "version or view suffix")
    uniq = list(dict.fromkeys(names))
    for i, a in enumerate(uniq):
        for b in uniq[i + 1:]:
            if find(a) == find(b):
                continue
            sa, sb = a.rsplit(".", 1), b.rsplit(".", 1)
            same_schema = (sa[0] if len(sa) > 1 else "") == (sb[0] if len(sb) > 1 else "")
            if same_schema and one_char_apart(base(a).rsplit(".", 1)[-1], base(b).rsplit(".", 1)[-1]):
                union(a, b, "one character apart")
    groups = {}
    for n in uniq:
        groups.setdefault(find(n), []).append(n)
    out = []
    for members in groups.values():
        if len(members) < 2:
            continue
        whys = sorted({w for pair, w in reason.items() if pair <= set(members)})
        out.append({"names": members, "reason": ", ".join(whys) or "similar names"})
    return out


def parse(path):
    out = {"file": path, "header_row": None, "columns": {}, "tables": [], "duplicates": [], "questions": []}
    q = out["questions"]
    rows = read_rows(path, q)
    if not rows:
        if not q:
            q.append("The catalog file is empty.")
        return out

    # header row: first of the first 15 rows with a header that looks like a table-name column
    name_tests = (lambda h: "table" in h and "name" in h, lambda h: "full name" in h, lambda h: h in ("table", "object", "object name", "name"))
    header_idx, name_col = None, None
    for i, row in enumerate(rows[:15]):
        hs = [norm(c) for c in row]
        c = find_col(hs, *name_tests)
        if c is not None:
            header_idx, name_col = i, c
            break
    if header_idx is None:
        # fall back: first column whose values look dotted; header is the row before the first such value
        for i, row in enumerate(rows[:15]):
            for j, c in enumerate(row):
                if RE_DOTTED.match(c) and c.count(".") >= 1:
                    header_idx, name_col = (i - 1 if i > 0 else 0), j
                    break
            if header_idx is not None:
                break
        if header_idx is None:
            q.append("No table-name column found: no header mentions 'table name' and no cell looks like DB.SCHEMA.TABLE. Confirm which column holds the full table name.")
            return out
        q.append(f"No header mentions 'table name'; column {name_col + 1} was taken as the table name because its values look like DB.SCHEMA.TABLE. Confirm.")
    headers = [norm(c) for c in rows[header_idx]]
    raw_headers = rows[header_idx]
    out["header_row"] = header_idx + 1
    cols = {
        "full_name": name_col,
        "owner": find_col(headers, lambda h: "owner" in h),
        "type": find_col(headers, lambda h: "table type" in h or "object type" in h, lambda h: h == "type", lambda h: "type" in h and "name" not in h),
        "active": find_col(headers, lambda h: "active" in h),
        "priority": find_col(headers, lambda h: "priority" in h),
        "static": find_col(headers, lambda h: "static" in h),
        "code_link": find_col(headers, lambda h: "link" in h, lambda h: "github" in h or "url" in h, lambda h: "code" in h),
    }
    out["columns"] = {k: (raw_headers[v] if v is not None else None) for k, v in cols.items()}
    for k, label in (("owner", "TABLE_OWNER"), ("type", "TABLE_TYPE"), ("active", "Active?"), ("code_link", "Link to code")):
        if cols[k] is None:
            q.append(f"No {label} column found in the catalog header; {k} is blank on every row.")

    def get(row, key):
        c = cols[key]
        return row[c] if c is not None and c < len(row) else ""

    for i in range(header_idx + 1, len(rows)):
        row = rows[i]; rnum = i + 1
        if not any(c for c in row):
            continue
        full = get(row, "full_name")
        if not full:
            q.append(f"Row {rnum} has values but no table name; skipped.")
            continue
        if not RE_DOTTED.match(full):
            q.append(f"Row {rnum}: table name {full!r} is not a plain DB.SCHEMA.TABLE name; kept as written.")
        typ = get(row, "type")
        owner = get(row, "owner")
        is_view = typ.strip().upper().startswith("VIEW")
        kind_hint = "view we built" if is_view and not PDP_OWNER.search(owner) else "HRDW"
        out["tables"].append({
            "full_name": full,
            "short_name": short_name(full),
            "schema": full.rsplit(".", 1)[0] if "." in full else "",
            "owner": owner,
            "type": typ,
            "active": parse_active(get(row, "active"), rnum, q),
            "priority": get(row, "priority"),
            "static": get(row, "static"),
            "code_link": get(row, "code_link"),
            "kind_hint": kind_hint,
            "row": rnum,
        })

    names = [t["full_name"] for t in out["tables"]]
    exact = {n for n in names if names.count(n) > 1}
    for n in sorted(exact):
        q.append(f"{n} appears on more than one catalog row; confirm which row is current.")
    out["duplicates"] = duplicate_groups(list(dict.fromkeys(names)))
    for g in out["duplicates"]:
        active = [t["full_name"] for t in out["tables"] if t["full_name"] in g["names"] and t["active"] is True]
        hint = f" Active flag says: {', '.join(active)}." if active else " None is marked active."
        q.append(f"{' / '.join(g['names'])} look like versions of one table ({g['reason']}). Which one is current, and are the others to be retired?{hint}")
    for t in out["tables"]:
        if t["active"] is True and not t["code_link"] and t["kind_hint"] == "view we built":
            q.append(f"{t['full_name']} is active but has no link to code; where is it built?")
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out")
    a = ap.parse_args()
    d = parse(a.path); js = json.dumps(d, indent=2)
    if a.out:
        open(a.out, "w").write(js)
        print(f"wrote {a.out}: {len(d['tables'])} tables, {len(d['duplicates'])} duplicate groups, {len(d['questions'])} questions")
    else:
        print(js)


if __name__ == "__main__":
    main()
