#!/usr/bin/env python3
"""
Read a metric definitions sheet (.csv or .xlsx), one row per metric, into JSON.

Usage:
    python3 parse_definitions.py <definitions.csv|.xlsx> [-o out.json]

Header names are matched loosely (case, spacing and punctuation ignored). Columns looked for:
  name         header containing "metric" and "name", or "metric", "kpi", "measure", or exactly "name"
  definition   header containing "definition", "description", "wording", "business" or "logic"
  category     header containing "category", "family", "group", "area" or "theme"
  tir          any header containing "TIR" (for example "Uses TIR?", "TIR flag")

The header row is the first of the first 15 rows on which a name column can be found.

Output JSON:
  file         path given
  header_row   1-based sheet row taken as the header (null when none was found)
  columns      which header was used for each field (null when none was found)
  metrics      one entry per row with a metric name:
                 name         as written, whitespace trimmed
                 definition   as written ("" when blank)
                 category     as written ("" when blank or no column)
                 tir          copied exactly as written, as a string ("" when blank or no column)
                 row          1-based sheet row
  questions    plain sentences for the reviewer: no name column (then metrics is empty),
               no definition column, rows with a name but no definition, duplicated names

Never raises on odd input.
"""
import argparse
import csv
import json
import re
import sys


# ----------------------------------------------------------------------------- tabular reader
def cell_text(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def read_rows(path, questions):
    low = path.lower()
    if low.endswith((".xlsx", ".xlsm")):
        try:
            from openpyxl import load_workbook
        except ImportError:
            questions.append("openpyxl is not installed, so the .xlsx file could not be read; export it as .csv or pip install openpyxl.")
            return []
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
        except Exception as e:
            questions.append(f"Could not open {path} as a workbook ({e}).")
            return []
        ws = wb.worksheets[0]
        if len(wb.worksheets) > 1:
            questions.append(f"The workbook has {len(wb.worksheets)} sheets; only the first ({ws.title!r}) was read as the definitions sheet.")
        return [[cell_text(v) for v in row] for row in ws.iter_rows(values_only=True)]
    try:
        with open(path, encoding="utf-8-sig", errors="replace", newline="") as f:
            sample = f.read(4096); f.seek(0)
            dialect = csv.excel
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
            except csv.Error:
                pass
            return [[cell_text(c) for c in row] for row in csv.reader(f, dialect)]
    except OSError as e:
        questions.append(f"Could not read {path} ({e}).")
        return []


def norm(h):
    return re.sub(r"[^a-z0-9]+", " ", (h or "").lower()).strip()


def find_col(headers, *tests):
    for t in tests:
        for i, h in enumerate(headers):
            if h and t(h):
                return i
    return None


NAME_TESTS = (
    lambda h: "metric" in h and "name" in h,
    lambda h: h in ("metric", "metrics", "kpi", "measure", "name", "metric title"),
    lambda h: "kpi" in h or "measure name" in h,
)


# ----------------------------------------------------------------------------- parse
def parse(path):
    out = {"file": path, "header_row": None, "columns": {}, "metrics": [], "questions": []}
    q = out["questions"]
    rows = read_rows(path, q)
    if not rows:
        if not q:
            q.append("The definitions file is empty.")
        return out
    header_idx, name_col = None, None
    for i, row in enumerate(rows[:15]):
        c = find_col([norm(x) for x in row], *NAME_TESTS)
        if c is not None:
            header_idx, name_col = i, c
            break
    if header_idx is None:
        q.append("No metric name column found in the first 15 rows (looked for a header containing 'metric name', 'metric', 'KPI', 'measure' or 'name'). Confirm which column holds the metric name; nothing was read.")
        return out
    raw_headers = rows[header_idx]
    headers = [norm(h) for h in raw_headers]
    out["header_row"] = header_idx + 1
    cols = {
        "name": name_col,
        "definition": find_col(headers, lambda h: "definition" in h, lambda h: "description" in h or "wording" in h, lambda h: "business" in h or "logic" in h),
        "category": find_col(headers, lambda h: "category" in h or "family" in h, lambda h: "group" in h or "area" in h or "theme" in h),
        "tir": find_col(headers, lambda h: re.search(r"\btir\b", h) is not None),
    }
    if cols["definition"] == name_col:
        cols["definition"] = None
    out["columns"] = {k: (raw_headers[v] if v is not None else None) for k, v in cols.items()}
    if cols["definition"] is None:
        q.append("No definition column found (looked for 'definition', 'description', 'wording', 'business' or 'logic'); definitions are blank.")
    if cols["tir"] is None:
        q.append("No TIR column found (no header contains 'TIR'); tir is blank on every metric.")

    def get(row, key):
        c = cols[key]
        return row[c] if c is not None and c < len(row) else ""

    for i in range(header_idx + 1, len(rows)):
        row = rows[i]; rnum = i + 1
        if not any(row):
            continue
        name = get(row, "name")
        if not name:
            q.append(f"Row {rnum} has text but no metric name; skipped. Is it a continuation of the row above?")
            continue
        m = {"name": name, "definition": get(row, "definition"), "category": get(row, "category"), "tir": get(row, "tir"), "row": rnum}
        if cols["definition"] is not None and not m["definition"]:
            q.append(f"Row {rnum}: {name!r} has no definition written.")
        out["metrics"].append(m)
    seen = {}
    for m in out["metrics"]:
        seen.setdefault(m["name"].lower(), []).append(m["row"])
    for name, rws in seen.items():
        if len(rws) > 1:
            q.append(f"Metric {name!r} appears on rows {', '.join(map(str, rws))}; confirm whether these are one metric or two.")
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("-o", "--out")
    a = ap.parse_args()
    d = parse(a.path); js = json.dumps(d, indent=2)
    if a.out:
        open(a.out, "w").write(js)
        print(f"wrote {a.out}: {len(d['metrics'])} metrics, {len(d['questions'])} questions")
    else:
        print(js)


if __name__ == "__main__":
    main()
