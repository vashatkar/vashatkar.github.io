# Source folder (v8)

No manifest. The folder layout is the manifest:

```
catalog/       table catalog export (.csv/.xlsx)
sql/           .sql files (a view definition with no CREATE names its table from the file name)
notebooks/     Databricks notebooks as .py / .ipynb / .sql
products/      the product workbook(s), .xlsx
definitions/   the metric definitions sheet (.csv/.xlsx), one row per metric, with a TIR column
restructure/   the restructure sheet export
```

Read in that order by `scripts/run_all.py`. A file in the wrong folder is read as that folder's kind, so put each where it belongs.
