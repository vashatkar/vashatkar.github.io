# Workbook schema (v8)

Header row 4, data from row 5. Plain database: every column visible, no helpers, no merged cells, no ID codes. Names are the keys.

## Metrics

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Metric name | name (the key, unique) | the skill, from files |  | The name people use, from the definitions sheet or the product. Unique. |
| Family | text | the skill, from files |  | The business question the metric answers, from references/families.md. Chosen by reading the calculation. |
| Definition in plain words | text | the skill, from files |  | From the definitions sheet, copied as written. Blank if the sheet has none. |
| What the code does | text | the skill, from files |  | What the SQL or notebook actually calculates, in words, with the formula on its own line after. This is the truth; where it disagrees with the definition, a Question is raised. |
| Cuts | one name per line, each '- ' | the skill, from files | names on Dimensions | The populations and filters this one calculation is shown by, one per line with a hyphen. Each must be spelled as on the Dimensions sheet. |
| Reads from | one name per line, each '- ' | the skill, from files | names on Legacy tables | The tables the calculation reads, one per line. |
| TIR | text | the skill, from files |  | Copied exactly from the definitions sheet's TIR column. |
| Official | drop-down | a person only | Yes, No, Undecided | Whether this rule is the agreed one for its family. |
| Why | text | a person only |  | The reason for the Official call, in one sentence. |
| Who is left out | text | the skill, from files |  | Only when the code has an explicit exclusion filter; the filter quoted. Otherwise blank. |
| Same rule elsewhere | text | the skill, from files |  | Other names found for this same calculation, one per line. A Question is raised asking which name is official. |
| Fields read | one name per line, each '- ' | the skill, from files | names on Fields | The columns the calculation uses, one per line. |
| Script | one name, drop-down from a sheet | the skill, from files | names on Scripts | The script that computes it, if any. |
| Review | drop-down | a person only | Proposed, Accepted, Corrected, Rejected | Proposed = a tool wrote it and nobody has checked. Accepted / Corrected / Rejected are a person's. |
| Source | text | the skill, from files |  | The file, tab, cell or notebook cell the row came from. Specific enough to open it. |
| Confidence | drop-down | the skill, from files | Found, Inferred, Proposed, Human | Found = read from a file. Inferred = deduced from more than one file. Proposed = a best reading, labelled. Human = a person entered it. |

## Legacy tables

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Table name | name (the key, unique) | the skill, from files |  | Two or three words a colleague would recognise. Unique. |
| Kind | drop-down | the skill, from files | HRDW, View we built, Hand-kept sheet, DEXP, Script output file, Shared (other team), Other | HRDW = delivered by PDP. View we built = a view our team or TAAA owns (from the catalog). Hand-kept sheet = a file a person maintains. DEXP = the NextGen exports. |
| Owner | text | the skill, from files |  | From the catalog's TABLE_OWNER, or PDP for HRDW. |
| Platform | one name, drop-down from a sheet | a person only | names on Platforms | HRDW rows only: the system the data is born in. A person fills it from PDP's mapping. |
| What PDP changes on load | text | a person only |  | HRDW rows only: the transformation between the platform and the warehouse table, from PDP. Blank until PDP says. |
| Built from | one name per line, each '- ' | the skill, from files | names on Legacy tables | The tables this one reads, one per line, from the SQL or notebook that builds it. Blank for HRDW. |
| Built by | filled by sync | sync (never typed) |  | The script that writes it. Filled by sync from the Scripts sheet. HRDW rows say delivered by PDP. |
| Feeds | filled by sync | sync (never typed) |  | The tables built from this one and the products that read it directly, one per line. Filled by sync. |
| Goes to | filled by sync | sync (never typed) |  | From the Legacy to target sheet: the target table, or 'N targets (split)'. HRDW rows say stays. Filled by sync. |
| Layer | filled by sync | sync (never typed) |  | Target layer(s) from Legacy to target; 1 for HRDW. |
| Status | drop-down | a person only | Not mapped, Mapped, Built, Retired, Stays | Not mapped, Mapped, Built, Retired, Stays. |
| Refresh frequency | drop-down | the skill, from files | Real time, Daily, Weekly, Monthly, Quarterly, On request, Unknown | How often it updates, from a schedule or a person. |
| Refresh owned by | text | the skill proposes; a person confirms |  | Team that runs the refresh. |
| Point of contact | text | a person only |  | The person to call. |
| Full name | text | the skill, from files |  | database.schema.table as written in the source, or the file path. |
| Code link | text | the skill, from files |  | From the catalog: where the code that builds it lives. |
| Active | text | the skill, from files |  | From the catalog's Active flag, as written. |
| Priority | text | the skill, from files |  | From the catalog's 'Collab to prod priority' column, as written. |
| Static | text | the skill, from files |  | From the catalog's 'Static or not static' column, as written. |
| Review | drop-down | a person only | Proposed, Accepted, Corrected, Rejected | Proposed = a tool wrote it and nobody has checked. Accepted / Corrected / Rejected are a person's. |
| Source | text | the skill, from files |  | The file, tab, cell or notebook cell the row came from. Specific enough to open it. |
| Confidence | drop-down | the skill, from files | Found, Inferred, Proposed, Human | Found = read from a file. Inferred = deduced from more than one file. Proposed = a best reading, labelled. Human = a person entered it. |

## Legacy to target

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Legacy table | one name, drop-down from a sheet | the skill, from files | names on Legacy tables | A name from the Legacy tables sheet. |
| Target table | text | the skill, from files |  | The proposed table, as named on the restructure sheet. It may not exist yet. |
| Layer | drop-down | the skill, from files | 1, 2, 3, 4 | The proposed layer the target sits in. |
| Why we need this | text | a person only |  | The analyst's note from the restructure sheet, verbatim. |
| Business logic that will apply | text | a person only |  | The analyst's note on the logic the target will carry, verbatim. |
| Status | drop-down | a person only | Mapped, Build, Built, Retired | Mapped, Build, Built, Retired. |
| Review | drop-down | a person only | Proposed, Accepted, Corrected, Rejected | Proposed = a tool wrote it and nobody has checked. Accepted / Corrected / Rejected are a person's. |
| Source | text | the skill, from files |  | The file, tab, cell or notebook cell the row came from. Specific enough to open it. |
| Confidence | drop-down | the skill, from files | Found, Inferred, Proposed, Human | Found = read from a file. Inferred = deduced from more than one file. Proposed = a best reading, labelled. Human = a person entered it. |

## Products

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Product name | name (the key, unique) | the skill, from files |  | The name people use. Unique. |
| Kind | drop-down | the skill, from files | Excel scorecard, Tableau, QuickSight, Sent report, Data pull, Other | Excel scorecard, Tableau, QuickSight, Sent report, Data pull. |
| Owner team | text | the skill proposes; a person confirms |  | Team responsible for it. |
| Point of contact | text | a person only |  | The person to call. |
| Reads from | one name per line, each '- ' | the skill, from files | names on Legacy tables | The tables and files it reads directly, one per line. |
| Refresh cadence | drop-down | the skill, from files | Real time, Daily, Weekly, Monthly, Quarterly, On request, Unknown | How often the numbers update. |
| Delivery cadence | text | a person only |  | Sent reports: when and to whom it goes out. |
| Automation level | drop-down | a person only | Automated, Partly manual, Manual, Unknown | Automated, Partly manual, Manual. An analyst sets it. |
| Where a person touches it | text | the skill, from files |  | Every hand step, one per line with a hyphen: what is pasted, what is uploaded, what is run by hand. |
| Scripts | filled by sync | sync (never typed) |  | Scripts that feed it, from the Scripts sheet. Filled by sync. |
| Decision | drop-down | a person only | Automate, Merge, Retire, Keep, Undecided | Automate, Merge, Retire, Keep, Undecided. Never written by a tool. |
| Why | text | a person only |  | The reason for the decision, in one sentence. |
| Review | drop-down | a person only | Proposed, Accepted, Corrected, Rejected | Proposed = a tool wrote it and nobody has checked. Accepted / Corrected / Rejected are a person's. |
| Source | text | the skill, from files |  | The file, tab, cell or notebook cell the row came from. Specific enough to open it. |
| Confidence | drop-down | the skill, from files | Found, Inferred, Proposed, Human | Found = read from a file. Inferred = deduced from more than one file. Proposed = a best reading, labelled. Human = a person entered it. |

## Fields

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Field name | name (the key, unique) | the skill, from files |  | The column, with the table in brackets when the same column exists on two tables. Unique. |
| Table | one name, drop-down from a sheet | the skill, from files | names on Legacy tables | The table it belongs to. |
| Type | drop-down | the skill, from files | Raw, Derived | Raw = a physical column. Derived = computed by a rule in a script or a product. |
| Rule | text | the skill, from files |  | Derived only: the rule in words, then the expression. |
| Used by metrics | filled by sync | sync (never typed) |  | Filled by sync from Metrics' Fields read. |
| Source | text | the skill, from files |  | File and cell. |
| Confidence | drop-down | the skill, from files | Found, Inferred, Proposed, Human |  |

## Scripts

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Script name | name (the key, unique) | the skill, from files |  | Two or three words. Unique. |
| Kind | drop-down | the skill, from files | Databricks notebook, SQL file, Databricks workflow, Manual process, Other |  |
| Builds | one name per line, each '- ' | the skill, from files | names on Legacy tables | Tables it writes, one per line. |
| Feeds | one name per line, each '- ' | the skill, from files | names on Products | Products it writes into directly, one per line. |
| Reads | one name per line, each '- ' | the skill, from files | names on Legacy tables | Tables it reads, one per line. |
| Schedule | text | the skill, from files |  | In words, from a job definition or header comment. |
| Started by | text | the skill, from files |  | A schedule, or a person by hand. |
| Who is told when it fails | text | the skill proposes; a person confirms |  | From alert settings; 'Nobody' when none are configured. |
| Code link | text | the skill, from files |  | Repo path or URL. |
| Source | text | the skill, from files |  |  |

## Dimensions

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Cut name | name (the key, unique) | the skill, from files |  | The cut as people say it. Unique. |
| Supplied by table | one name, drop-down from a sheet | the skill, from files | names on Legacy tables | The table the cut comes from, where known. |
| Used by metrics | filled by sync | sync (never typed) |  | Filled by sync from Metrics' Cuts. |

## Platforms

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Platform name | name (the key, unique) | a person only |  |  |
| Feeds which HRDW tables | one name per line, each '- ' | a person only | names on Legacy tables | One per line. |

## Questions

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Question | text | the skill, from files |  |  |
| About | text | the skill, from files |  | Sheet and row name. |
| What was seen | text | the skill, from files |  |  |
| Raised by pass | text | the skill, from files |  |  |
| Answer | text | a person only |  |  |
| Status | drop-down | a person only | Open, Answered, Dropped |  |

## Decision log

| Column | Kind | Who | Values / links to | Meaning |
|---|---|---|---|---|
| Date | text | a person only |  |  |
| Decision | text | a person only |  |  |
| About | text | a person only |  | Sheet and row name(s). |
| Decided by | text | a person only |  |  |

