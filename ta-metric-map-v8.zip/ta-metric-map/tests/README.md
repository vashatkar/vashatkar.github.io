# Self-test

Before running the skill on real files, prove the scripts work here:

    python3 scripts/parse_twb.py tests/sample_scorecard.twb -o /tmp/sample.json
    cp template/TA_Metric_Map_v7.xlsx /tmp/map.xlsx
    python3 scripts/workbook.py check /tmp/map.xlsx

Expected from the parser: 1 datasource reading TA_RPT.SCORECARD_BASE, three calculated
fields (two captioned "Cycle Time" with different formulas, one "Hires"), three worksheets
(Eng, Finance, Pipeline), one dashboard. The two "Cycle Time" formulas are the deduplication
case in extraction-rules.md: same caption, different formula, so two Metrics rows in one
family plus a Question.

Notebook parser:

    python3 scripts/parse_notebook.py tests/sample_notebook.py

Expected: reads hrdw.requisition, hrdw.offer, hrdw.requisition_history, ta_custom.req_linkage,
ta_rpt.scorecard_base, ta_rpt.hires_by_req; writes ta_rpt.scorecard_base and ta_rpt.hires_by_req;
six aliased expressions including cycle_time_days and counts_for_ttf; a join on
requisition_history with a BETWEEN condition, which is the recruiter-credit rule.

Also expected from the added keys:
  header_comments    one line: "Owner: Team Opportunity. Runs weekdays 06:00 ET via workflow ta_daily_scorecard."
  runs               one entry, kind "%run", path "./helpers" (cell 1)
  widgets            one entry, name "schema", default "ta_rpt"
  unresolved_tables  one entry, expression f"{schema}.req_snapshot" from .table in the last cell;
                     it is NOT in reads, and the matching question names the widget and its default
  file_writes        one entry: path /dbfs/FileStore/ta/scorecard_input.xlsx, format xlsx,
                     sheet_name "Data", call .to_excel
  questions          two: the runtime-named table, and "./helpers must be parsed separately"

Scorecard workbook parser:

    python3 scripts/parse_xlsx.py tests/sample_scorecard.xlsx

The fixture is a Data tab (60 rows, 7 snake_case columns: req_id, org, month, hires,
offers_extended, cycle_time_days, source), two scorecard tabs Eng and Finance with the same five
labels and month columns Jul/Aug/Sep, one comment on Eng!B7, a named range Data_Hires, and a
hidden Scratch sheet. Expected:
  sheets      Data = "data dump" (header_row 1, 7 columns); Eng and Finance = "scorecard"
              (12 formulas each, header_row 2); Scratch = "hidden", read_by_visible_formulas []
  metrics     exactly 5, each with where listing 6 cells and tabs ["Eng", "Finance"]:
                Hires                  formula, SUMIFS over the named range Data_Hires
                                       (names_used {"Data_Hires": "Data!$D:$D"}; reads_labels say org / month / hires)
                Offers extended        formula, SUMIFS, unit_hint unknown
                Offer accept rate      formula, shape R[-2]C[0]/R[-1]C[0], unit_hint percent,
                                       reads_labels resolve B3 to "Hires / Jul" etc.
                Avg cycle time (days)  formula, AVERAGEIFS, unit_hint days
                Open reqs              "pasted value", cached [120,131,128,135,146,143],
                                       comments [["Eng!B7", "pasted from notebook run 2026-10-01"]]
              The org literal ("Eng"/"Finance") appears in the shape as "<sheet>" and the month
              literal as "<period>" with parameters.period.values {Jul: 2026-07, Aug: 2026-08,
              Sep: 2026-09}: three months x two tabs collapse into one metric, not six or fifteen.
  tables      one entry for Data, listobject null, kind_guess "Script output" (snake_case headers)
  questions   four: formula cells never calculated (one per scorecard tab, because openpyxl writes
              no cached values), hidden Scratch not read by any formula, and "what writes Data?".
              No question about Open reqs, because one of its cells carries a comment.

Manifest proposer:

    python3 scripts/propose_manifest.py <any folder containing tests/>

Job definition and incidents log (used by Pass 2b and Pass 5c):

    tests/sample_job.json        a Databricks workflow: weekdays 06:00 ET, owner, failure email, runs sample_notebook
    tests/sample_incidents.csv   five reported problems; two are the same symptom (recurring), one fix is "Fixed" with no detail (Root stage Unknown + a question)

Expected rows: one Jobs row (Trigger Scheduled, Failure notice "email to ta-data-alerts@"), five
Incidents rows with Root stages Manual step, Platform to HRDW, Manual step, Inside the dashboard,
Unknown.

## v8 input readers

Table catalog (Google Sheets export):

    python3 scripts/parse_catalog.py tests/sample_catalog.csv

The fixture is 12 rows: nine METIS_* views in HRDW_DB.PHDP_HR_UCS_RCRTG owned by SYSDBA_ODCP,
two PDP-owned HRDW tables in PHDP_HR_API_RCRTG, one DEXP_DB sandbox view. Expected:
  tables      12, header_row 1, every column found by its header. short_name is the last dotted
              part lowercased with underscores as spaces, suffixes kept ("metis funnel v2",
              "metis scorecard vw"). kind_hint is "view we built" for the ten VIEW rows whose owner
              does not contain PDP/HRDW/WAREHOUSE and "HRDW" for the two PDP_HR_OWNER tables.
  active      true/false from 1/0; null for METIS_CAMPUS_HIRES (value "maybe") plus a question
  duplicates  three groups: METIS_FUNNEL / _V2 (suffix), METIS_SCORECARD_VW / _VWW (suffix),
              METIS_ORG_CODE / _CODEE (one character apart)
  questions   four: the "maybe" Active value and one per duplicate group, each naming which
              member the Active flag favours. No "no link to code" question for the PDP tables
              (that check only fires for "view we built" rows).

Metric definitions sheet:

    python3 scripts/parse_definitions.py tests/sample_definitions.csv

Six metrics with columns Metric Name / Category / Definition / Uses TIR?. Expected: six entries
with tir copied as the strings "Yes"/"No" (not booleans), rows 2 to 7; one question, because
"Interview to Offer Rate" (row 7) has an empty definition. A file with no recognisable name
column returns metrics [] and one question, not an error.

Restructure sheet ("Legacy <> New tables mapping"):

    python3 scripts/parse_restructure.py tests/sample_restructure.csv

Four legend rows and a blank row precede the header, so header_row is 6 and legend lists
"Legend", "Already Existed - HRDW Table", "Completed", "In progress". Expected:
  pairs          four: scorecard_vw -> HRDW_DB.PHDP_HR_API_RCRTG.PL_WRKDAY_RCRTNG_FUNNEL (layer 2)
                 and scorecard_vw -> app_ownership (layer 3), both from row 7 and both carrying
                 row 7's note and logic verbatim; scorecard_tir -> tir_mapping (layer 3, row 8);
                 metis_funnel -> application driver (layer 2, row 9)
  no_legacy      two: the "-" row (recruiter_capacity) and the "Manual Input" row (org_code_lookup)
  legacy_tables  scorecard_vw, scorecard_tir, metis_funnel
  questions      two, one per no_legacy row, asking whether it is a new table or a missing name.
  The note in row 7 is a placeholder standing in for the real "why we need app_ownership" text;
  replace it with the sheet's wording when checking verbatim copying.

Bare SQL view definition (no CREATE statement):

    python3 scripts/parse_notebook.py tests/sql/metis_funnel.sql

Expected: reads HRDW_DB.PHDP_HR_API_RCRTG.PL_WRKDAY_JOB_REQ, HRDW_DB.PHDP_HR_API_RCRTG.PL_WRKDAY_RCRTNG_FUNNEL
and HRDW_DB.PHDP_HR_UCS_RCRTG.CAMPUS_REQS_V1 (the CTE names campus_req, all_req, funnel are not
reads); writes []; implied_target "metis_funnel"; one question saying the target was taken from the
file name; one join (all_req ON ar.REQ_ID = fn.REQ_ID); five aliased expressions including STAGE
(CASE), CYCLE_TIME_DAYS (DATEDIFF) and OFFER_ACCEPTED_FLAG. tests/sample_notebook.py is unchanged
by this rule because it has writes.

All three new parsers accept the same sheet saved as .xlsx (first sheet, or the sheet whose name
contains "legacy" and "mapping" for the restructure reader) and return a question instead of
raising on an empty, missing or unrecognisable file.
