SELECT * FROM (
WITH campus_req AS (
    SELECT
        r.REQ_ID,
        r.REQ_TITLE,
        'Campus' AS REQ_CHANNEL,
        r.ORG_CODE,
        r.OPEN_DT
    FROM HRDW_DB.PHDP_HR_UCS_RCRTG.CAMPUS_REQS_V1 r
    WHERE r.REQ_STATUS <> 'Cancelled'
),
all_req AS (
    SELECT
        j.REQ_ID,
        j.REQ_TITLE,
        'Professional' AS REQ_CHANNEL,
        j.ORG_CODE,
        j.OPEN_DT
    FROM HRDW_DB.PHDP_HR_API_RCRTG.PL_WRKDAY_JOB_REQ j
    WHERE j.REQ_STATUS IN ('Open', 'Filled', 'Closed')
    UNION ALL
    SELECT REQ_ID, REQ_TITLE, REQ_CHANNEL, ORG_CODE, OPEN_DT FROM campus_req
),
funnel AS (
    SELECT
        f.APPLICATION_ID,
        f.CANDIDATE_ID,
        f.REQ_ID,
        CASE WHEN f.STAGE_NAME = 'Phone Screen' THEN 'Screen'
             WHEN f.STAGE_NAME IN ('Onsite', 'Panel') THEN 'Interview'
             ELSE f.STAGE_NAME END AS STAGE,
        f.STAGE_ENTERED_DT,
        DATEDIFF(day, f.APPLIED_DT, f.HIRE_DT) AS CYCLE_TIME_DAYS,
        CASE WHEN f.OFFER_STATUS = 'Accepted' THEN 1 ELSE 0 END AS OFFER_ACCEPTED_FLAG
    FROM HRDW_DB.PHDP_HR_API_RCRTG.PL_WRKDAY_RCRTNG_FUNNEL f
)
SELECT
    fn.*,
    ar.REQ_TITLE,
    ar.REQ_CHANNEL,
    ar.ORG_CODE,
    ar.OPEN_DT
FROM funnel fn
LEFT JOIN all_req ar ON ar.REQ_ID = fn.REQ_ID
)
