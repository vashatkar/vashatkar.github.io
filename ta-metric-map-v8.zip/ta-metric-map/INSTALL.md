# Install and first run

## Install the skill

Unzip so that the folder is named `ta-metric-map` and sits in one of:

- `~/.claude/skills/ta-metric-map/` for your own use on this machine, or
- `<project>/.claude/skills/ta-metric-map/` inside a repo, so anyone who clones it gets the skill.

Claude Code lists it as `ta-metric-map`. Nothing else to register.

## Dependency

The scripts need Python 3.9+ and one package:

    pip install openpyxl

Nothing else; the Tableau and notebook parsers use the standard library.

## Self-test (do this once per machine)

    cd <skill folder>
    python3 scripts/parse_twb.py tests/sample_scorecard.twb | head -40
    python3 scripts/parse_notebook.py tests/sample_notebook.py | head -40
    python3 scripts/parse_xlsx.py tests/sample_scorecard.xlsx | head -40
    cp template/TA_Metric_Map_v8.xlsx /tmp/map.xlsx
    python3 scripts/workbook.py check /tmp/map.xlsx

All four should run without errors; `check` prints "OK".

## First real run

1. Put the inputs in your project folder, any names, any subfolders: the catalog export, the SQL files, the notebook export, the scorecard .xlsx, the definitions sheet, the restructure export.
2. Copy `template/TA_Metric_Map_v8.xlsx` next to it. Always work on a copy; the template stays empty.
3. Run the one command yourself, or ask Claude Code to:
   `python3 <skill>/scripts/run_all.py "<project folder>" TA_Metric_Map_v8.xlsx --product "TA scorecard"`
4. Then in Claude Code: "Use the ta-metric-map skill to finish TA_Metric_Map_v8.xlsx" — it writes the plain-words cells, sets families, folds duplicate calculations, checks, and shows the Metrics and Legacy tables tabs.

Running it again on the same files is safe: rows that already exist are skipped, not duplicated.

## What the workbook needs

Excel (desktop) for the Decisions sheet's click-through links and hover notes. Google Sheets
and LibreOffice open it and compute everything, but may not follow the in-sheet links.
