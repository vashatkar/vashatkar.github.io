---
name: ta-metric-map
description: Fill and check the TA metric map workbook (TA_Metric_Map_v8.xlsx) from a table catalog, SQL and Databricks notebooks, an Excel scorecard, a metric definitions sheet and the restructure sheet. One command fills every tab; you then write the plain-words cells, set families, fold duplicate calculations, and stop. Use when asked to inventory TA products, metrics, tables or scripts, run the TA data audit, or populate or extend the metric map.
---

# TA metric map (v8)

The workbook is a plain database with ten tabs: Metrics, Legacy tables, Legacy to target, Products,
Fields, Scripts, Dimensions, Platforms, Questions, Decision log. Names are the keys; there are no ID
codes anywhere. Multi-value cells hold one name per line, each line starting with "- ".

Four rules override everything else:

1. **Every cell comes from a file or stays blank with a Question.** No paraphrase to make a row look
   complete, no filler, no guessed owners or reasons. If you cannot point at the line in the file, the
   cell is blank.
2. **One row per calculation.** The same calculation on another population, filter or tab is ONE row
   with the cuts listed. Only a different calculation makes a second row. Near-identical calculations
   under different names fold into one row; the other names go in "Same rule elsewhere" and a Question
   asks which is official. The checker fails the run on duplicate rows or duplicate calculations.
3. **Never write a person's columns**: Decision, Official, Why, Platform, What PDP changes on load, the
   Decision log. Never overwrite a row whose Review is Accepted or Corrected.
4. **One stop.** Run the command, do the four finishing steps below, check, show the two tabs, stop.

## Inputs

Point the command at the project folder. No subfolders, no renaming. Files are sorted by what they
are: `.sql` is SQL (a view definition with no CREATE names its table from the file name);
`.py`/`.ipynb` are notebooks; `.twb`/`.twbx` are Tableau products; `.csv`/`.xlsx` are told apart by
their headers (a table catalog, a metric definitions sheet, the restructure sheet), and any other
`.xlsx` with data tabs is a product workbook such as the scorecard. The run prints what each file was
taken as; a file it cannot place raises a Question instead of stopping. The six-subfolder layout
(`catalog/ sql/ notebooks/ products/ definitions/ restructure/`) also still works.

Order of reading is fixed whatever the layout: catalog first (it settles Kind, owner, active flag and
code link for every table it lists), then the code (a file that shows how a table is built overrides a
schema-is-HRDW guess), then the product and the definitions sheet (the definitions sheet is the
dictionary, the code is the truth: where they disagree the code wins and a Question is raised),
then the restructure sheet last, because it joins onto tables that now exist.

## Run

```
python3 scripts/run_all.py "<project folder>" <map.xlsx> --product "<product name>"
```

It fills every tab from the files, runs `sync` (Built by, Feeds, Goes to, Layer, Scripts, Used by
metrics) and `check`, and prints what it added and every problem. It writes Review = Proposed on
every row. The template workbook is `template/TA_Metric_Map_v8.xlsx`; always run on a copy.

## Finish by hand (you, not the script)

1. **What the code does, in words.** The script put the formula or expression there. Put one plain
   sentence above it that says what it calculates (`references/writing-style.md`), keep the formula
   on its own line after. Nothing the formula does not say.
2. **Family.** From `references/families.md`, by reading the calculation. Blank plus a Question if
   none fits. Never a fragment of the name.
3. **Fold duplicates.** `check` lists any two rows with the same calculation. Decide which name is the
   product's and run `workbook.py merge Metrics "<keep>" "<fold>"`; it moves cuts, tables and fields
   onto the kept row, lists the folded name in Same rule elsewhere, and raises the "which name is
   official" Question. Rows that came from the definitions sheet only (no formula found) stay as
   they are, with their Question.
4. **Who is left out.** Only where the code has an explicit exclusion filter: quote it. Otherwise
   blank.

Then `python3 scripts/workbook.py check <map.xlsx>` (must print OK) and
`python3 scripts/check_quality.py <map.xlsx>` (must report no errors). Show the Metrics and Legacy
tables tabs as a plain table and stop.

## Working with the workbook

Only through `scripts/workbook.py`. `append` takes rows keyed by header text; link cells take names;
multi-value cells take a list. `fill` writes blank cells or Proposed rows and turns a conflict on a
validated row into a Question. `set` overwrites but refuses validated rows without `--force`.
`question "<sheet>: <row name>" "<question>" "<what was seen>"`. `merge` folds metrics. `sync`
rebuilds the derived columns. `check` fails on duplicates, unresolved names, bad dropdown values
and codes.

Source cells must be specific enough to open: `<file> cell N` for notebooks, `<file> tabs Eng,
Finance, label Hires` for the scorecard, `<catalog file> row N` for the catalog.

## What the files cannot tell you (ask, never guess)

Which platform feeds an HRDW table and what PDP changes on load; who owns a table the catalog does
not list; which script produced a pasted number; whether two calculations with different names are
meant to be the same metric; the population behind a pasted number; the refresh cadence when no
schedule is in a file; the reason a table exists. Each is a Question naming the row.

## What done looks like

Every file in the folder read or questioned. `check` OK, `check_quality` no errors. Every Metrics
row has either a calculation in words plus formula, or a Question saying where it is computed. No
two rows share a calculation. Every table the code builds has Built from; every HRDW table says
delivered by PDP. The person opens Metrics and Legacy tables and reads names, not codes.
